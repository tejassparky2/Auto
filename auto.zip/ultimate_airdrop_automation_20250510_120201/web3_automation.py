import logging
import json
import time
import re
import copy
from datetime import datetime
import requests
from urllib.parse import urlparse, urljoin

from app import db
from models import Account, Airdrop, Task, TaskExecution, TaskRecording

logger = logging.getLogger(__name__)

class Web3Automator:
    """
    Advanced Web3 automation system that supports wallet connections,
    token swaps, bridging, and other blockchain interactions across all
    major networks and wallet types.
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': 'https://example.com',
            'Referer': 'https://example.com/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Connection': 'keep-alive',
        }
        self.supported_networks = {
            'ethereum': {
                'chain_id': 1,
                'name': 'Ethereum Mainnet',
                'currency': 'ETH',
                'rpc_url': 'https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161',
                'explorer': 'https://etherscan.io'
            },
            'polygon': {
                'chain_id': 137,
                'name': 'Polygon Mainnet',
                'currency': 'MATIC',
                'rpc_url': 'https://polygon-rpc.com',
                'explorer': 'https://polygonscan.com'
            },
            'bsc': {
                'chain_id': 56,
                'name': 'Binance Smart Chain',
                'currency': 'BNB',
                'rpc_url': 'https://bsc-dataseed.binance.org',
                'explorer': 'https://bscscan.com'
            },
            'arbitrum': {
                'chain_id': 42161,
                'name': 'Arbitrum One',
                'currency': 'ETH',
                'rpc_url': 'https://arb1.arbitrum.io/rpc',
                'explorer': 'https://arbiscan.io'
            },
            'optimism': {
                'chain_id': 10,
                'name': 'Optimism',
                'currency': 'ETH',
                'rpc_url': 'https://mainnet.optimism.io',
                'explorer': 'https://optimistic.etherscan.io'
            },
            'avalanche': {
                'chain_id': 43114,
                'name': 'Avalanche C-Chain',
                'currency': 'AVAX',
                'rpc_url': 'https://api.avax.network/ext/bc/C/rpc',
                'explorer': 'https://snowtrace.io'
            },
            'solana': {
                'chain_id': 'solana',
                'name': 'Solana Mainnet',
                'currency': 'SOL',
                'rpc_url': 'https://api.mainnet-beta.solana.com',
                'explorer': 'https://explorer.solana.com'
            },
            'base': {
                'chain_id': 8453,
                'name': 'Base',
                'currency': 'ETH',
                'rpc_url': 'https://mainnet.base.org',
                'explorer': 'https://basescan.org'
            },
            'zksync': {
                'chain_id': 324,
                'name': 'zkSync Era',
                'currency': 'ETH',
                'rpc_url': 'https://mainnet.era.zksync.io',
                'explorer': 'https://explorer.zksync.io'
            }
        }
        self.wallet_types = {
            'metamask': {
                'extension_id': 'nkbihfbeogaeaoehlefnkodbefgpgknn',
                'detection_script': "return typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask",
                'connect_script': """
                    async function connectMetaMask() {
                        try {
                            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
                            return { success: true, address: accounts[0] };
                        } catch (error) {
                            return { success: false, error: error.message };
                        }
                    }
                    return await connectMetaMask();
                """
            },
            'phantom': {
                'extension_id': 'bfnaelmomeimhlpmgjnjophhpkkoljpa',
                'detection_script': "return typeof window.solana !== 'undefined' && window.solana.isPhantom",
                'connect_script': """
                    async function connectPhantom() {
                        try {
                            const resp = await window.solana.connect();
                            return { success: true, address: resp.publicKey.toString() };
                        } catch (error) {
                            return { success: false, error: error.message };
                        }
                    }
                    return await connectPhantom();
                """
            },
            'walletconnect': {
                'detection_script': "return typeof window.WalletConnectProvider !== 'undefined'",
                'connect_script': """
                    async function connectWalletConnect() {
                        try {
                            const provider = new WalletConnectProvider.default({
                                infuraId: "27e484dcd9e3efcfd25a83a78777cdf1"
                            });
                            const accounts = await provider.enable();
                            window.web3 = new Web3(provider);
                            return { success: true, address: accounts[0] };
                        } catch (error) {
                            return { success: false, error: error.message };
                        }
                    }
                    return await connectWalletConnect();
                """
            },
            'coinbase': {
                'extension_id': 'hnfanknocfeofbddgcijnmhnfnkdnaad',
                'detection_script': "return typeof window.ethereum !== 'undefined' && window.ethereum.isCoinbaseWallet",
                'connect_script': """
                    async function connectCoinbase() {
                        try {
                            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
                            return { success: true, address: accounts[0] };
                        } catch (error) {
                            return { success: false, error: error.message };
                        }
                    }
                    return await connectCoinbase();
                """
            }
        }
    
    def detect_wallet_connection_method(self, recording_id):
        """
        Analyze recording to detect wallet connection method used
        
        Args:
            recording_id: ID of the recording to analyze
            
        Returns:
            dict: Wallet connection information
        """
        recording = TaskRecording.query.get(recording_id)
        if not recording:
            logger.error(f"Recording {recording_id} not found")
            return None
        
        try:
            # Load DOM snapshots and actions
            dom_snapshots = json.loads(recording.dom_snapshots)
            actions = json.loads(recording.actions)
            
            # Look for wallet connection patterns in the DOM
            wallet_info = {
                'wallet_detected': False,
                'wallet_type': None,
                'network': None,
                'connection_method': None,
                'api_based': False,
                'web3_functions': []
            }
            
            # Check DOM snapshots for wallet connection elements
            for snapshot in dom_snapshots:
                html = base64.b64decode(snapshot.get('html', '')).decode('utf-8', errors='ignore')
                
                # Check for wallet-related keywords
                if any(w in html.lower() for w in ['connect wallet', 'connect to a wallet', 'sign in with ethereum']):
                    wallet_info['wallet_detected'] = True
                
                # Check for specific wallet providers
                for wallet_type in self.wallet_types:
                    if wallet_type.lower() in html.lower():
                        wallet_info['wallet_type'] = wallet_type
                
                # Check for network information
                for network in self.supported_networks:
                    if network.lower() in html.lower() or self.supported_networks[network]['name'].lower() in html.lower():
                        wallet_info['network'] = network
                
                # Check for Web3 functions
                web3_functions = []
                if 'web3.eth.contract' in html or 'ethers.Contract' in html:
                    web3_functions.append('smart_contract_interaction')
                if 'web3.eth.getBalance' in html or 'eth_getBalance' in html:
                    web3_functions.append('balance_check')
                if 'eth_sendTransaction' in html or 'send(' in html:
                    web3_functions.append('transaction')
                if 'estimateGas' in html:
                    web3_functions.append('gas_estimation')
                if 'sign' in html.lower() and ('message' in html.lower() or 'transaction' in html.lower()):
                    web3_functions.append('signing')
                
                wallet_info['web3_functions'] = web3_functions
            
            # Check network requests for API-based wallet connections
            network_requests = json.loads(recording.network_requests)
            for request in network_requests:
                if 'method' in request and request['method'] in ['eth_requestAccounts', 'eth_accounts', 'connect']:
                    wallet_info['api_based'] = True
                    wallet_info['connection_method'] = 'api'
                    break
            
            # If no API calls detected, it's likely using UI elements
            if not wallet_info['connection_method']:
                wallet_info['connection_method'] = 'ui'
            
            return wallet_info
        
        except Exception as e:
            logger.exception(f"Error detecting wallet connection method: {str(e)}")
            return None
    
    def execute_wallet_task(self, task_id, account_id):
        """
        Execute a wallet-related task
        
        Args:
            task_id: ID of the task to execute
            account_id: ID of the account to use
            
        Returns:
            bool: Success flag
        """
        try:
            task = Task.query.get(task_id)
            account = Account.query.get(account_id)
            
            if not task or not account:
                logger.error(f"Task {task_id} or account {account_id} not found")
                return False
            
            # Get airdrop and task parameters
            airdrop = Airdrop.query.get(task.airdrop_id)
            if not airdrop:
                logger.error(f"Airdrop {task.airdrop_id} not found")
                return False
            
            try:
                task_params = json.loads(task.params)
            except:
                task_params = {}
            
            # Find recording for this airdrop
            recording = TaskRecording.query.filter_by(airdrop_id=airdrop.id).first()
            
            if not recording:
                logger.error(f"No recording found for airdrop {airdrop.id}")
                return False
            
            # Analyze recording for wallet information
            wallet_info = self.detect_wallet_connection_method(recording.id)
            
            if not wallet_info or not wallet_info['wallet_detected']:
                logger.error("No wallet connection detected in recording")
                return False
            
            # Execute based on connection method
            if wallet_info['connection_method'] == 'api' and wallet_info['api_based']:
                return self._execute_wallet_task_api(task, task_params, account, airdrop, wallet_info, recording)
            else:
                return self._execute_wallet_task_ui(task, task_params, account, airdrop, wallet_info, recording)
            
        except Exception as e:
            logger.exception(f"Error executing wallet task {task_id}: {str(e)}")
            
            # Record execution result
            execution = TaskExecution()
            execution.task_id = task_id
            execution.account_id = account_id
            execution.status = 'error'
            execution.details = f"Error: {str(e)}"
            execution.execution_time = 0.0
            execution.started_at = datetime.utcnow()
            execution.completed_at = datetime.utcnow()
            
            db.session.add(execution)
            db.session.commit()
            
            return False
    
    def _execute_wallet_task_api(self, task, task_params, account, airdrop, wallet_info, recording):
        """Execute wallet task using API approach"""
        try:
            logger.info(f"Executing wallet task {task.id} via API")
            
            # Get recorded network requests for this task
            network_requests = json.loads(recording.network_requests)
            actions = json.loads(recording.actions)
            
            # Find wallet connection request
            wallet_requests = [r for r in network_requests 
                             if any(method in str(r) for method in 
                                   ['eth_requestAccounts', 'eth_accounts', 'connect'])]
            
            if not wallet_requests:
                logger.error("No wallet connection requests found in recording")
                return False
            
            # Extract request details
            wallet_request = wallet_requests[0]
            request_data = wallet_request.get('request', {})
            request_url = request_data.get('url', '')
            request_method = request_data.get('method', 'POST')
            request_headers = request_data.get('headers', {})
            request_body = request_data.get('post_data', '{}')
            
            # Update request for account-specific data
            try:
                body_data = json.loads(request_body)
                
                # Some common parameters that might need to be updated
                # with account-specific values would go here
                
                request_body = json.dumps(body_data)
            except:
                pass
            
            # Make the wallet connection request
            logger.info(f"Making wallet connection request to {request_url}")
            response = requests.request(
                request_method,
                request_url,
                headers=request_headers,
                data=request_body,
                timeout=30
            )
            
            # Process the response
            if response.status_code >= 400:
                logger.error(f"Wallet connection request failed with status {response.status_code}")
                logger.error(f"Response: {response.text}")
                return False
            
            logger.info(f"Wallet connection response: {response.status_code}")
            
            # Execute follow-up actions if needed
            if task.task_type == 'wallet_connect':
                # For simple connection, we're done
                self._record_successful_execution(task, account)
                return True
            
            elif task.task_type == 'wallet_transaction':
                # Execute transaction
                return self._execute_wallet_transaction(task, task_params, account, airdrop, wallet_info, recording)
            
            elif task.task_type == 'wallet_swap':
                # Execute token swap
                return self._execute_token_swap(task, task_params, account, airdrop, wallet_info, recording)
            
            elif task.task_type == 'wallet_bridge':
                # Execute token bridge
                return self._execute_token_bridge(task, task_params, account, airdrop, wallet_info, recording)
            
            # Default success
            self._record_successful_execution(task, account)
            return True
            
        except Exception as e:
            logger.exception(f"Error in _execute_wallet_task_api: {str(e)}")
            return False
    
    def _execute_wallet_task_ui(self, task, task_params, account, airdrop, wallet_info, recording):
        """Execute wallet task using UI approach (via browser automation)"""
        try:
            logger.info(f"Executing wallet task {task.id} via UI")
            
            # For UI-based tasks, we'll need to use a browser automation helper
            from automation import get_chrome_options
            from selenium import webdriver
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support.ui import WebDriverWait
            from selenium.webdriver.support import expected_conditions as EC
            
            # Setup browser with wallet extension
            chrome_options = get_chrome_options()
            
            # Add wallet extension if available
            wallet_type = wallet_info.get('wallet_type') or task_params.get('wallet_type', 'metamask')
            if wallet_type in self.wallet_types and 'extension_id' in self.wallet_types[wallet_type]:
                extension_path = f"wallet_extensions/{wallet_type}"
                if os.path.exists(extension_path):
                    chrome_options.add_extension(extension_path)
            
            # Start browser
            driver = webdriver.Chrome(options=chrome_options)
            
            try:
                # Navigate to airdrop URL
                driver.get(airdrop.url)
                
                # Wait for page to load
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.TAG_NAME, "body"))
                )
                
                # Detect wallet button
                wallet_button = None
                wallet_button_selectors = [
                    "//button[contains(text(), 'Connect Wallet')]",
                    "//button[contains(text(), 'Connect')]",
                    "//div[contains(text(), 'Connect Wallet')]",
                    "//a[contains(text(), 'Connect Wallet')]",
                    "//button[contains(@class, 'wallet')]",
                    "//div[contains(@class, 'wallet-connect')]"
                ]
                
                for selector in wallet_button_selectors:
                    try:
                        wallet_button = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((By.XPATH, selector))
                        )
                        break
                    except:
                        continue
                
                if not wallet_button:
                    logger.error("Could not find wallet connect button")
                    
                    # Try using JavaScript injection as a fallback
                    if wallet_type in self.wallet_types and 'connect_script' in self.wallet_types[wallet_type]:
                        logger.info(f"Trying to connect using JavaScript injection for {wallet_type}")
                        result = driver.execute_script(self.wallet_types[wallet_type]['connect_script'])
                        
                        if result and result.get('success'):
                            logger.info(f"Successfully connected to {wallet_type} via JavaScript")
                            # Continue with task specific actions
                            self._execute_wallet_specific_task(driver, task, task_params, account, wallet_info)
                            self._record_successful_execution(task, account)
                            return True
                    
                    return False
                
                # Click wallet connect button
                wallet_button.click()
                
                # Wait for wallet selection (if multiple options)
                time.sleep(2)
                
                # Check for wallet options
                wallet_options = driver.find_elements(By.XPATH, 
                                                     f"//div[contains(text(), '{wallet_type}')]")
                
                if wallet_options:
                    # Click the correct wallet option
                    wallet_options[0].click()
                    time.sleep(2)
                
                # Handle wallet popup (extension)
                # Switch to newest window (extension popup)
                original_window = driver.current_window_handle
                for window_handle in driver.window_handles:
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)
                        break
                
                # Check if on extension page
                if 'extension' in driver.current_url or wallet_type.lower() in driver.current_url.lower():
                    # Handle extension-specific connection approval
                    if wallet_type == 'metamask':
                        # Look for "Next" and "Connect" buttons
                        next_button = driver.find_elements(By.XPATH, "//button[contains(text(), 'Next')]")
                        if next_button:
                            next_button[0].click()
                            time.sleep(1)
                        
                        connect_button = driver.find_elements(By.XPATH, "//button[contains(text(), 'Connect')]")
                        if connect_button:
                            connect_button[0].click()
                            time.sleep(1)
                    
                    elif wallet_type == 'phantom':
                        # Look for "Connect" button
                        connect_button = driver.find_elements(By.XPATH, "//button[contains(text(), 'Connect')]")
                        if connect_button:
                            connect_button[0].click()
                            time.sleep(1)
                
                # Switch back to main window
                driver.switch_to.window(original_window)
                
                # Execute task-specific actions
                success = self._execute_wallet_specific_task(driver, task, task_params, account, wallet_info)
                
                if success:
                    self._record_successful_execution(task, account)
                    return True
                else:
                    return False
                
            finally:
                # Close browser
                driver.quit()
            
        except Exception as e:
            logger.exception(f"Error in _execute_wallet_task_ui: {str(e)}")
            return False
    
    def _execute_wallet_specific_task(self, driver, task, task_params, account, wallet_info):
        """Execute task-specific wallet actions in the browser"""
        try:
            if task.task_type == 'wallet_connect':
                # For simple connection, we're done
                return True
            
            elif task.task_type == 'wallet_transaction':
                # Look for transaction confirm button
                confirm_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Confirm') or contains(text(), 'Submit') or contains(text(), 'Sign')]"))
                )
                confirm_button.click()
                
                # Handle wallet confirmation popup
                original_window = driver.current_window_handle
                time.sleep(2)
                
                for window_handle in driver.window_handles:
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)
                        break
                
                # Look for confirmation button in wallet popup
                confirm_buttons = driver.find_elements(By.XPATH, 
                                                      "//button[contains(text(), 'Confirm') or contains(text(), 'Sign') or contains(text(), 'Approve')]")
                
                if confirm_buttons:
                    confirm_buttons[0].click()
                    time.sleep(2)
                
                # Switch back to main window
                driver.switch_to.window(original_window)
                
                # Wait for transaction to be processed
                time.sleep(5)
                
                return True
            
            elif task.task_type == 'wallet_swap':
                # Handle token swap UI
                amount_input = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, "//input[contains(@class, 'amount') or contains(@placeholder, 'Amount')]"))
                )
                
                # Set amount (use small value for testing)
                amount = task_params.get('amount', '0.001')
                amount_input.clear()
                amount_input.send_keys(str(amount))
                
                # Find swap button
                swap_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Swap') or contains(text(), 'Trade') or contains(text(), 'Exchange')]"))
                )
                swap_button.click()
                
                # Handle confirmation
                confirm_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Confirm') or contains(text(), 'Swap now')]"))
                )
                confirm_button.click()
                
                # Handle wallet confirmation (similar to transaction)
                original_window = driver.current_window_handle
                time.sleep(2)
                
                for window_handle in driver.window_handles:
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)
                        break
                
                # Look for confirmation button in wallet popup
                confirm_buttons = driver.find_elements(By.XPATH, 
                                                     "//button[contains(text(), 'Confirm') or contains(text(), 'Sign') or contains(text(), 'Approve')]")
                
                if confirm_buttons:
                    confirm_buttons[0].click()
                    time.sleep(2)
                
                # Switch back to main window
                driver.switch_to.window(original_window)
                
                # Wait for swap to complete
                time.sleep(10)
                
                return True
            
            elif task.task_type == 'wallet_bridge':
                # Handle token bridging UI
                
                # Input the amount
                amount_input = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, "//input[contains(@class, 'amount') or contains(@placeholder, 'Amount')]"))
                )
                
                # Set amount (use small value for testing)
                amount = task_params.get('amount', '0.001')
                amount_input.clear()
                amount_input.send_keys(str(amount))
                
                # Look for destination network selection if needed
                if 'destination_network' in task_params:
                    dest_network = task_params['destination_network']
                    network_dropdown = driver.find_elements(By.XPATH, 
                                                          "//div[contains(@class, 'network') or contains(@class, 'chain')]")
                    
                    if network_dropdown:
                        network_dropdown[0].click()
                        time.sleep(1)
                        
                        # Select destination network
                        network_option = driver.find_elements(By.XPATH, 
                                                            f"//div[contains(text(), '{dest_network}')]")
                        if network_option:
                            network_option[0].click()
                            time.sleep(1)
                
                # Find bridge/transfer button
                bridge_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Bridge') or contains(text(), 'Transfer') or contains(text(), 'Send')]"))
                )
                bridge_button.click()
                
                # Handle confirmation
                confirm_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Confirm') or contains(text(), 'Proceed')]"))
                )
                confirm_button.click()
                
                # Handle wallet confirmation (similar to transaction)
                original_window = driver.current_window_handle
                time.sleep(2)
                
                for window_handle in driver.window_handles:
                    if window_handle != original_window:
                        driver.switch_to.window(window_handle)
                        break
                
                # Look for confirmation button in wallet popup
                confirm_buttons = driver.find_elements(By.XPATH, 
                                                     "//button[contains(text(), 'Confirm') or contains(text(), 'Sign') or contains(text(), 'Approve')]")
                
                if confirm_buttons:
                    confirm_buttons[0].click()
                    time.sleep(2)
                
                # Switch back to main window
                driver.switch_to.window(original_window)
                
                # Wait for bridging to start (it may take a while to complete)
                time.sleep(10)
                
                return True
            
            # Default handler for other wallet tasks
            return True
            
        except Exception as e:
            logger.exception(f"Error in _execute_wallet_specific_task: {str(e)}")
            return False
    
    def _execute_wallet_transaction(self, task, task_params, account, airdrop, wallet_info, recording):
        """Execute wallet transaction via API"""
        # This is a placeholder that would need to be customized heavily based on the actual API
        logger.info("Wallet transaction API execution not fully implemented")
        return False
    
    def _execute_token_swap(self, task, task_params, account, airdrop, wallet_info, recording):
        """Execute token swap via API"""
        # This is a placeholder that would need to be customized heavily based on the actual API
        logger.info("Token swap API execution not fully implemented")
        return False
    
    def _execute_token_bridge(self, task, task_params, account, airdrop, wallet_info, recording):
        """Execute token bridge via API"""
        # This is a placeholder that would need to be customized heavily based on the actual API
        logger.info("Token bridge API execution not fully implemented")
        return False
    
    def _record_successful_execution(self, task, account):
        """Record successful task execution"""
        execution = TaskExecution()
        execution.task_id = task.id
        execution.account_id = account.id
        execution.status = 'success'
        execution.details = f"Successfully executed wallet task"
        execution.execution_time = 5.0  # Estimate
        execution.started_at = datetime.utcnow()
        execution.completed_at = datetime.utcnow()
        
        db.session.add(execution)
        
        # Update task status
        task.status = 'completed'
        
        db.session.commit()

# Create a function to execute wallet tasks
def execute_wallet_task(task_id, account_id):
    """
    Execute a wallet-related task
    
    Args:
        task_id: ID of the task to execute
        account_id: ID of the account to use
        
    Returns:
        bool: Success flag
    """
    automator = Web3Automator()
    return automator.execute_wallet_task(task_id, account_id)