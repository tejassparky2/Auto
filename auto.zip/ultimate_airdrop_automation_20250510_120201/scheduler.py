import logging
import time
import threading
import schedule
from datetime import datetime, timedelta

from app import db
from models import AirdropSchedule, TaskExecution, Task, Account
import airdrop_manager
import notifications

logger = logging.getLogger(__name__)

# Global flag for controlling the scheduler thread
running = False
thread = None

def setup_scheduler():
    """Configure jobs in the scheduler"""
    # Set up the scheduler with various recurring jobs
    schedule.every(1).minutes.do(execute_pending_tasks)
    schedule.every(10).minutes.do(refresh_scheduled_airdrops)
    schedule.every(1).hour.do(clear_stale_tasks)
    schedule.every(4).hours.do(check_accounts_status)
    
    logger.info("Scheduler configured successfully")

def start_scheduler():
    """Start the scheduler in a background thread"""
    global running, thread
    
    if running:
        logger.warning("Scheduler already running")
        return False
    
    running = True
    thread = threading.Thread(target=run_scheduler)
    thread.daemon = True  # Allow Python to exit even if the thread is running
    thread.start()
    
    logger.info("Scheduler started")
    return True

def stop_scheduler():
    """Stop the scheduler thread"""
    global running
    
    if not running:
        logger.warning("Scheduler not running")
        return False
    
    running = False
    logger.info("Scheduler stopping (may take up to a minute to fully stop)")
    return True

def run_scheduler():
    """Main scheduler loop"""
    setup_scheduler()
    
    logger.info("Scheduler thread running")
    
    while running:
        try:
            schedule.run_pending()
        except Exception as e:
            logger.error(f"Error in scheduler: {str(e)}")
        
        # Sleep for a bit to avoid high CPU usage
        time.sleep(30)
    
    logger.info("Scheduler thread stopped")

def execute_pending_tasks():
    """Execute tasks that are queued and ready for execution"""
    try:
        logger.info("Checking for pending tasks")
        
        # Get tasks that are queued for execution
        executions = TaskExecution.query.filter_by(status='queued').all()
        
        if not executions:
            logger.info("No pending tasks found")
            return
        
        logger.info(f"Found {len(executions)} pending task executions")
        
        # Execute each task
        for execution in executions:
            try:
                task = Task.query.get(execution.task_id)
                account = Account.query.get(execution.account_id)
                
                if not task or not account:
                    logger.error(f"Cannot find task {execution.task_id} or account {execution.account_id}")
                    execution.status = 'failed'
                    execution.result = "Task or account not found"
                    db.session.commit()
                    continue
                
                # Update status to in_progress
                execution.status = 'in_progress'
                execution.started_at = datetime.utcnow()
                db.session.commit()
                
                # Execute the task
                logger.info(f"Executing task {task.id} with account {account.id}")
                
                # Get the best strategy
                from learning import get_best_strategy
                strategy = get_best_strategy(task.task_type, account.platform)
                
                # Execute the task
                from automation import execute_task
                start_time = time.time()
                result = execute_task(task.task_type, task.get_params(), account, strategy)
                execution_time = time.time() - start_time
                
                # Update execution record
                execution.completed_at = datetime.utcnow()
                execution.set_result(result)
                execution.status = 'completed' if result.get('success', False) else 'failed'
                
                # Create task history
                history = TaskHistory()
                history.task_id = task.id
                history.account_id = account.id
                history.status = 'success' if result.get('success', False) else 'failed'
                history.details = result.get('details', '')
                history.execution_time = execution_time
                db.session.add(history)
                
                # Update task status
                if result.get('success', False):
                    task.status = 'completed'
                    # Send notification for task completion
                    notifications.on_task_completed(task.id, account.id, result.get('details', ''))
                else:
                    # Increment retry count
                    task.retry_count += 1
                    
                    if task.retry_count >= task.max_retries:
                        task.status = 'failed'
                    else:
                        task.status = 'pending'
                    
                    # Send notification for task failure
                    notifications.on_task_failed(
                        task.id, account.id, result.get('details', ''),
                        task.retry_count, task.max_retries
                    )
                
                db.session.commit()
                logger.info(f"Task execution {execution.id} completed with status: {execution.status}")
                
            except Exception as e:
                logger.exception(f"Error executing task {execution.task_id}: {str(e)}")
                
                # Update execution record
                execution.status = 'failed'
                execution.completed_at = datetime.utcnow()
                execution.set_result({"success": False, "details": f"Error: {str(e)}"})
                
                db.session.commit()
                
                # Attempt to update task status
                try:
                    task = Task.query.get(execution.task_id)
                    if task:
                        task.retry_count += 1
                        if task.retry_count >= task.max_retries:
                            task.status = 'failed'
                        else:
                            task.status = 'pending'
                        
                        db.session.commit()
                except Exception as inner_e:
                    logger.error(f"Error updating task status: {str(inner_e)}")
    
    except Exception as e:
        logger.exception(f"Error in execute_pending_tasks: {str(e)}")

def refresh_scheduled_airdrops():
    """Refresh the scheduled airdrops and queue tasks for execution"""
    try:
        logger.info("Refreshing scheduled airdrops")
        
        # Get active schedules that are due
        now = datetime.utcnow()
        active_schedules = AirdropSchedule.query.filter_by(active=True).all()
        
        for schedule_item in active_schedules:
            try:
                # Check if this schedule is due to run
                if schedule_item.next_run and schedule_item.next_run <= now:
                    logger.info(f"Processing scheduled airdrop {schedule_item.airdrop_id}")
                    
                    # Get airdrop
                    from models import Airdrop
                    airdrop = Airdrop.query.get(schedule_item.airdrop_id)
                    
                    if not airdrop:
                        logger.error(f"Cannot find airdrop {schedule_item.airdrop_id}")
                        schedule_item.active = False
                        db.session.commit()
                        continue
                    
                    # Distribute airdrop to accounts
                    success, message = airdrop_manager.distribute_airdrop_to_accounts(
                        schedule_item.airdrop_id, 
                        replicate=False  # Don't replicate tasks to all accounts
                    )
                    
                    if success:
                        logger.info(f"Successfully distributed airdrop {airdrop.id}: {message}")
                    else:
                        logger.warning(f"Failed to distribute airdrop {airdrop.id}: {message}")
                    
                    # Update schedule
                    schedule_item.last_run = now
                    schedule_item.calculate_next_run()
                    db.session.commit()
            
            except Exception as e:
                logger.error(f"Error processing schedule {schedule_item.id}: {str(e)}")
        
        logger.info("Scheduled airdrops refresh completed")
    
    except Exception as e:
        logger.exception(f"Error in refresh_scheduled_airdrops: {str(e)}")

def clear_stale_tasks():
    """Clear out stale tasks and executions (stuck in in_progress state)"""
    try:
        logger.info("Clearing stale tasks")
        
        # Consider tasks stuck in in_progress for over 6 hours as stale
        stale_cutoff = datetime.utcnow() - timedelta(hours=6)
        
        # Find stale executions
        stale_executions = TaskExecution.query.filter_by(
            status='in_progress'
        ).filter(TaskExecution.started_at < stale_cutoff).all()
        
        if not stale_executions:
            logger.info("No stale task executions found")
            return
        
        logger.info(f"Found {len(stale_executions)} stale task executions")
        
        # Mark stale executions as failed
        for execution in stale_executions:
            execution.status = 'failed'
            execution.set_result({
                "success": False, 
                "details": "Task execution timed out (stale)"
            })
            
            # Try to update the associated task
            task = Task.query.get(execution.task_id)
            if task:
                task.retry_count += 1
                if task.retry_count >= task.max_retries:
                    task.status = 'failed'
                else:
                    task.status = 'pending'
        
        db.session.commit()
        logger.info(f"Cleared {len(stale_executions)} stale task executions")
    
    except Exception as e:
        logger.exception(f"Error in clear_stale_tasks: {str(e)}")

def check_accounts_status():
    """Check the status of accounts to detect issues (locked, rate limited, etc.)"""
    try:
        logger.info("Checking accounts status")
        
        # For now, just log that we're checking
        # In a real implementation, you'd check the status of each account
        # by making test API calls or checking for error patterns
        
        logger.info("Accounts status check completed")
    
    except Exception as e:
        logger.exception(f"Error in check_accounts_status: {str(e)}")

def schedule_airdrop(airdrop_id, user_id, start_time=None, end_time=None, repeat_type='once'):
    """
    Schedule an airdrop for execution
    
    Args:
        airdrop_id: ID of the airdrop to schedule
        user_id: ID of the user who owns the airdrop
        start_time: When to start executing the airdrop (datetime)
        end_time: When to stop executing the airdrop (datetime)
        repeat_type: How often to repeat ('once', 'daily', 'weekly', 'monthly')
    
    Returns:
        AirdropSchedule object
    """
    try:
        # Create new schedule
        schedule_item = AirdropSchedule()
        schedule_item.airdrop_id = airdrop_id
        schedule_item.user_id = user_id
        schedule_item.start_time = start_time or datetime.utcnow()
        schedule_item.end_time = end_time
        schedule_item.repeat_type = repeat_type
        schedule_item.active = True
        
        # Calculate initial next_run
        schedule_item.calculate_next_run()
        
        db.session.add(schedule_item)
        db.session.commit()
        
        logger.info(f"Scheduled airdrop {airdrop_id} with repeat type {repeat_type}")
        return schedule_item
    
    except Exception as e:
        logger.exception(f"Error scheduling airdrop {airdrop_id}: {str(e)}")
        return None

# Import needed for TaskHistory
from models import TaskHistory