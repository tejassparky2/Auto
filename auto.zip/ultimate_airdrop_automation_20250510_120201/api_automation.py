import logging
import json
import time
import os
import hashlib
import re
import copy
from datetime import datetime
import requests
from urllib.parse import urlparse, urljoin

from app import db
from models import Account, Airdrop, Task, TaskExecution, TaskRecording

logger = logging.getLogger(__name__)

class APIAutomator:
    """
    Advanced API-based automation that prioritizes direct API calls and cookie auth
    over UI interaction for more reliable execution across different websites.
    """
    
    def __init__(self):
        self.session = requests.Session()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': 'https://example.com',
            'Referer': 'https://example.com/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Connection': 'keep-alive',
        }
        self.token_patterns = {
            'bearer': r'bearer\s+([a-zA-Z0-9\-_.+/=]+)',
            'jwt': r'eyJ[a-zA-Z0-9\-_.+/=]+',
            'api_key': r'[\'"]?api_key[\'"]?\s*[=:]\s*[\'"]([a-zA-Z0-9\-_.+/=]+)[\'"]',
            'access_token': r'[\'"]?access_token[\'"]?\s*[=:]\s*[\'"]([a-zA-Z0-9\-_.+/=]+)[\'"]',
            'csrf': r'csrf[\'"]?\s*[=:]\s*[\'"]([a-zA-Z0-9\-_.+/=]+)[\'"]'
        }
    
    def extract_network_data(self, recording_id):
        """
        Extract valuable network data from a recording
        """
        recording = TaskRecording.query.get(recording_id)
        if not recording:
            logger.error(f"Recording {recording_id} not found")
            return None
        
        try:
            # Load data
            network_requests = json.loads(recording.network_requests)
            cookies = json.loads(recording.cookies)
            local_storage = json.loads(recording.local_storage)
            actions = json.loads(recording.actions)
            
            # Extract API requests
            api_calls = [a for a in actions if a.get('type') == 'api_request']
            
            # Identify authentication-related calls
            auth_calls = []
            auth_tokens = {}
            auth_cookies = []
            
            # Extract authentication tokens and cookies
            for call in api_calls:
                url = call.get('url', '')
                
                # Check if this looks like an authentication endpoint
                is_auth_endpoint = any(term in url.lower() for term in 
                                     ['auth', 'login', 'token', 'session', 'signin'])
                
                if is_auth_endpoint:
                    auth_calls.append(call)
                    
                    # Extract tokens from response headers
                    headers = call.get('headers', {})
                    for header_name, header_value in headers.items():
                        for token_name, pattern in self.token_patterns.items():
                            matches = re.findall(pattern, str(header_value), re.IGNORECASE)
                            if matches:
                                auth_tokens[token_name] = matches[0]
                    
                    # Look for tokens in request data
                    data = call.get('data', '')
                    for token_name, pattern in self.token_patterns.items():
                        matches = re.findall(pattern, str(data), re.IGNORECASE)
                        if matches:
                            auth_tokens[token_name] = matches[0]
            
            # Extract auth-related cookies
            auth_cookie_names = ['token', 'auth', 'session', 'jwt', 'id', 'user', 'sid']
            for cookie in cookies:
                name = cookie.get('name', '').lower()
                if any(auth_name in name for auth_name in auth_cookie_names):
                    auth_cookies.append(cookie)
            
            # Extract auth data from localStorage
            auth_storage = {}
            for key, value in local_storage.items():
                if any(auth_name in key.lower() for auth_name in auth_cookie_names + ['token', 'bearer']):
                    auth_storage[key] = value
            
            return {
                'api_calls': api_calls,
                'auth_calls': auth_calls,
                'auth_tokens': auth_tokens,
                'auth_cookies': auth_cookies,
                'auth_storage': auth_storage,
                'cookies': cookies
            }
        
        except Exception as e:
            logger.exception(f"Error extracting network data: {str(e)}")
            return None
    
    def replay_api_requests(self, recording_id, account_id):
        """
        Replay recorded API requests using cookie/token authentication
        
        Args:
            recording_id: ID of the recording to replay
            account_id: ID of the account to use
            
        Returns:
            bool: Success flag
        """
        try:
            # Get account and recording
            account = Account.query.get(account_id)
            if not account:
                logger.error(f"Account {account_id} not found")
                return False
            
            # Extract network data
            network_data = self.extract_network_data(recording_id)
            if not network_data:
                logger.error("Failed to extract network data")
                return False
            
            # Start fresh session
            self.session = requests.Session()
            
            # Set cookies from recording
            for cookie in network_data['cookies']:
                domain = cookie.get('domain', '')
                if domain.startswith('.'):
                    domain = domain[1:]
                    
                self.session.cookies.set(
                    name=cookie.get('name'),
                    value=cookie.get('value'),
                    domain=domain,
                    path=cookie.get('path', '/')
                )
            
            # Replay authentication calls first
            auth_successful = self._replay_auth_calls(network_data, account)
            if not auth_successful:
                logger.warning("Authentication replay may not have been successful")
            
            # Replay task-specific API calls
            airdrop_id = TaskRecording.query.get(recording_id).airdrop_id
            tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
            
            for task in tasks:
                task_type = task.task_type
                try:
                    task_params = json.loads(task.params)
                except:
                    task_params = {}
                
                success = self._execute_task_via_api(task_type, task_params, network_data, account)
                
                # Record execution result
                execution = TaskExecution()
                execution.task_id = task.id
                execution.account_id = account_id
                execution.status = 'success' if success else 'failure'
                execution.details = "Executed via API" if success else "API execution failed"
                execution.execution_time = 1.0  # API calls are typically fast
                execution.started_at = datetime.utcnow()
                execution.completed_at = datetime.utcnow()
                
                db.session.add(execution)
            
            db.session.commit()
            logger.info(f"Replayed API requests for recording {recording_id} with account {account_id}")
            return True
            
        except Exception as e:
            logger.exception(f"Error replaying API requests: {str(e)}")
            db.session.rollback()
            return False
    
    def _replay_auth_calls(self, network_data, account):
        """Replay authentication API calls"""
        try:
            for auth_call in network_data.get('auth_calls', []):
                url = auth_call.get('url')
                method = auth_call.get('method', 'GET')
                headers = auth_call.get('headers', {})
                data = auth_call.get('data', '')
                
                # Update headers
                request_headers = copy.deepcopy(self.headers)
                request_headers.update(headers)
                
                # Check if we need to substitute account credentials
                if data:
                    # Check if this looks like a login request
                    is_login = any(term in data.lower() for term in ['username', 'email', 'password', 'login'])
                    
                    if is_login:
                        # Try to parse the data
                        try:
                            # For JSON data
                            if 'application/json' in headers.get('Content-Type', ''):
                                data_dict = json.loads(data)
                                
                                # Look for username/email/password fields
                                for field in ['username', 'email', 'user', 'login']:
                                    if field in data_dict:
                                        data_dict[field] = account.username
                                
                                if 'password' in data_dict:
                                    data_dict['password'] = account.password
                                
                                data = json.dumps(data_dict)
                            
                            # For form data
                            elif 'application/x-www-form-urlencoded' in headers.get('Content-Type', ''):
                                from urllib.parse import parse_qs, urlencode
                                data_dict = parse_qs(data)
                                
                                # Look for username/email/password fields
                                for field in ['username', 'email', 'user', 'login']:
                                    if field in data_dict:
                                        data_dict[field] = [account.username]
                                
                                if 'password' in data_dict:
                                    data_dict['password'] = [account.password]
                                
                                data = urlencode(data_dict, doseq=True)
                        
                        except Exception as parse_error:
                            logger.error(f"Error parsing auth data: {str(parse_error)}")
                
                # Make the request
                try:
                    if method == 'GET':
                        response = self.session.get(url, headers=request_headers, timeout=10)
                    elif method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    elif method == 'PUT':
                        response = self.session.put(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    # Check for authentication tokens in response
                    response_text = response.text
                    for token_name, pattern in self.token_patterns.items():
                        matches = re.findall(pattern, response_text, re.IGNORECASE)
                        if matches:
                            # Store token in headers for future requests
                            if token_name == 'bearer' or token_name == 'jwt':
                                self.headers['Authorization'] = f"Bearer {matches[0]}"
                            else:
                                # Store in session for later use
                                self.session.token_data = self.session.token_data if hasattr(self.session, 'token_data') else {}
                                self.session.token_data[token_name] = matches[0]
                    
                    # For JSON responses, look for tokens
                    try:
                        json_response = response.json()
                        for key, value in json_response.items():
                            if any(token_term in key.lower() for token_term in ['token', 'auth', 'jwt', 'access']):
                                # Store in session
                                self.session.token_data = self.session.token_data if hasattr(self.session, 'token_data') else {}
                                self.session.token_data[key] = value
                                
                                # If it looks like a bearer token, set the header
                                if isinstance(value, str) and len(value) > 20:
                                    self.headers['Authorization'] = f"Bearer {value}"
                    except:
                        pass
                    
                except Exception as request_error:
                    logger.error(f"Error making auth request to {url}: {str(request_error)}")
            
            # Consider auth successful if we have cookies or tokens
            return len(self.session.cookies) > 0 or (hasattr(self.session, 'token_data') and len(self.session.token_data) > 0)
        
        except Exception as e:
            logger.exception(f"Error replaying auth calls: {str(e)}")
            return False
    
    def _execute_task_via_api(self, task_type, task_params, network_data, account):
        """Execute a specific task via API"""
        try:
            # Match the task to an API call
            api_calls = network_data.get('api_calls', [])
            
            # Different task types require different API call patterns
            if task_type.startswith('twitter_'):
                return self._execute_twitter_task(task_type, task_params, api_calls, account)
            elif task_type.startswith('discord_'):
                return self._execute_discord_task(task_type, task_params, api_calls, account)
            elif task_type.startswith('telegram_'):
                return self._execute_telegram_task(task_type, task_params, api_calls, account)
            elif task_type.startswith('website_'):
                return self._execute_website_task(task_type, task_params, api_calls, account)
            else:
                logger.warning(f"Unknown task type for API execution: {task_type}")
                return False
        
        except Exception as e:
            logger.exception(f"Error executing task {task_type} via API: {str(e)}")
            return False
    
    def _execute_twitter_task(self, task_type, task_params, api_calls, account):
        """Execute Twitter tasks via API"""
        try:
            # Find Twitter API calls
            twitter_calls = [call for call in api_calls if 'twitter.com' in call.get('url', '') or 'x.com' in call.get('url', '')]
            
            if not twitter_calls:
                logger.warning("No Twitter API calls found in recording")
                return False
            
            if task_type == 'twitter_follow':
                username = task_params.get('username')
                if not username:
                    return False
                
                # Find follow API call
                follow_calls = [call for call in twitter_calls if 'follow' in call.get('url', '').lower()]
                
                if follow_calls:
                    # Replay the follow API call
                    follow_call = follow_calls[0]
                    url = follow_call.get('url')
                    method = follow_call.get('method', 'POST')
                    headers = follow_call.get('headers', {})
                    data = follow_call.get('data', '')
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            elif task_type == 'twitter_like':
                tweet_link = task_params.get('tweet_link')
                tweet_id = task_params.get('tweet_id')
                
                if not tweet_id and tweet_link:
                    # Extract tweet ID from link
                    tweet_id = tweet_link.split('/status/')[1].split('?')[0].split('/')[0]
                
                if not tweet_id:
                    return False
                
                # Find like API call
                like_calls = [call for call in twitter_calls if 'like' in call.get('url', '').lower()]
                
                if like_calls:
                    # Replay the like API call
                    like_call = like_calls[0]
                    url = like_call.get('url')
                    method = like_call.get('method', 'POST')
                    headers = like_call.get('headers', {})
                    data = like_call.get('data', '')
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            elif task_type == 'twitter_retweet':
                tweet_link = task_params.get('tweet_link')
                tweet_id = task_params.get('tweet_id')
                
                if not tweet_id and tweet_link:
                    # Extract tweet ID from link
                    tweet_id = tweet_link.split('/status/')[1].split('?')[0].split('/')[0]
                
                if not tweet_id:
                    return False
                
                # Find retweet API call
                retweet_calls = [call for call in twitter_calls if 'retweet' in call.get('url', '').lower()]
                
                if retweet_calls:
                    # Replay the retweet API call
                    retweet_call = retweet_calls[0]
                    url = retweet_call.get('url')
                    method = retweet_call.get('method', 'POST')
                    headers = retweet_call.get('headers', {})
                    data = retweet_call.get('data', '')
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            else:
                logger.warning(f"Unknown Twitter task type: {task_type}")
                return False
        
        except Exception as e:
            logger.exception(f"Error executing Twitter task {task_type}: {str(e)}")
            return False
    
    def _execute_discord_task(self, task_type, task_params, api_calls, account):
        """Execute Discord tasks via API"""
        try:
            # Find Discord API calls
            discord_calls = [call for call in api_calls if 'discord.com' in call.get('url', '')]
            
            if not discord_calls:
                logger.warning("No Discord API calls found in recording")
                return False
            
            if task_type == 'discord_join':
                invite_code = task_params.get('invite_code')
                invite_link = task_params.get('invite_link')
                
                if not invite_code and invite_link:
                    # Extract invite code from link
                    if 'discord.gg/' in invite_link:
                        invite_code = invite_link.split('discord.gg/')[1].split('?')[0].split('/')[0]
                    elif '/invite/' in invite_link:
                        invite_code = invite_link.split('/invite/')[1].split('?')[0].split('/')[0]
                
                if not invite_code:
                    return False
                
                # Find join API call
                join_calls = [call for call in discord_calls if '/invites/' in call.get('url', '').lower()]
                
                if join_calls:
                    # Replay the join API call
                    join_call = join_calls[0]
                    url = join_call.get('url')
                    method = join_call.get('method', 'POST')
                    headers = join_call.get('headers', {})
                    data = join_call.get('data', '')
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Make sure we're using the correct invite code
                    url = f"https://discord.com/api/v9/invites/{invite_code}"
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            elif task_type == 'discord_message':
                channel_id = task_params.get('channel_id')
                message_text = task_params.get('message_text')
                
                if not channel_id or not message_text:
                    return False
                
                # Find message API call
                message_calls = [call for call in discord_calls if '/messages' in call.get('url', '').lower()]
                
                if message_calls:
                    # Replay the message API call
                    message_call = message_calls[0]
                    url = message_call.get('url')
                    method = message_call.get('method', 'POST')
                    headers = message_call.get('headers', {})
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Make sure we're using the correct channel ID and message
                    url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
                    data = json.dumps({"content": message_text})
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            else:
                logger.warning(f"Unknown Discord task type: {task_type}")
                return False
        
        except Exception as e:
            logger.exception(f"Error executing Discord task {task_type}: {str(e)}")
            return False
    
    def _execute_telegram_task(self, task_type, task_params, api_calls, account):
        """Execute Telegram tasks via API"""
        try:
            # Telegram doesn't have a public API for joining groups
            # Most of these actions would be UI-based, but we can try
            # to identify any API calls that might be useful
            
            # Find Telegram-related API calls
            telegram_calls = [call for call in api_calls if 't.me' in call.get('url', '')]
            
            if not telegram_calls:
                logger.warning("No Telegram API calls found in recording")
                return False
            
            # Most Telegram web interactions require a UI, so we'll just try to
            # replay any API calls we found
            for call in telegram_calls:
                url = call.get('url')
                method = call.get('method', 'GET')
                headers = call.get('headers', {})
                data = call.get('data', '')
                
                # Update headers
                request_headers = copy.deepcopy(self.headers)
                request_headers.update(headers)
                
                # Make the request
                try:
                    if method == 'GET':
                        response = self.session.get(url, headers=request_headers, timeout=10)
                    elif method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                except Exception as req_error:
                    logger.error(f"Error making Telegram request: {str(req_error)}")
            
            # Since we can't reliably automate Telegram via API, we'll consider this a best-effort
            return True
        
        except Exception as e:
            logger.exception(f"Error executing Telegram task {task_type}: {str(e)}")
            return False
    
    def _execute_website_task(self, task_type, task_params, api_calls, account):
        """Execute website-specific tasks via API"""
        try:
            url = task_params.get('url')
            if not url:
                return False
            
            # Parse domain
            domain = urlparse(url).netloc
            
            # Find API calls to this domain
            domain_calls = [call for call in api_calls if domain in call.get('url', '')]
            
            if not domain_calls:
                logger.warning(f"No API calls found for domain {domain}")
                return False
            
            if task_type == 'website_signup' or task_type == 'website_form':
                form_data = task_params.get('form_data', {})
                
                # Find form submission API calls (usually POST requests)
                form_calls = [call for call in domain_calls if call.get('method', '').upper() == 'POST']
                
                if form_calls:
                    # Replay the form submission API call
                    form_call = form_calls[0]
                    url = form_call.get('url')
                    method = form_call.get('method', 'POST')
                    headers = form_call.get('headers', {})
                    data = form_call.get('data', '')
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Update form data with account info if needed
                    if task_type == 'website_signup':
                        try:
                            # For JSON data
                            if 'application/json' in headers.get('Content-Type', ''):
                                data_dict = json.loads(data)
                                
                                # Replace email/username/password fields
                                for field in data_dict:
                                    field_lower = field.lower()
                                    if 'email' in field_lower:
                                        data_dict[field] = account.email or account.username
                                    elif 'user' in field_lower or 'name' in field_lower:
                                        data_dict[field] = account.username
                                    elif 'pass' in field_lower:
                                        data_dict[field] = account.password
                                
                                data = json.dumps(data_dict)
                            
                            # For form data
                            elif 'application/x-www-form-urlencoded' in headers.get('Content-Type', ''):
                                from urllib.parse import parse_qs, urlencode
                                data_dict = parse_qs(data)
                                
                                # Replace email/username/password fields
                                for field in list(data_dict.keys()):
                                    field_lower = field.lower()
                                    if 'email' in field_lower:
                                        data_dict[field] = [account.email or account.username]
                                    elif 'user' in field_lower or 'name' in field_lower:
                                        data_dict[field] = [account.username]
                                    elif 'pass' in field_lower:
                                        data_dict[field] = [account.password]
                                
                                data = urlencode(data_dict, doseq=True)
                        
                        except Exception as parse_error:
                            logger.error(f"Error parsing form data: {str(parse_error)}")
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            elif task_type == 'website_wallet':
                wallet_type = task_params.get('wallet_type')
                
                # Find wallet connection API calls
                wallet_calls = [call for call in domain_calls 
                              if any(term in call.get('url', '').lower() for term in ['wallet', 'connect', 'web3', 'eth'])]
                
                if wallet_calls:
                    # Replay the wallet connection API call
                    wallet_call = wallet_calls[0]
                    url = wallet_call.get('url')
                    method = wallet_call.get('method', 'POST')
                    headers = wallet_call.get('headers', {})
                    data = wallet_call.get('data', '')
                    
                    # Update headers
                    request_headers = copy.deepcopy(self.headers)
                    request_headers.update(headers)
                    
                    # Make the request
                    if method == 'POST':
                        response = self.session.post(url, headers=request_headers, data=data, timeout=10)
                    else:
                        response = self.session.request(method, url, headers=request_headers, data=data, timeout=10)
                    
                    return response.status_code < 400
                
                return False
            
            else:
                logger.warning(f"Unknown website task type: {task_type}")
                return False
        
        except Exception as e:
            logger.exception(f"Error executing website task {task_type}: {str(e)}")
            return False
    
    def extract_tokens_from_page(self, html_content):
        """Extract authentication tokens from a page"""
        tokens = {}
        
        # Look for tokens in the HTML
        for token_name, pattern in self.token_patterns.items():
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            if matches:
                tokens[token_name] = matches[0]
        
        # Look for JSON data that might contain tokens
        json_pattern = r'<script[^>]*>\s*(?:window\.)?([\w.]+)\s*=\s*({.+?})\s*</script>'
        json_matches = re.findall(json_pattern, html_content, re.DOTALL)
        
        for var_name, json_str in json_matches:
            try:
                data = json.loads(json_str)
                self._extract_tokens_from_json(data, tokens)
            except:
                pass
        
        return tokens
    
    def _extract_tokens_from_json(self, data, tokens, prefix=''):
        """Recursively extract tokens from JSON data"""
        if isinstance(data, dict):
            for key, value in data.items():
                full_key = f"{prefix}.{key}" if prefix else key
                
                # Check if this key looks like a token
                if any(token_term in full_key.lower() for token_term in ['token', 'auth', 'jwt', 'access']):
                    if isinstance(value, str) and len(value) > 10:
                        tokens[full_key] = value
                
                # Recurse into nested objects
                if isinstance(value, (dict, list)):
                    self._extract_tokens_from_json(value, tokens, full_key)
        
        elif isinstance(data, list):
            for i, item in enumerate(data):
                full_key = f"{prefix}[{i}]" if prefix else f"[{i}]"
                if isinstance(item, (dict, list)):
                    self._extract_tokens_from_json(item, tokens, full_key)

# Create a function to execute airdrop using API automation
def execute_airdrop_api(airdrop_id, account_id=None):
    """
    Execute airdrop tasks using API automation
    
    Args:
        airdrop_id: ID of the airdrop to execute
        account_id: Optional ID of the account to use (if None, find the best account)
        
    Returns:
        bool: Success flag
    """
    try:
        from models import Airdrop, Account, Task, TaskRecording
        
        # Get airdrop
        airdrop = Airdrop.query.get(airdrop_id)
        if not airdrop:
            logger.error(f"Airdrop {airdrop_id} not found")
            return False
        
        # Get or find account
        if account_id:
            account = Account.query.get(account_id)
            if not account:
                logger.error(f"Account {account_id} not found")
                return False
        else:
            # Find best account - one that has been used for this airdrop before
            recording = TaskRecording.query.filter_by(airdrop_id=airdrop_id).first()
            if recording:
                account = Account.query.get(recording.account_id)
            else:
                # Or just get any account
                account = Account.query.filter_by(user_id=airdrop.user_id).first()
            
            if not account:
                logger.error(f"No account found for airdrop {airdrop_id}")
                return False
        
        # Find existing recording
        recording = TaskRecording.query.filter_by(airdrop_id=airdrop_id).first()
        
        if not recording:
            logger.warning(f"No recording found for airdrop {airdrop_id}, can't use API automation")
            return False
        
        # Use the recording to replay API requests
        automator = APIAutomator()
        success = automator.replay_api_requests(recording.id, account.id)
        
        # Update airdrop status
        if success:
            airdrop.status = 'completed'
        else:
            airdrop.status = 'failed'
        
        db.session.commit()
        
        return success
    
    except Exception as e:
        logger.exception(f"Error executing airdrop {airdrop_id} via API: {str(e)}")
        db.session.rollback()
        return False