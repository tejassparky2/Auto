/**
 * Airdrop Automation Tool
 * Charts for visualizing statistics
 */

let platformChart = null;
let taskTypeChart = null;

document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
});

/**
 * Initialize all charts on the statistics page
 */
function initializeCharts() {
    initializePlatformChart();
    initializeTaskTypeChart();
}

/**
 * Initialize platform success rate chart
 */
function initializePlatformChart() {
    const platformChartCanvas = document.getElementById('platform-chart');
    if (!platformChartCanvas) return;

    // Get chart data from the data attributes
    const labels = JSON.parse(platformChartCanvas.dataset.labels || '[]');
    const data = JSON.parse(platformChartCanvas.dataset.data || '[]');
    
    if (platformChart) {
        platformChart.destroy();
    }
    
    platformChart = new Chart(platformChartCanvas, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Success Rate (%)',
                data: data,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(153, 102, 255, 0.7)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Success Rate (%)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Platform'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Success rate: ${context.parsed.y.toFixed(1)}%`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize task type success rate chart
 */
function initializeTaskTypeChart() {
    const taskTypeChartCanvas = document.getElementById('task-type-chart');
    if (!taskTypeChartCanvas) return;

    // Get chart data from the data attributes
    const labels = JSON.parse(taskTypeChartCanvas.dataset.labels || '[]');
    const data = JSON.parse(taskTypeChartCanvas.dataset.data || '[]');
    
    if (taskTypeChart) {
        taskTypeChart.destroy();
    }
    
    taskTypeChart = new Chart(taskTypeChartCanvas, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)',
                    'rgba(201, 203, 207, 0.7)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(201, 203, 207, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.parsed.toFixed(1)}%`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize task success trend chart
 */
function initializeSuccessTrendChart() {
    const trendChartCanvas = document.getElementById('success-trend-chart');
    if (!trendChartCanvas) return;

    // This would typically get data from an API
    // For now we'll use some sample data
    const dates = Array.from({length: 10}, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - i);
        return date.toLocaleDateString('en-US', {month: 'short', day: 'numeric'});
    }).reverse();
    
    const successRates = [65, 70, 68, 72, 75, 80, 78, 82, 85, 88];
    
    new Chart(trendChartCanvas, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Success Rate Trend',
                data: successRates,
                fill: false,
                borderColor: 'rgba(75, 192, 192, 1)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Success Rate (%)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    }
                }
            }
        }
    });
}

/**
 * Update chart data
 */
function updateChartData(chartInstance, labels, data) {
    if (!chartInstance) return;
    
    chartInstance.data.labels = labels;
    chartInstance.data.datasets[0].data = data;
    chartInstance.update();
}
