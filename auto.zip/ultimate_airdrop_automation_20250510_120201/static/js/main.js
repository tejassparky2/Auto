/**
 * Airdrop Automation Tool
 * Main JavaScript functionality for the web interface
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips and popovers
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    
    const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
    const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));
    
    // Setup event handlers
    setupEventHandlers();
    
    // Load initial data for dashboard if on the index page
    if (document.querySelector('#dashboard-summary')) {
        loadDashboardData();
    }
    
    // Load task details if on the airdrops page and an airdrop is selected
    const airdropDetails = document.querySelector('#airdrop-details');
    if (airdropDetails && airdropDetails.dataset.airdropId) {
        loadAirdropTasks(airdropDetails.dataset.airdropId);
    }
});

/**
 * Setup event handlers for various interactions
 */
function setupEventHandlers() {
    // Handle account form password toggle
    const passwordToggles = document.querySelectorAll('.password-toggle');
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordField = document.querySelector(this.dataset.target);
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                this.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                passwordField.type = 'password';
                this.innerHTML = '<i class="fas fa-eye"></i>';
            }
        });
    });
    
    // Handle airdrop selection for viewing details
    const airdropItems = document.querySelectorAll('.airdrop-item');
    airdropItems.forEach(item => {
        item.addEventListener('click', function() {
            const airdropId = this.dataset.airdropId;
            loadAirdropTasks(airdropId);
            
            // Update active state
            airdropItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            
            // Update details section
            const detailsSection = document.querySelector('#airdrop-details');
            if (detailsSection) {
                detailsSection.dataset.airdropId = airdropId;
                detailsSection.querySelector('.airdrop-name').textContent = this.dataset.airdropName;
                detailsSection.querySelector('.airdrop-url').textContent = this.dataset.airdropUrl;
                detailsSection.querySelector('.airdrop-url').href = this.dataset.airdropUrl;
            }
        });
    });
    
    // Handle execute airdrop button
    const executeButtons = document.querySelectorAll('.execute-airdrop');
    executeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const airdropId = this.dataset.airdropId;
            executeAirdrop(airdropId);
        });
    });
    
    // Handle delete confirmation
    const deleteConfirmButtons = document.querySelectorAll('.delete-confirm');
    deleteConfirmButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetForm = document.querySelector(this.dataset.target);
            if (targetForm) {
                targetForm.submit();
            }
        });
    });
}

/**
 * Load dashboard summary data
 */
function loadDashboardData() {
    // This would typically make an API call to get real-time data
    // For now we'll use the data already rendered in the page
    updateDashboardCharts();
}

/**
 * Load tasks for a specific airdrop
 */
function loadAirdropTasks(airdropId) {
    const tasksContainer = document.querySelector('#tasks-container');
    if (!tasksContainer) return;
    
    // Show loading indicator
    tasksContainer.innerHTML = '<div class="text-center my-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';
    
    // Fetch tasks from API
    fetch(`/api/tasks/${airdropId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load tasks');
            }
            return response.json();
        })
        .then(tasks => {
            renderTasks(tasks, tasksContainer);
        })
        .catch(error => {
            tasksContainer.innerHTML = `<div class="alert alert-danger" role="alert">Error: ${error.message}</div>`;
        });
}

/**
 * Render tasks in the container
 */
function renderTasks(tasks, container) {
    if (tasks.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No tasks found for this airdrop</div>';
        return;
    }
    
    let html = '';
    
    tasks.forEach(task => {
        const statusClass = getStatusClass(task.status);
        
        html += `
        <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="fas fa-tasks me-2"></i>${task.task_type}</span>
                <span class="badge ${statusClass}">${task.status}</span>
            </div>
            <div class="card-body">
                <p class="card-text">${task.description}</p>
                
                <div class="accordion" id="taskHistory${task.id}">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#history${task.id}">
                                Task History (${task.history.length})
                            </button>
                        </h2>
                        <div id="history${task.id}" class="accordion-collapse collapse" data-bs-parent="#taskHistory${task.id}">
                            <div class="accordion-body p-0">
                                <ul class="list-group list-group-flush">
        `;
        
        if (task.history.length === 0) {
            html += `<li class="list-group-item">No history records available</li>`;
        } else {
            task.history.forEach(h => {
                const historyStatusClass = h.status === 'success' ? 'text-success' : 'text-danger';
                html += `
                <li class="list-group-item">
                    <div class="d-flex justify-content-between">
                        <small>${h.timestamp}</small>
                        <span class="${historyStatusClass}">${h.status}</span>
                    </div>
                    <div><small class="text-muted">Account: ${h.account || 'N/A'}</small></div>
                    <div><small>${h.details || 'No details'}</small></div>
                </li>
                `;
            });
        }
        
        html += `
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;
    });
    
    container.innerHTML = html;
}

/**
 * Get Bootstrap class for status badges
 */
function getStatusClass(status) {
    switch(status) {
        case 'completed':
            return 'bg-success';
        case 'failed':
            return 'bg-danger';
        case 'in_progress':
            return 'bg-primary';
        case 'pending':
            return 'bg-warning';
        default:
            return 'bg-secondary';
    }
}

/**
 * Execute an airdrop
 */
function executeAirdrop(airdropId) {
    const button = document.querySelector(`.execute-airdrop[data-airdrop-id="${airdropId}"]`);
    if (button) {
        // Disable button and show spinner
        button.disabled = true;
        const originalText = button.innerHTML;
        button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Executing...';
        
        // Create a form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/airdrops/execute/${airdropId}`;
        document.body.appendChild(form);
        form.submit();
    }
}

/**
 * Update dashboard charts
 */
function updateDashboardCharts() {
    // This function would be implemented in charts.js
    if (typeof initializeCharts === 'function') {
        initializeCharts();
    }
}
