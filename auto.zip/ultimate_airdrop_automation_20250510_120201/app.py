import os
import logging
import time
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

# Create SQLAlchemy instance
db = SQLAlchemy(model_class=Base)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///airdrop.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize database
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Import models after db initialization to avoid circular imports
with app.app_context():
    import models
    from models import User, Account, Airdrop, Task, TaskHistory, NotificationSettings, ProxyServer
    db.create_all()

# Import other modules after models
import airdrop_manager
import automation
import scraper
import learning

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(models.User, int(user_id))

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        return render_template('index.html')
    else:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and password and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
        
        if existing_user:
            flash('Username or email already exists', 'danger')
            return render_template('register.html')
            
        # Create new user
        new_user = User()
        new_user.username = username
        new_user.email = email
        new_user.password_hash = generate_password_hash(password or "")
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

@app.route('/accounts')
@login_required
def accounts():
    user_accounts = Account.query.filter_by(user_id=current_user.id).all()
    return render_template('accounts.html', accounts=user_accounts)

@app.route('/accounts/add', methods=['POST'])
@login_required
def add_account():
    platform = request.form.get('platform')
    username = request.form.get('username')
    password = request.form.get('password')
    
    new_account = Account()
    new_account.user_id = current_user.id
    new_account.platform = platform
    new_account.username = username
    new_account.password = password
    
    db.session.add(new_account)
    db.session.commit()
    
    flash(f'Account {username} for {platform} added successfully', 'success')
    return redirect(url_for('accounts'))

@app.route('/accounts/delete/<int:account_id>', methods=['POST'])
@login_required
def delete_account(account_id):
    account = Account.query.filter_by(id=account_id, user_id=current_user.id).first()
    
    if not account:
        flash('Account not found', 'danger')
        return redirect(url_for('accounts'))
    
    db.session.delete(account)
    db.session.commit()
    
    flash('Account deleted successfully', 'success')
    return redirect(url_for('accounts'))

@app.route('/airdrops')
@login_required
def airdrops():
    user_airdrops = Airdrop.query.filter_by(user_id=current_user.id).all()
    return render_template('airdrops.html', airdrops=user_airdrops)

@app.route('/airdrops/add', methods=['POST'])
@login_required
def add_airdrop():
    name = request.form.get('name')
    url = request.form.get('url')
    
    # Create new airdrop
    new_airdrop = Airdrop()
    new_airdrop.user_id = current_user.id
    new_airdrop.name = name
    new_airdrop.url = url
    new_airdrop.status = 'pending'
    
    db.session.add(new_airdrop)
    db.session.commit()
    
    # Analyze airdrop URL and create tasks
    try:
        airdrop_manager.analyze_airdrop(new_airdrop.id)
        flash(f'Airdrop {name} added successfully and analyzed', 'success')
    except Exception as e:
        flash(f'Airdrop added but analysis failed: {str(e)}', 'warning')
    
    return redirect(url_for('airdrops'))

@app.route('/airdrops/delete/<int:airdrop_id>', methods=['POST'])
@login_required
def delete_airdrop(airdrop_id):
    airdrop = Airdrop.query.filter_by(id=airdrop_id, user_id=current_user.id).first()
    
    if not airdrop:
        flash('Airdrop not found', 'danger')
        return redirect(url_for('airdrops'))
    
    # Delete associated tasks first
    Task.query.filter_by(airdrop_id=airdrop_id).delete()
    
    db.session.delete(airdrop)
    db.session.commit()
    
    flash('Airdrop deleted successfully', 'success')
    return redirect(url_for('airdrops'))

@app.route('/airdrops/distribute/<int:airdrop_id>', methods=['POST'])
@login_required
def distribute_airdrop(airdrop_id):
    """
    Distribute airdrop tasks across multiple accounts
    """
    airdrop = Airdrop.query.filter_by(id=airdrop_id, user_id=current_user.id).first()
    
    if not airdrop:
        flash('Airdrop not found', 'danger')
        return redirect(url_for('airdrops'))
    
    # Get parameters
    replicate = request.form.get('replicate', 'false') == 'true'
    selected_accounts = request.form.getlist('account_ids')
    account_ids = [int(id) for id in selected_accounts] if selected_accounts else None
    
    # Distribute airdrop tasks to accounts
    try:
        success, message = airdrop_manager.distribute_airdrop_to_accounts(
            airdrop_id, 
            account_ids=account_ids, 
            replicate=replicate
        )
        
        if success:
            flash(message, 'success')
        else:
            flash(f'Failed to distribute airdrop: {message}', 'danger')
    except Exception as e:
        flash(f'Error during airdrop distribution: {str(e)}', 'danger')
    
    return redirect(url_for('airdrops'))

@app.route('/airdrops/execute/<int:airdrop_id>', methods=['POST'])
@login_required
def execute_airdrop(airdrop_id):
    """
    Execute an airdrop directly (all tasks)
    """
    airdrop = Airdrop.query.filter_by(id=airdrop_id, user_id=current_user.id).first()
    
    if not airdrop:
        flash('Airdrop not found', 'danger')
        return redirect(url_for('airdrops'))
    
    # Get specific account ID if provided
    account_id = request.form.get('account_id', None)
    if account_id:
        account_id = int(account_id)
        # Verify account belongs to user
        account = Account.query.filter_by(id=account_id, user_id=current_user.id).first()
        if not account:
            flash('Invalid account selected', 'danger')
            return redirect(url_for('airdrops'))
    
    # Get execution method
    execution_method = request.form.get('execution_method', 'browser')
    
    # Start airdrop execution in background
    try:
        if execution_method == 'api':
            # Try API-based execution first (using cookies, tokens, direct API calls)
            import api_automation
            success = api_automation.execute_airdrop_api(airdrop_id, account_id)
            
            if success:
                flash('Airdrop executed successfully via API automation', 'success')
            else:
                # Fall back to browser automation if API fails
                flash('API execution failed, falling back to browser automation', 'warning')
                airdrop_manager.execute_airdrop(airdrop_id, account_id=account_id)
                flash('Airdrop execution started via browser automation', 'success')
        else:
            # Standard browser-based execution
            airdrop_manager.execute_airdrop(airdrop_id, account_id=account_id)
            flash('Airdrop execution started via browser automation', 'success')
    except Exception as e:
        flash(f'Failed to start airdrop execution: {str(e)}', 'danger')
    
    return redirect(url_for('airdrops'))

@app.route('/tasks/execute/<int:task_id>', methods=['POST'])
@login_required
def execute_single_task(task_id):
    """
    Execute a single task with a specific account
    """
    # Get task and verify ownership
    task = Task.query.join(Airdrop).filter(
        Task.id == task_id, 
        Airdrop.user_id == current_user.id
    ).first()
    
    if not task:
        flash('Task not found or you do not have permission to execute it', 'danger')
        return redirect(url_for('airdrops'))
    
    # Get account ID
    account_id = request.form.get('account_id')
    if not account_id:
        flash('No account selected for task execution', 'danger')
        return redirect(url_for('airdrops'))
    
    # Verify account belongs to user
    account = Account.query.filter_by(id=int(account_id), user_id=current_user.id).first()
    if not account:
        flash('Invalid account selected', 'danger')
        return redirect(url_for('airdrops'))
    
    # Execute task
    try:
        # Get strategy 
        strategy = learning.get_best_strategy(task.task_type, account.platform)
        
        # Update task status
        task.status = 'in_progress'
        db.session.commit()
        
        # Execute task
        start_time = time.time()
        result = automation.execute_task(task.task_type, task.get_params(), account, strategy)
        execution_time = time.time() - start_time
        
        # Record history
        history = TaskHistory()
        history.task_id = task.id
        history.account_id = account.id
        history.status = 'success' if result['success'] else 'failed'
        history.details = result.get('details', '')
        history.execution_time = execution_time
        db.session.add(history)
        
        # Update task status
        if result['success']:
            task.status = 'completed'
            flash('Task executed successfully', 'success')
        else:
            task.status = 'failed'
            flash(f'Task execution failed: {result.get("details", "")}', 'danger')
        
        db.session.commit()
    except Exception as e:
        flash(f'Error executing task: {str(e)}', 'danger')
    
    return redirect(url_for('airdrops'))

@app.route('/statistics')
@login_required
def statistics():
    # Get task statistics for the current user
    tasks = Task.query.join(Airdrop).filter(Airdrop.user_id == current_user.id).all()
    
    # Get advanced analytics
    import analytics
    performance_metrics = analytics.get_user_performance_metrics(current_user.id, time_period='30d')
    
    # Get success rates by platform
    platform_data = {
        'labels': list(performance_metrics.get('platform_success_rates', {}).keys()),
        'success_rates': list(performance_metrics.get('platform_success_rates', {}).values())
    }
    
    # Get task type statistics
    task_type_data = {
        'labels': list(performance_metrics.get('task_type_success_rates', {}).keys()),
        'success_rates': list(performance_metrics.get('task_type_success_rates', {}).values())
    }
    
    # Get account performance data
    account_data = {
        'labels': list(performance_metrics.get('account_success_rates', {}).keys()),
        'success_rates': list(performance_metrics.get('account_success_rates', {}).values())
    }
    
    # Get time-based distribution data
    time_data = {
        'hourly': performance_metrics.get('hourly_distribution', {}),
        'daily': performance_metrics.get('daily_distribution', {})
    }
    
    # Get common errors
    common_errors = performance_metrics.get('common_errors', [])
    
    # Get overall stats
    overall_stats = {
        'total_executions': performance_metrics.get('total_executions', 0),
        'success_rate': performance_metrics.get('success_rate', 0),
        'avg_execution_time': performance_metrics.get('avg_execution_time', 0),
        'total_airdrops_completed': performance_metrics.get('total_airdrops_completed', 0),
        'total_tasks_completed': performance_metrics.get('total_tasks_completed', 0)
    }
    
    return render_template('statistics.html', 
                          platform_data=platform_data,
                          task_type_data=task_type_data,
                          account_data=account_data,
                          time_data=time_data,
                          common_errors=common_errors,
                          overall_stats=overall_stats)

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    # Get user's notification settings
    notification_settings = NotificationSettings.query.filter_by(user_id=current_user.id).first()
    
    # If no settings exist yet, create default settings
    if not notification_settings:
        notification_settings = NotificationSettings()
        notification_settings.user_id = current_user.id
        notification_settings.email_notifications = False
        notification_settings.telegram_notifications = False
        notification_settings.slack_notifications = False
        notification_settings.sms_notifications = False
        notification_settings.notification_level = 'important'
        db.session.add(notification_settings)
        db.session.commit()
    
    # Handle form submission
    if request.method == 'POST':
        # Update notification settings
        notification_settings.email_notifications = 'email_notifications' in request.form
        notification_settings.telegram_notifications = 'telegram_notifications' in request.form
        notification_settings.slack_notifications = 'slack_notifications' in request.form
        notification_settings.sms_notifications = 'sms_notifications' in request.form
        
        notification_settings.email = request.form.get('email')
        notification_settings.telegram_chat_id = request.form.get('telegram_chat_id')
        notification_settings.slack_webhook_url = request.form.get('slack_webhook_url')
        notification_settings.phone_number = request.form.get('phone_number')
        
        notification_settings.notification_level = request.form.get('notification_level', 'important')
        
        db.session.commit()
        flash('Settings updated successfully', 'success')
        return redirect(url_for('settings'))
    
    # Get a list of user's proxies
    proxies = ProxyServer.query.filter_by(user_id=current_user.id).all()
    
    return render_template('settings.html', 
                          notification_settings=notification_settings,
                          proxies=proxies)

@app.route('/discover-airdrops', methods=['GET', 'POST'])
@login_required
def discover_airdrops():
    """Discover new airdrops from various sources"""
    if request.method == 'POST':
        # Get discovery parameters
        keywords = request.form.get('keywords', '').split(',')
        keywords = [k.strip() for k in keywords if k.strip()]
        
        platforms = request.form.getlist('platforms')
        auto_add = 'auto_add' in request.form
        
        # Start discovery job
        import airdrop_discovery
        results = airdrop_discovery.start_discovery_job(
            current_user.id,
            auto_add=auto_add,
            keywords=keywords,
            platforms=platforms
        )
        
        if auto_add:
            # If auto-added, show summary
            flash(f"Discovered {results.get('discovered', 0)} airdrops. Added {results.get('added', 0)}, "
                  f"skipped {results.get('skipped', 0)}, failed {results.get('failed', 0)}.", 'success')
            return redirect(url_for('airdrops'))
        else:
            # If not auto-added, show list of discovered airdrops
            discovered_airdrops = results.get('airdrops', [])
            return render_template('discover_airdrops.html', 
                                  discovered=discovered_airdrops,
                                  keywords=','.join(keywords),
                                  platforms=platforms)
    
    # Default: show discovery form
    return render_template('discover_airdrops.html')

@app.route('/add-discovered-airdrops', methods=['POST'])
@login_required
def add_discovered_airdrops():
    """Add selected discovered airdrops"""
    # Get selected airdrop data
    selected_airdrops = []
    for key, value in request.form.items():
        if key.startswith('airdrop_') and value == 'on':
            airdrop_index = int(key.split('_')[1])
            airdrop_name = request.form.get(f'name_{airdrop_index}')
            airdrop_url = request.form.get(f'url_{airdrop_index}')
            airdrop_source = request.form.get(f'source_{airdrop_index}')
            
            if airdrop_name and airdrop_url:
                selected_airdrops.append({
                    'name': airdrop_name,
                    'url': airdrop_url,
                    'source': airdrop_source
                })
    
    if not selected_airdrops:
        flash('No airdrops selected', 'warning')
        return redirect(url_for('discover_airdrops'))
    
    # Add selected airdrops
    import airdrop_discovery
    results = airdrop_discovery.add_discovered_airdrops(selected_airdrops, current_user.id)
    
    flash(f"Added {results.get('added', 0)} airdrops, failed {results.get('failed', 0)}", 'success')
    return redirect(url_for('airdrops'))

@app.route('/proxies', methods=['GET', 'POST'])
@login_required
def proxies():
    """Manage proxy servers"""
    if request.method == 'POST':
        # Add new proxy
        proxy_type = request.form.get('proxy_type')
        ip_address = request.form.get('ip_address')
        port = request.form.get('port')
        username = request.form.get('username')
        password = request.form.get('password')
        country = request.form.get('country')
        
        if not ip_address or not port or not proxy_type:
            flash('IP address, port, and proxy type are required', 'danger')
            return redirect(url_for('proxies'))
        
        # Create new proxy
        proxy = ProxyServer()
        proxy.user_id = current_user.id
        proxy.ip_address = ip_address
        proxy.port = int(port)
        proxy.proxy_type = proxy_type
        proxy.username = username
        proxy.password = password
        proxy.country = country
        proxy.status = 'active'
        
        db.session.add(proxy)
        db.session.commit()
        
        flash('Proxy server added successfully', 'success')
        return redirect(url_for('proxies'))
    
    # Get list of proxies
    proxies = ProxyServer.query.filter_by(user_id=current_user.id).all()
    
    return render_template('proxies.html', proxies=proxies)

@app.route('/proxies/delete/<int:proxy_id>', methods=['POST'])
@login_required
def delete_proxy(proxy_id):
    """Delete a proxy server"""
    proxy = ProxyServer.query.filter_by(id=proxy_id, user_id=current_user.id).first()
    
    if not proxy:
        flash('Proxy server not found', 'danger')
        return redirect(url_for('proxies'))
    
    db.session.delete(proxy)
    db.session.commit()
    
    flash('Proxy server deleted successfully', 'success')
    return redirect(url_for('proxies'))

@app.route('/proxies/test/<int:proxy_id>', methods=['POST'])
@login_required
def test_proxy(proxy_id):
    """Test a proxy server connection"""
    proxy = ProxyServer.query.filter_by(id=proxy_id, user_id=current_user.id).first()
    
    if not proxy:
        flash('Proxy server not found', 'danger')
        return redirect(url_for('proxies'))
    
    try:
        # Test the proxy by making a request to a test URL
        import requests
        
        proxy_url = proxy.get_proxy_url()
        proxies = {
            'http': proxy_url,
            'https': proxy_url
        }
        
        start_time = time.time()
        response = requests.get('https://httpbin.org/ip', proxies=proxies, timeout=10)
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            # Update proxy status and speed
            proxy.status = 'active'
            proxy.speed = response_time * 1000  # Convert to ms
            proxy.last_checked = datetime.utcnow()
            db.session.commit()
            
            flash(f'Proxy test successful. Response time: {round(response_time * 1000, 2)}ms', 'success')
        else:
            proxy.status = 'error'
            proxy.last_checked = datetime.utcnow()
            db.session.commit()
            
            flash(f'Proxy test failed. Status code: {response.status_code}', 'danger')
    
    except Exception as e:
        proxy.status = 'error'
        proxy.last_checked = datetime.utcnow()
        db.session.commit()
        
        flash(f'Proxy test failed: {str(e)}', 'danger')
    
    return redirect(url_for('proxies'))

@app.route('/api/tasks/<int:airdrop_id>')
@login_required
def get_tasks(airdrop_id):
    airdrop = Airdrop.query.filter_by(id=airdrop_id, user_id=current_user.id).first()
    
    if not airdrop:
        return jsonify({'error': 'Airdrop not found'}), 404
    
    tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
    task_list = []
    
    for task in tasks:
        task_history = TaskHistory.query.filter_by(task_id=task.id).order_by(TaskHistory.timestamp.desc()).all()
        task_list.append({
            'id': task.id,
            'task_type': task.task_type,
            'description': task.description,
            'status': task.status,
            'history': [{'timestamp': h.timestamp.strftime('%Y-%m-%d %H:%M:%S'), 
                         'status': h.status, 
                         'account': db.session.get(Account, h.account_id).username if h.account_id else None,
                         'details': h.details} for h in task_history]
        })
    
    return jsonify(task_list)

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500
