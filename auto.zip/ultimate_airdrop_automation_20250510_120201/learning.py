import logging
import json
import time
from datetime import datetime, timedelta

from app import db
from models import TaskExecution, LearningData

logger = logging.getLogger(__name__)

def get_best_strategy(task_type, platform):
    """
    Get the best strategy for a given task type and platform based on historical data
    
    Args:
        task_type: Type of task (twitter_follow, discord_join, etc.)
        platform: Platform (twitter, discord, etc.)
    
    Returns:
        dict: Strategy parameters (wait times, selectors, etc.)
    """
    try:
        # Find the best strategy from learning data
        learning_data = LearningData.query.filter_by(
            task_type=task_type,
            platform=platform
        ).order_by(LearningData.success_rate.desc()).first()
        
        if learning_data and learning_data.strategy:
            try:
                strategy = json.loads(learning_data.strategy)
                logger.info(f"Found learned strategy for {task_type} on {platform} with {learning_data.success_rate*100:.1f}% success rate")
                return strategy
            except json.JSONDecodeError:
                logger.error(f"Error decoding strategy JSON for {task_type} on {platform}")
        
        # If no strategy found or error, use default
        return get_default_strategy(task_type, platform)
    
    except Exception as e:
        logger.exception(f"Error getting best strategy for {task_type} on {platform}: {str(e)}")
        return get_default_strategy(task_type, platform)

def get_default_strategy(task_type, platform):
    """
    Get default strategy for a given task type and platform
    """
    # Default strategies for different task types
    default_strategies = {
        'twitter': {
            'twitter_follow': {
                'wait_before_action': 2.0,
                'wait_after_action': 1.5,
                'random_delay': True,
                'delay_range': [0.5, 2.0],
                'retry_count': 3,
                'verify_success': True,
                'human_like_behavior': True,
                'scroll_before_action': True,
                'button_selectors': [
                    'button[data-testid="followButton"]',
                    'div[role="button"][data-testid="follow"]',
                    'div[data-testid="confirmationSheetConfirm"]'
                ]
            },
            'twitter_like': {
                'wait_before_action': 1.5,
                'wait_after_action': 1.0,
                'random_delay': True,
                'delay_range': [0.5, 1.5],
                'retry_count': 2,
                'verify_success': True,
                'button_selectors': [
                    'div[data-testid="like"]'
                ]
            },
            'twitter_retweet': {
                'wait_before_action': 2.0,
                'wait_after_action': 2.0,
                'random_delay': True,
                'delay_range': [1.0, 3.0],
                'retry_count': 3,
                'verify_success': True,
                'button_selectors': [
                    'div[data-testid="retweet"]',
                    'div[data-testid="retweetConfirm"]'
                ]
            },
            'twitter_comment': {
                'wait_before_action': 2.0,
                'wait_after_action': 2.0,
                'random_delay': True,
                'delay_range': [1.0, 3.0],
                'retry_count': 2,
                'verify_success': True,
                'input_selectors': [
                    'div[data-testid="tweetTextarea_0"]'
                ],
                'button_selectors': [
                    'div[data-testid="tweetButton"]'
                ],
                'comment_variations': [
                    "Great project! Looking forward to it.",
                    "Excited for this! Thanks for the opportunity.",
                    "Awesome! Can't wait to try it out.",
                    "This looks promising. Thanks for sharing.",
                    "Interesting project, following with interest!"
                ]
            }
        },
        'discord': {
            'discord_join': {
                'wait_before_action': 3.0,
                'wait_after_action': 5.0,
                'random_delay': True,
                'delay_range': [2.0, 8.0],
                'retry_count': 3,
                'verify_success': True,
                'captcha_detection': True,
                'button_selectors': [
                    'button[type="button"]',
                    'button.button-f2h6uQ.lookFilled-yCfaCM',
                    '.button-f2h6uQ'
                ]
            },
            'discord_message': {
                'wait_before_action': 2.0,
                'wait_after_action': 1.0,
                'random_delay': True,
                'delay_range': [1.0, 3.0],
                'retry_count': 2,
                'verify_success': True,
                'input_selectors': [
                    'div[role="textbox"]',
                    '.slateTextArea-27tjG0'
                ],
                'button_selectors': [
                    'button[aria-label="Send Message"]'
                ],
                'message_variations': [
                    "Hello! Just joined the server.",
                    "Hi everyone! Excited to be here.",
                    "Hello from the airdrop community!",
                    "Greetings! Looking forward to participating.",
                    "Hey! Thanks for the invite."
                ]
            }
        },
        'telegram': {
            'telegram_join': {
                'wait_before_action': 3.0,
                'wait_after_action': 3.0,
                'random_delay': True,
                'delay_range': [2.0, 5.0],
                'retry_count': 3,
                'verify_success': True,
                'button_selectors': [
                    'a.tgme_action_button_new',
                    'div.tgme_page_action'
                ]
            }
        },
        'website': {
            'website_signup': {
                'wait_before_action': 2.0,
                'wait_after_action': 5.0,
                'random_delay': True,
                'delay_range': [1.0, 3.0],
                'retry_count': 3,
                'verify_success': True,
                'detect_recaptcha': True,
                'form_fill_speed': 'medium',  # slow, medium, fast
                'common_field_mappings': {
                    'email': ['email', 'mail', 'e-mail', 'user_email'],
                    'username': ['username', 'user', 'login', 'user_login'],
                    'password': ['password', 'pass', 'pwd', 'user_password'],
                    'confirm_password': ['confirm_password', 'password_confirm', 'confirm_pwd']
                }
            },
            'website_form': {
                'wait_before_action': 2.0,
                'wait_after_action': 3.0,
                'random_delay': True,
                'delay_range': [1.0, 2.0],
                'retry_count': 2,
                'verify_success': True,
                'detect_recaptcha': True,
                'form_fill_speed': 'medium'
            }
        }
    }
    
    # Get platform defaults
    platform_defaults = default_strategies.get(platform, {})
    
    # Get task defaults
    task_defaults = platform_defaults.get(task_type, {})
    
    if not task_defaults:
        # If no specific defaults, use generic defaults
        task_defaults = {
            'wait_before_action': 2.0,
            'wait_after_action': 2.0,
            'random_delay': True,
            'delay_range': [1.0, 3.0],
            'retry_count': 3,
            'verify_success': True
        }
    
    logger.info(f"Using default strategy for {task_type} on {platform}")
    return task_defaults

def update_strategy(task_type, platform, success, execution_time, details):
    """
    Update the strategy based on task execution outcome
    
    Args:
        task_type: Type of task
        platform: Platform
        success: Whether the task was successful
        execution_time: Time taken to execute the task
        details: Details about the execution
    """
    try:
        # Find existing learning data
        learning_data = LearningData.query.filter_by(
            task_type=task_type,
            platform=platform
        ).first()
        
        if not learning_data:
            # Create new learning data
            learning_data = LearningData()
            learning_data.task_type = task_type
            learning_data.platform = platform
            learning_data.strategy = json.dumps(get_default_strategy(task_type, platform))
            learning_data.success_rate = 1.0 if success else 0.0
            learning_data.avg_execution_time = execution_time
            learning_data.common_errors = json.dumps([]) if success else json.dumps([analyze_error_patterns(details, task_type, platform)])
            learning_data.total_attempts = 1
            
            db.session.add(learning_data)
            db.session.commit()
            
            logger.info(f"Created new learning data for {task_type} on {platform}")
            return
        
        # Update existing learning data
        total_attempts = learning_data.total_attempts + 1
        success_count = int(learning_data.success_rate * learning_data.total_attempts) + (1 if success else 0)
        new_success_rate = success_count / total_attempts
        
        # Update average execution time with weighted average
        new_avg_execution_time = (learning_data.avg_execution_time * learning_data.total_attempts + execution_time) / total_attempts
        
        # Update common errors
        if not success:
            error_pattern = analyze_error_patterns(details, task_type, platform)
            try:
                common_errors = json.loads(learning_data.common_errors) if learning_data.common_errors else []
                common_errors.append(error_pattern)
                # Keep only last 10 errors
                if len(common_errors) > 10:
                    common_errors = common_errors[-10:]
            except json.JSONDecodeError:
                common_errors = [error_pattern]
            
            learning_data.common_errors = json.dumps(common_errors)
        
        # Update strategy based on execution outcome
        try:
            current_strategy = json.loads(learning_data.strategy) if learning_data.strategy else get_default_strategy(task_type, platform)
            common_errors = json.loads(learning_data.common_errors) if learning_data.common_errors else []
            
            # Adjust strategy
            new_strategy = adjust_strategy(current_strategy, new_success_rate, new_avg_execution_time, common_errors, total_attempts)
            learning_data.strategy = json.dumps(new_strategy)
        except json.JSONDecodeError:
            # Fallback if JSON is invalid
            learning_data.strategy = json.dumps(get_default_strategy(task_type, platform))
        
        # Update learning data
        learning_data.success_rate = new_success_rate
        learning_data.avg_execution_time = new_avg_execution_time
        learning_data.total_attempts = total_attempts
        learning_data.last_updated = datetime.utcnow()
        
        db.session.commit()
        
        logger.info(f"Updated learning data for {task_type} on {platform}. New success rate: {new_success_rate*100:.1f}%")
        
    except Exception as e:
        logger.exception(f"Error updating strategy for {task_type} on {platform}: {str(e)}")

def analyze_error_patterns(details, task_type, platform):
    """
    Analyze error patterns from task details
    """
    error_pattern = {
        'timestamp': datetime.utcnow().isoformat(),
        'task_type': task_type,
        'platform': platform,
        'error_category': 'unknown',
        'error_details': details
    }
    
    # Error categories
    error_categories = {
        'captcha': ['captcha', 'robot', 'verification', 'human'],
        'rate_limit': ['rate limit', 'too many requests', '429', 'try again later'],
        'login_failed': ['login failed', 'incorrect password', 'invalid credentials'],
        'element_not_found': ['element not found', 'no such element', 'could not locate element'],
        'connection': ['connection', 'timeout', 'network', 'proxy'],
        'blocked': ['blocked', 'banned', 'suspicious', 'unusual activity'],
        'js_error': ['javascript', 'script', 'undefined', 'null object']
    }
    
    details_lower = str(details).lower()
    
    # Categorize error
    for category, keywords in error_categories.items():
        if any(keyword in details_lower for keyword in keywords):
            error_pattern['error_category'] = category
            break
    
    return error_pattern

def adjust_strategy(current_strategy, success_rate, avg_execution_time, common_errors, total_attempts):
    """
    Adjust strategy based on success rate, execution time, and common errors
    """
    # Make a copy of the current strategy
    new_strategy = current_strategy.copy()
    
    # If high success rate, don't change too much
    if success_rate > 0.9 and total_attempts > 5:
        # Slightly optimize for speed
        if 'wait_before_action' in new_strategy and new_strategy['wait_before_action'] > 1.0:
            new_strategy['wait_before_action'] = max(1.0, new_strategy['wait_before_action'] * 0.9)
        
        if 'wait_after_action' in new_strategy and new_strategy['wait_after_action'] > 1.0:
            new_strategy['wait_after_action'] = max(1.0, new_strategy['wait_after_action'] * 0.9)
        
        return new_strategy
    
    # If very low success rate, make more significant changes
    if success_rate < 0.3 and total_attempts > 3:
        # Increase waits
        if 'wait_before_action' in new_strategy:
            new_strategy['wait_before_action'] = min(10.0, new_strategy['wait_before_action'] * 1.5)
        
        if 'wait_after_action' in new_strategy:
            new_strategy['wait_after_action'] = min(10.0, new_strategy['wait_after_action'] * 1.5)
        
        # Increase retry count
        if 'retry_count' in new_strategy:
            new_strategy['retry_count'] = min(5, new_strategy['retry_count'] + 1)
        
        # Analyze specific error patterns
        error_categories = [error.get('error_category', 'unknown') for error in common_errors if isinstance(error, dict)]
        category_counts = {}
        for category in error_categories:
            category_counts[category] = category_counts.get(category, 0) + 1
        
        most_common_error = max(category_counts.items(), key=lambda x: x[1])[0] if category_counts else None
        
        # Adjust based on most common error
        if most_common_error == 'captcha':
            new_strategy['human_like_behavior'] = True
            new_strategy['random_delay'] = True
            if 'delay_range' in new_strategy:
                new_strategy['delay_range'] = [
                    min(3.0, new_strategy['delay_range'][0] * 1.5),
                    min(8.0, new_strategy['delay_range'][1] * 1.5)
                ]
        
        elif most_common_error == 'rate_limit':
            if 'delay_range' in new_strategy:
                new_strategy['delay_range'] = [
                    min(5.0, new_strategy['delay_range'][0] * 2),
                    min(15.0, new_strategy['delay_range'][1] * 2)
                ]
        
        elif most_common_error == 'element_not_found':
            # Try alternative selectors
            platform_specific_updates = {
                'twitter': {
                    'twitter_follow': {
                        'button_selectors': [
                            'button[data-testid="followButton"]',
                            'div[role="button"][data-testid="follow"]',
                            '.css-1rynq56',
                            '.r-fmgk96',
                            '.r-1awozwy'
                        ]
                    }
                },
                'discord': {
                    'discord_join': {
                        'button_selectors': [
                            'button[type="button"]',
                            'button.button-f2h6uQ.lookFilled-yCfaCM',
                            '.button-f2h6uQ',
                            '.container-2Uhd9s',
                            '.actionButtons-2vEOUh button'
                        ]
                    }
                }
            }
            
            for platform, tasks in platform_specific_updates.items():
                for task_type, updates in tasks.items():
                    for key, value in updates.items():
                        if platform in new_strategy.get('platform', '') and task_type in new_strategy.get('task_type', ''):
                            new_strategy[key] = value
    
    return new_strategy

def learn_from_successful_tasks():
    """
    Analyze successful tasks to learn optimal strategies
    """
    try:
        # Get recent successful task executions
        recent_time = datetime.utcnow() - timedelta(days=7)
        successful_executions = TaskExecution.query.filter(
            TaskExecution.status == 'success',
            TaskExecution.completed_at > recent_time,
            TaskExecution.strategy_used.isnot(None)
        ).all()
        
        if not successful_executions:
            logger.info("No successful task executions to learn from")
            return
        
        # Group by task_type and analyze
        task_groups = {}
        for execution in successful_executions:
            task = execution.task
            if not task:
                continue
            
            key = f"{task.task_type}"
            if key not in task_groups:
                task_groups[key] = []
            
            try:
                # Extract platform from task type
                if 'twitter' in task.task_type:
                    platform = 'twitter'
                elif 'discord' in task.task_type:
                    platform = 'discord'
                elif 'telegram' in task.task_type:
                    platform = 'telegram'
                elif 'website' in task.task_type:
                    platform = 'website'
                else:
                    platform = 'unknown'
                
                # Add to group
                task_groups[key].append({
                    'execution_id': execution.id,
                    'task_id': task.id,
                    'task_type': task.task_type,
                    'platform': platform,
                    'execution_time': execution.execution_time,
                    'strategy_used': json.loads(execution.strategy_used) if execution.strategy_used else None
                })
            except (json.JSONDecodeError, AttributeError) as e:
                logger.error(f"Error processing execution {execution.id}: {str(e)}")
        
        # Analyze each group
        for task_type, executions in task_groups.items():
            if len(executions) < 3:
                continue
            
            # Group by platform
            platform_groups = {}
            for execution in executions:
                platform = execution.get('platform', 'unknown')
                if platform not in platform_groups:
                    platform_groups[platform] = []
                
                platform_groups[platform].append(execution)
            
            # Process each platform
            for platform, platform_executions in platform_groups.items():
                if len(platform_executions) < 3:
                    continue
                
                # Find execution with lowest time
                best_execution = min(platform_executions, key=lambda x: x.get('execution_time', float('inf')))
                best_strategy = best_execution.get('strategy_used')
                
                if not best_strategy:
                    continue
                
                # Update the learning data
                learning_data = LearningData.query.filter_by(
                    task_type=task_type,
                    platform=platform
                ).first()
                
                if not learning_data:
                    learning_data = LearningData()
                    learning_data.task_type = task_type
                    learning_data.platform = platform
                    learning_data.success_rate = 1.0
                    learning_data.avg_execution_time = best_execution.get('execution_time', 0)
                    learning_data.common_errors = json.dumps([])
                    learning_data.total_attempts = len(platform_executions)
                    learning_data.strategy = json.dumps(best_strategy)
                    
                    db.session.add(learning_data)
                else:
                    # Only update if new strategy is better
                    current_avg_time = learning_data.avg_execution_time
                    new_best_time = best_execution.get('execution_time', 0)
                    
                    if new_best_time < current_avg_time * 0.8:  # 20% improvement
                        logger.info(f"Found better strategy for {task_type} on {platform}: {new_best_time:.2f}s vs {current_avg_time:.2f}s")
                        
                        learning_data.strategy = json.dumps(best_strategy)
                        learning_data.avg_execution_time = (learning_data.avg_execution_time + new_best_time) / 2
                        learning_data.last_updated = datetime.utcnow()
            
        db.session.commit()
        logger.info(f"Updated learning data for {len(task_groups)} task types")
        
    except Exception as e:
        logger.exception(f"Error learning from successful tasks: {str(e)}")
        db.session.rollback()