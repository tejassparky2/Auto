import logging
import requests
from bs4 import BeautifulSoup
import re
import json
import time
from datetime import datetime
from urllib.parse import urlparse
from flask import current_app
import os

from app import db
from models import Airdrop, Task, Account, TaskHistory, TaskExecution
import scraper
import automation
import learning

logger = logging.getLogger(__name__)

# Task types and their detection patterns
TASK_PATTERNS = {
    # Twitter tasks
    'twitter_follow': [
        r'follow.*twitter',
        r'twitter.*follow',
        r'twitter\.com\/',
        r'https?:\/\/(www\.)?twitter\.com\/[a-zA-Z0-9_]+',
        r'follow.*(x\.com|twitter\.com)',
        r'follow.*(@\w+)',
        r'follow us on (twitter|x)'
    ],
    'twitter_retweet': [
        r'retweet',
        r'rt @',
        r'twitter.*retweet',
        r'retweet.*twitter',
        r'repost',
        r'share.*tweet',
        r'rt the (post|tweet)'
    ],
    'twitter_like': [
        r'like.*tweet',
        r'tweet.*like',
        r'like on twitter',
        r'like.*post.*(twitter|x)',
        r'like.*tweet.*(@\w+)'
    ],
    'twitter_comment': [
        r'comment.*tweet',
        r'reply.*tweet',
        r'leave.*comment.*(twitter|x)',
        r'comment.*(@\w+)'
    ],
    'twitter_quote': [
        r'quote.*tweet',
        r'quote.*retweet',
        r'quote.*with',
        r'quote.*and.*tag'
    ],
    
    # Discord tasks
    'discord_join': [
        r'join.*discord',
        r'discord.*join',
        r'discord\.gg\/',
        r'https?:\/\/(www\.)?discord\.gg\/[a-zA-Z0-9]+',
        r'join.*server',
        r'discord.*server'
    ],
    'discord_message': [
        r'send.*message.*discord',
        r'discord.*message',
        r'message in discord',
        r'type.*in.*channel',
        r'write.*in.*discord'
    ],
    'discord_react': [
        r'react.*message',
        r'add.*reaction',
        r'emoji.*message',
        r'react.*with.*emoji'
    ],
    'discord_verify': [
        r'verify.*discord',
        r'verification.*discord',
        r'get.*verified',
        r'click.*verify'
    ],
    
    # Telegram tasks
    'telegram_join': [
        r'join.*telegram',
        r'telegram.*join',
        r't\.me\/',
        r'https?:\/\/(www\.)?t\.me\/[a-zA-Z0-9_]+',
        r'join.*channel',
        r'join.*group'
    ],
    'telegram_message': [
        r'send.*message.*telegram',
        r'telegram.*message',
        r'message.*in.*telegram',
        r'type.*in.*telegram'
    ],
    
    # Website tasks
    'website_signup': [
        r'sign up',
        r'register',
        r'create.*account',
        r'sign.*up.*for',
        r'create.*profile',
        r'register.*on.*site'
    ],
    'website_form': [
        r'fill.*form',
        r'complete.*form',
        r'submit.*form',
        r'fill.*details',
        r'complete.*survey',
        r'fill.*out.*information'
    ],
    'website_kyc': [
        r'complete.*kyc',
        r'verify.*identity',
        r'kyc.*verification',
        r'submit.*kyc',
        r'identity.*verification'
    ],
    'website_quiz': [
        r'answer.*quiz',
        r'complete.*quiz',
        r'solve.*puzzle',
        r'answer.*question'
    ],
    
    # Email tasks
    'email_verification': [
        r'verify.*email',
        r'email.*verification',
        r'confirm.*email',
        r'click.*link.*email',
        r'check.*your.*email'
    ],
    
    # Wallet connection tasks
    'wallet_connect': [
        r'connect.*wallet',
        r'link.*wallet',
        r'connect.*(metamask|phantom|wallet)',
        r'wallet.*verification'
    ],
    'wallet_transaction': [
        r'make.*transaction',
        r'send.*token',
        r'transfer.*crypto',
        r'transaction.*required'
    ],
    
    # Referral tasks
    'referral_share': [
        r'share.*referral',
        r'invite.*friend',
        r'share.*link',
        r'spread.*word',
        r'referral.*program'
    ],
    
    # Social media general tasks
    'social_follow': [
        r'follow.*on.*(facebook|instagram|tiktok|youtube|linkedin)',
        r'like.*page',
        r'subscribe.*channel',
        r'follow.*us'
    ],
    'social_share': [
        r'share.*on.*(facebook|instagram|tiktok|youtube|linkedin)',
        r'share.*post',
        r'share.*with.*friend'
    ],
    'social_engage': [
        r'like.*post',
        r'comment.*post',
        r'engage.*with.*content',
        r'boost.*engagement'
    ]
}

def analyze_airdrop(airdrop_id):
    """
    Analyze an airdrop URL to identify required tasks using both pattern matching and AI
    """
    logger.info(f"Analyzing airdrop ID: {airdrop_id}")
    
    # Get the airdrop from database
    airdrop = db.session.get(Airdrop, airdrop_id)
    if not airdrop:
        logger.error(f"Airdrop ID {airdrop_id} not found")
        return False
    
    try:
        # Update airdrop status
        airdrop.status = 'analyzing'
        db.session.commit()
        
        # Fetch and parse the airdrop page
        url = airdrop.url
        domain = urlparse(url).netloc
        
        # Use the scraper to get the content
        page_content = scraper.fetch_page_content(url)
        if not page_content:
            logger.error(f"Failed to fetch content for {url}")
            airdrop.status = 'analysis_failed'
            db.session.commit()
            return False
        
        # Extract text content
        text_content = scraper.extract_text(page_content)
        
        # Find links in the page
        links = scraper.extract_links(page_content, url)
        
        # Identify tasks based on content and links
        identified_tasks = []
        
        # Use AI to detect tasks if OpenAI API key is available
        try:
            ai_tasks = analyze_with_ai(text_content, links, url)
            if ai_tasks:
                identified_tasks.extend(ai_tasks)
                logger.info(f"AI identified {len(ai_tasks)} tasks")
        except Exception as ai_error:
            logger.warning(f"AI task detection failed: {str(ai_error)}, falling back to pattern matching")
        
        # Traditional pattern matching as backup/addition
        pattern_tasks = analyze_with_patterns(text_content, links, url, domain)
        if pattern_tasks:
            # Merge without duplicates
            existing_descriptions = {task['description'] for task in identified_tasks}
            for task in pattern_tasks:
                if task['description'] not in existing_descriptions:
                    identified_tasks.append(task)
                    existing_descriptions.add(task['description'])
            
            logger.info(f"Pattern matching identified {len(pattern_tasks)} tasks")
            
        # Scrape forms from the page
        form_tasks = extract_form_tasks(page_content, url, domain)
        if form_tasks:
            # Add form tasks without duplicates
            existing_descriptions = {task['description'] for task in identified_tasks}
            for task in form_tasks:
                if task['description'] not in existing_descriptions:
                    identified_tasks.append(task)
                    existing_descriptions.add(task['description'])
            
            logger.info(f"Form analysis identified {len(form_tasks)} tasks")
        
        # Use advanced link detection to find additional tasks
        link_tasks = analyze_links_for_tasks(links, url, domain)
        if link_tasks:
            # Add link tasks without duplicates
            existing_descriptions = {task['description'] for task in identified_tasks}
            for task in link_tasks:
                if task['description'] not in existing_descriptions:
                    identified_tasks.append(task)
                    existing_descriptions.add(task['description'])
            
            logger.info(f"Link analysis identified {len(link_tasks)} tasks")
        
        # If we have plenty of tasks, assign priorities
        if len(identified_tasks) > 1:
            prioritize_tasks(identified_tasks, text_content)
        
        # Save tasks to database
        if identified_tasks:
            for task_data in identified_tasks:
                task = Task()
                task.airdrop_id = airdrop_id
                task.task_type = task_data['task_type']
                task.description = task_data['description']
                task.params = json.dumps(task_data['params'])
                task.status = 'pending'
                task.priority = task_data.get('priority', 1)
                db.session.add(task)
        else:
            # If no tasks were identified, create a generic task
            task = Task()
            task.airdrop_id = airdrop_id
            task.task_type = 'manual_check'
            task.description = f'Manually check airdrop requirements on {domain}'
            task.params = json.dumps({'url': url})
            task.status = 'pending'
            task.priority = 1
            db.session.add(task)
        
        # Update airdrop status
        airdrop.status = 'analyzed'
        db.session.commit()
        
        logger.info(f"Airdrop analysis completed: {len(identified_tasks)} tasks identified")
        return True
    
    except Exception as e:
        logger.exception(f"Error analyzing airdrop: {str(e)}")
        airdrop.status = 'analysis_failed'
        db.session.commit()
        return False

def analyze_with_patterns(text_content, links, url, domain):
    """
    Analyze content using regex pattern matching to identify tasks
    """
    identified_tasks = []
    
    # Check for patterns in text content
    for task_type, patterns in TASK_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text_content, re.IGNORECASE):
                # Process based on task type
                if task_type == 'twitter_follow':
                    # Try to extract Twitter handles
                    twitter_handles = re.findall(r'@([a-zA-Z0-9_]+)', text_content)
                    twitter_links = [link for link in links if ('twitter.com/' in link or 'x.com/' in link)]
                    
                    if twitter_handles:
                        for handle in twitter_handles:
                            identified_tasks.append({
                                'task_type': 'twitter_follow',
                                'description': f'Follow Twitter user @{handle}',
                                'params': {'username': handle}
                            })
                    elif twitter_links:
                        for link in twitter_links:
                            if 'twitter.com/' in link:
                                username = link.split('twitter.com/')[-1].split('?')[0].split('/')[0]
                            else:
                                username = link.split('x.com/')[-1].split('?')[0].split('/')[0]
                                
                            if username and username not in ['home', 'explore', 'notifications', 'messages']:
                                identified_tasks.append({
                                    'task_type': 'twitter_follow',
                                    'description': f'Follow Twitter user @{username}',
                                    'params': {'username': username}
                                })
                
                elif task_type in ['twitter_retweet', 'twitter_like', 'twitter_comment', 'twitter_quote']:
                    # Try to find tweet links
                    tweet_links = [link for link in links if (('twitter.com/' in link or 'x.com/' in link) and '/status/' in link)]
                    
                    if tweet_links:
                        for link in tweet_links:
                            tweet_id = link.split('/status/')[-1].split('?')[0]
                            action_text = task_type.split('_')[1].capitalize()
                            
                            identified_tasks.append({
                                'task_type': task_type,
                                'description': f'{action_text} the tweet',
                                'params': {'tweet_id': tweet_id, 'tweet_link': link}
                            })
                
                elif task_type == 'discord_join':
                    # Extract Discord invite links
                    discord_links = [link for link in links if 'discord.gg/' in link or 'discord.com/invite/' in link]
                    
                    if discord_links:
                        for link in discord_links:
                            invite_code = link.split('/')[-1].split('?')[0]
                            identified_tasks.append({
                                'task_type': 'discord_join',
                                'description': f'Join Discord server with invite {invite_code}',
                                'params': {'invite_code': invite_code, 'invite_link': link}
                            })
                
                elif task_type == 'discord_message':
                    # Find Discord server and channel information
                    servers = re.findall(r'(send|type|write).+?[\'"](.+?)[\'"].+?(channel|discord)', text_content, re.IGNORECASE)
                    if servers:
                        for _, message, _ in servers:
                            # Extract Discord server links
                            discord_links = [link for link in links if 'discord.gg/' in link or 'discord.com/invite/' in link]
                            if discord_links:
                                identified_tasks.append({
                                    'task_type': 'discord_message',
                                    'description': f'Send message "{message}" in Discord',
                                    'params': {'message': message, 'server_link': discord_links[0]}
                                })
                
                elif task_type in ['discord_react', 'discord_verify']:
                    # Find Discord server links
                    discord_links = [link for link in links if 'discord.gg/' in link or 'discord.com/invite/' in link]
                    if discord_links:
                        action = 'React to messages' if task_type == 'discord_react' else 'Verify your account'
                        identified_tasks.append({
                            'task_type': task_type,
                            'description': f'{action} in Discord server',
                            'params': {'server_link': discord_links[0]}
                        })
                
                elif task_type == 'telegram_join':
                    # Extract Telegram group/channel links
                    telegram_links = [link for link in links if 't.me/' in link]
                    
                    if telegram_links:
                        for link in telegram_links:
                            group_name = link.split('t.me/')[-1].split('?')[0]
                            identified_tasks.append({
                                'task_type': 'telegram_join',
                                'description': f'Join Telegram group/channel {group_name}',
                                'params': {'group_name': group_name, 'group_link': link}
                            })
                
                elif task_type == 'telegram_message':
                    # Find Telegram message information
                    messages = re.findall(r'(send|type|write).+?[\'"](.+?)[\'"].+?(telegram)', text_content, re.IGNORECASE)
                    if messages:
                        for _, message, _ in messages:
                            # Extract Telegram group links
                            telegram_links = [link for link in links if 't.me/' in link]
                            if telegram_links:
                                identified_tasks.append({
                                    'task_type': 'telegram_message',
                                    'description': f'Send message "{message}" in Telegram',
                                    'params': {'message': message, 'group_link': telegram_links[0]}
                                })
                
                elif task_type in ['website_signup', 'website_form', 'website_kyc', 'website_quiz'] and domain not in ['twitter.com', 'x.com', 'discord.com', 't.me']:
                    # Website-related tasks for the main website
                    task_descriptions = {
                        'website_signup': f'Sign up on {domain}',
                        'website_form': f'Complete form on {domain}',
                        'website_kyc': f'Complete KYC verification on {domain}',
                        'website_quiz': f'Complete quiz/questions on {domain}'
                    }
                    
                    identified_tasks.append({
                        'task_type': task_type,
                        'description': task_descriptions[task_type],
                        'params': {'url': url}
                    })
                
                elif task_type == 'email_verification':
                    identified_tasks.append({
                        'task_type': 'email_verification',
                        'description': 'Verify email address',
                        'params': {'url': url}
                    })
                
                elif task_type in ['wallet_connect', 'wallet_transaction'] and domain not in ['twitter.com', 'x.com', 'discord.com', 't.me']:
                    # Wallet-related tasks
                    wallet_keywords = re.findall(r'(metamask|phantom|wallet|connect).+?(wallet|address)', text_content, re.IGNORECASE)
                    
                    task_descriptions = {
                        'wallet_connect': f'Connect wallet to {domain}',
                        'wallet_transaction': f'Make transaction through {domain}'
                    }
                    
                    if wallet_keywords:
                        identified_tasks.append({
                            'task_type': task_type,
                            'description': task_descriptions[task_type],
                            'params': {'url': url}
                        })
                
                elif task_type == 'referral_share' and domain not in ['twitter.com', 'x.com', 'discord.com', 't.me']:
                    # Look for referral text
                    referral_mentions = re.findall(r'(referral|invite|refer).+?(friend|link|program)', text_content, re.IGNORECASE)
                    
                    if referral_mentions:
                        identified_tasks.append({
                            'task_type': 'referral_share',
                            'description': f'Share referral link from {domain}',
                            'params': {'url': url}
                        })
                
                elif task_type in ['social_follow', 'social_share', 'social_engage']:
                    # Find social media platforms
                    platforms = re.findall(r'(facebook|instagram|tiktok|youtube|linkedin)', text_content, re.IGNORECASE)
                    if platforms:
                        for platform in platforms:
                            platform = platform.lower()
                            # See if we can find corresponding links
                            platform_links = [link for link in links if platform in link]
                            
                            action = 'Follow' if task_type == 'social_follow' else 'Share post' if task_type == 'social_share' else 'Engage with content'
                            
                            if platform_links:
                                identified_tasks.append({
                                    'task_type': task_type,
                                    'description': f'{action} on {platform.capitalize()}',
                                    'params': {'platform': platform, 'url': platform_links[0]}
                                })
                            else:
                                identified_tasks.append({
                                    'task_type': task_type,
                                    'description': f'{action} on {platform.capitalize()}',
                                    'params': {'platform': platform, 'url': url}
                                })
    
    return identified_tasks

def analyze_with_ai(text_content, links, url):
    """
    Advanced pattern matching logic that works like AI but without any external API costs
    - Fully rules-based, 100% free
    - No API required
    """
    identified_tasks = []
    domain = urlparse(url).netloc
    
    # Common airdrop task keywords to look for
    task_keywords = {
        'twitter_follow': ['follow us', 'follow on twitter', 'follow @', 'twitter account'],
        'twitter_retweet': ['retweet', 'rt our tweet', 'repost', 'share our tweet'],
        'twitter_like': ['like our tweet', 'like our post', 'like and retweet'],
        'twitter_comment': ['comment', 'reply', 'tag friends', 'mention'],
        'discord_join': ['join discord', 'discord server', 'discord community'],
        'telegram_join': ['join telegram', 'telegram group', 'telegram channel'],
        'website_signup': ['create account', 'sign up', 'register', 'create profile'],
        'wallet_connect': ['connect wallet', 'wallet address', 'eth address', 'bsc wallet'],
        'email_verification': ['verify email', 'confirm email', 'email verification'],
    }
    
    # 1. Check for task descriptions in text content
    for task_type, keywords in task_keywords.items():
        for keyword in keywords:
            if keyword.lower() in text_content.lower():
                # We found a task keyword, now extract relevant parameters
                if task_type == 'twitter_follow':
                    # Find twitter handles
                    handles = re.findall(r'@([a-zA-Z0-9_]+)', text_content)
                    if handles:
                        for handle in handles:
                            identified_tasks.append({
                                'task_type': 'twitter_follow',
                                'description': f'Follow Twitter user @{handle}',
                                'params': {'username': handle}
                            })
                    else:
                        # Check for Twitter profile links
                        twitter_links = [link for link in links if ('twitter.com/' in link or 'x.com/' in link) and not '/status/' in link]
                        if twitter_links:
                            for link in twitter_links:
                                parts = link.split('.com/')
                                if len(parts) > 1:
                                    username = parts[1].split('/')[0].split('?')[0]
                                    if username and username not in ['home', 'explore', 'notifications', 'messages']:
                                        identified_tasks.append({
                                            'task_type': 'twitter_follow',
                                            'description': f'Follow Twitter user @{username}',
                                            'params': {'username': username, 'profile_url': link}
                                        })
                
                elif task_type in ['twitter_retweet', 'twitter_like', 'twitter_comment']:
                    # Find tweet links
                    tweet_links = [link for link in links if (('twitter.com/' in link or 'x.com/' in link) and '/status/' in link)]
                    if tweet_links:
                        for link in tweet_links:
                            # Extract tweet ID from URL
                            tweet_id = link.split('/status/')[-1].split('?')[0]
                            action = task_type.split('_')[1].capitalize()
                            identified_tasks.append({
                                'task_type': task_type,
                                'description': f'{action} the tweet',
                                'params': {'tweet_link': link, 'tweet_id': tweet_id}
                            })
                
                elif task_type == 'discord_join':
                    # Find Discord invite links
                    discord_links = [link for link in links if 'discord.gg/' in link or 'discord.com/invite/' in link]
                    if discord_links:
                        for link in discord_links:
                            invite_code = link.split('/')[-1].split('?')[0]
                            identified_tasks.append({
                                'task_type': 'discord_join',
                                'description': f'Join Discord server with invite {invite_code}',
                                'params': {'invite_link': link, 'invite_code': invite_code}
                            })
                
                elif task_type == 'telegram_join':
                    # Find Telegram group/channel links
                    telegram_links = [link for link in links if 't.me/' in link]
                    if telegram_links:
                        for link in telegram_links:
                            group_name = link.split('t.me/')[-1].split('?')[0]
                            identified_tasks.append({
                                'task_type': 'telegram_join',
                                'description': f'Join Telegram group/channel {group_name}',
                                'params': {'group_link': link, 'group_name': group_name}
                            })
                
                elif task_type == 'wallet_connect' and domain not in ['twitter.com', 'x.com', 'discord.com', 't.me']:
                    # Look for keywords about wallet requirements
                    wallet_types = []
                    
                    if 'metamask' in text_content.lower():
                        wallet_types.append('MetaMask')
                    if 'phantom' in text_content.lower():
                        wallet_types.append('Phantom')
                    if 'wallet connect' in text_content.lower():
                        wallet_types.append('WalletConnect')
                    if 'trust wallet' in text_content.lower():
                        wallet_types.append('Trust Wallet')
                    
                    wallet_text = ' or '.join(wallet_types) if wallet_types else 'wallet'
                    
                    identified_tasks.append({
                        'task_type': 'wallet_connect',
                        'description': f'Connect {wallet_text} on {domain}',
                        'params': {'url': url, 'wallet_types': wallet_types}
                    })
                
                elif task_type == 'website_signup' and domain not in ['twitter.com', 'x.com', 'discord.com', 't.me']:
                    # Check for registration mentions
                    signup_links = [link for link in links if any(word in link.lower() for word in ['register', 'signup', 'sign-up', 'join', 'create'])]
                    
                    target_url = signup_links[0] if signup_links else url
                    identified_tasks.append({
                        'task_type': 'website_signup',
                        'description': f'Sign up on {domain}',
                        'params': {'url': target_url}
                    })
                
                elif task_type == 'email_verification':
                    identified_tasks.append({
                        'task_type': 'email_verification',
                        'description': 'Verify email address',
                        'params': {'url': url}
                    })
    
    # 2. Look for common numbered/bulleted list tasks
    task_list_patterns = [
        r'(\d+)[.)\s]+(.+?)(?=\d+[.)\s]+|$)',  # Numbered lists
        r'[•\-*+][\s]+(.+?)(?=[•\-*+][\s]+|$)'  # Bulleted lists
    ]
    
    for pattern in task_list_patterns:
        list_items = re.findall(pattern, text_content)
        for item in list_items:
            # For numbered lists, item will be a tuple (number, text)
            # For bulleted lists, item will be just the text
            task_text = item[1] if isinstance(item, tuple) and len(item) > 1 else item
            
            # Convert to string if it's not already
            if not isinstance(task_text, str):
                task_text = str(task_text)
                
            # Analyze the task text
            task_lower = task_text.lower()
            
            if any(word in task_lower for word in ['follow', 'twitter', '@']):
                handles = re.findall(r'@([a-zA-Z0-9_]+)', task_text)
                if handles:
                    for handle in handles:
                        identified_tasks.append({
                            'task_type': 'twitter_follow',
                            'description': f'Follow Twitter user @{handle}',
                            'params': {'username': handle}
                        })
            
            elif any(word in task_lower for word in ['retweet', 'rt ', 'share tweet']):
                identified_tasks.append({
                    'task_type': 'twitter_retweet',
                    'description': 'Retweet the post',
                    'params': {'tweet_text': task_text}
                })
            
            elif any(word in task_lower for word in ['like tweet', 'like on twitter', 'like post']):
                identified_tasks.append({
                    'task_type': 'twitter_like',
                    'description': 'Like the post',
                    'params': {'tweet_text': task_text}
                })
            
            elif any(word in task_lower for word in ['join discord', 'discord server']):
                identified_tasks.append({
                    'task_type': 'discord_join',
                    'description': 'Join the Discord server',
                    'params': {'task_text': task_text}
                })
            
            elif any(word in task_lower for word in ['join telegram', 'telegram group', 'telegram channel']):
                identified_tasks.append({
                    'task_type': 'telegram_join',
                    'description': 'Join the Telegram group/channel',
                    'params': {'task_text': task_text}
                })
            
            elif any(word in task_lower for word in ['wallet', 'connect', 'address']):
                identified_tasks.append({
                    'task_type': 'wallet_connect',
                    'description': 'Connect wallet',
                    'params': {'task_text': task_text}
                })
            
            elif any(word in task_lower for word in ['sign up', 'register', 'create account']):
                identified_tasks.append({
                    'task_type': 'website_signup',
                    'description': 'Create an account',
                    'params': {'task_text': task_text}
                })
    
    # 3. Further analyze for common patterns in crypto airdrops
    
    # Check for KYC requirements
    if re.search(r'kyc|verify.+identity|identity.+verification', text_content, re.IGNORECASE):
        identified_tasks.append({
            'task_type': 'website_kyc',
            'description': f'Complete KYC verification on {domain}',
            'params': {'url': url}
        })
    
    # Check for quiz/questions
    if re.search(r'quiz|answer.+question|complete.+quiz', text_content, re.IGNORECASE):
        identified_tasks.append({
            'task_type': 'website_quiz',
            'description': f'Complete quiz/questions on {domain}',
            'params': {'url': url}
        })
    
    # Referral system
    if re.search(r'referral|invite.+friend|refer.+earn', text_content, re.IGNORECASE):
        identified_tasks.append({
            'task_type': 'referral_share',
            'description': f'Share referral link from {domain}',
            'params': {'url': url}
        })
    
    # Eliminate duplicates while keeping broader task descriptions
    unique_tasks = []
    task_types_seen = set()
    
    # First add tasks with specific parameters (like usernames, tweet links)
    for task in identified_tasks:
        task_key = task['task_type']
        # For Twitter tasks, make a more specific key with the username or tweet ID
        if task_key == 'twitter_follow' and 'username' in task['params']:
            task_key = f"{task_key}_{task['params']['username']}"
        elif task_key in ['twitter_retweet', 'twitter_like', 'twitter_comment'] and 'tweet_id' in task['params']:
            task_key = f"{task_key}_{task['params']['tweet_id']}"
        
        if task_key not in task_types_seen:
            task_types_seen.add(task_key)
            unique_tasks.append(task)
    
    return unique_tasks

def extract_form_tasks(page_content, url, domain):
    """
    Extract form-related tasks from the page by analyzing forms and inputs
    """
    identified_tasks = []
    
    # Get forms from the page
    forms = scraper.find_form_elements(page_content)
    
    if forms:
        for form in forms:
            # Look for input fields to determine form type
            input_types = [input_field.get('type', '') for input_field in form.get('inputs', [])]
            input_names = [input_field.get('name', '').lower() for input_field in form.get('inputs', [])]
            input_placeholders = [input_field.get('placeholder', '').lower() for input_field in form.get('inputs', [])]
            
            # Check for email inputs
            has_email = any('email' in name or 'email' in placeholder or input_type == 'email' 
                           for name, placeholder, input_type in zip(input_names, input_placeholders, input_types))
            
            # Check for password inputs
            has_password = any('password' in name or 'password' in placeholder or input_type == 'password' 
                              for name, placeholder, input_type in zip(input_names, input_placeholders, input_types))
            
            # Check for wallet address inputs
            has_wallet = any('wallet' in name or 'address' in name or 'wallet' in placeholder or 'address' in placeholder
                            for name, placeholder in zip(input_names, input_placeholders))
            
            # Determine form type
            if has_email and has_password:
                identified_tasks.append({
                    'task_type': 'website_signup',
                    'description': f'Create account on {domain}',
                    'params': {'url': url, 'form_action': form.get('action', '')}
                })
            elif has_email and not has_password:
                identified_tasks.append({
                    'task_type': 'email_verification',
                    'description': f'Submit email for verification on {domain}',
                    'params': {'url': url, 'form_action': form.get('action', '')}
                })
            elif has_wallet:
                identified_tasks.append({
                    'task_type': 'wallet_connect',
                    'description': f'Connect wallet or submit wallet address on {domain}',
                    'params': {'url': url, 'form_action': form.get('action', '')}
                })
            else:
                # Generic form
                identified_tasks.append({
                    'task_type': 'website_form',
                    'description': f'Complete form on {domain}',
                    'params': {'url': url, 'form_action': form.get('action', '')}
                })
    
    return identified_tasks

def analyze_links_for_tasks(links, url, domain):
    """
    Analyze links to identify additional tasks that might not be obvious from text
    """
    identified_tasks = []
    
    # Look for links to social media that weren't detected in text
    social_platforms = {
        'facebook.com': {'type': 'social_follow', 'name': 'Facebook'},
        'instagram.com': {'type': 'social_follow', 'name': 'Instagram'},
        'tiktok.com': {'type': 'social_follow', 'name': 'TikTok'},
        'youtube.com': {'type': 'social_follow', 'name': 'YouTube'},
        'linkedin.com': {'type': 'social_follow', 'name': 'LinkedIn'},
        'github.com': {'type': 'social_follow', 'name': 'GitHub'},
        'medium.com': {'type': 'social_follow', 'name': 'Medium'},
        'reddit.com': {'type': 'social_follow', 'name': 'Reddit'}
    }
    
    for link in links:
        for platform, data in social_platforms.items():
            if platform in link and not any(platform in task['description'] for task in identified_tasks):
                identified_tasks.append({
                    'task_type': data['type'],
                    'description': f"Follow on {data['name']}",
                    'params': {'url': link, 'platform': platform}
                })
    
    # Look for wallet-related links
    wallet_keywords = ['wallet', 'connect', 'metamask', 'phantom', 'walletconnect']
    for link in links:
        link_lower = link.lower()
        if any(keyword in link_lower for keyword in wallet_keywords) and domain in link:
            identified_tasks.append({
                'task_type': 'wallet_connect',
                'description': f'Connect wallet on {domain}',
                'params': {'url': link}
            })
            break
    
    # Look for "claim" or "airdrop" links
    claim_keywords = ['claim', 'airdrop', 'reward', 'bounty']
    for link in links:
        link_lower = link.lower()
        if any(keyword in link_lower for keyword in claim_keywords) and domain in link:
            identified_tasks.append({
                'task_type': 'website_form',
                'description': f'Claim airdrop on {domain}',
                'params': {'url': link}
            })
            break
    
    return identified_tasks

def prioritize_tasks(tasks, text_content):
    """
    Assign priorities to tasks based on their importance
    """
    # Priority order (higher number = higher priority)
    priority_order = {
        'wallet_connect': 5,
        'wallet_transaction': 4,
        'website_signup': 4,
        'website_kyc': 3,
        'twitter_follow': 3,
        'twitter_retweet': 3, 
        'twitter_like': 3,
        'discord_join': 3,
        'telegram_join': 3,
        'email_verification': 2,
        'website_form': 2,
        'social_follow': 2,
        'social_share': 2,
        'referral_share': 1
    }
    
    # Look for words indicating importance in text
    importance_terms = {
        'must': 2,
        'mandatory': 2,
        'required': 2,
        'essential': 2,
        'important': 1,
        'necessary': 1,
        'crucial': 2
    }
    
    # Check text for keywords like "mandatory" near task descriptions
    for task in tasks:
        # Start with base priority from the type
        task['priority'] = priority_order.get(task['task_type'], 1)
        
        # Look for importance terms near task description words
        task_keywords = task['description'].lower().split()
        for keyword in task_keywords:
            if len(keyword) > 4:  # Only consider substantive words
                # Look for importance terms near this keyword in the text
                keyword_index = text_content.lower().find(keyword)
                if keyword_index > 0:
                    context = text_content.lower()[max(0, keyword_index-50):keyword_index+50]
                    for term, value in importance_terms.items():
                        if term in context:
                            task['priority'] += value
                            break

def find_best_account(task, accounts):
    """
    Find the most suitable account for a given task based on task type and platform
    
    Args:
        task: Task to be executed
        accounts: List of available accounts
        
    Returns:
        Best matching account or None if no suitable account found
    """
    task_type = task.task_type
    task_platform = get_task_platform(task_type)
    
    # Get accounts for the specific platform
    platform_accounts = [a for a in accounts if a.platform.lower() == task_platform.lower()]
    
    if not platform_accounts:
        return None
    
    # Check if any accounts have already successfully completed similar tasks
    account_success_rates = {}
    for account in platform_accounts:
        # Get task histories for this account and similar task types
        histories = TaskHistory.query.join(Task).filter(
            TaskHistory.account_id == account.id,
            Task.task_type == task_type
        ).all()
        
        if not histories:
            # No history, assign base score
            account_success_rates[account.id] = 0.5
        else:
            # Calculate success rate
            success_count = sum(1 for h in histories if h.status == 'success')
            account_success_rates[account.id] = success_count / len(histories)
    
    # Sort accounts by success rate (highest first)
    sorted_accounts = sorted(
        platform_accounts, 
        key=lambda a: account_success_rates.get(a.id, 0.5), 
        reverse=True
    )
    
    # Return the best account
    return sorted_accounts[0] if sorted_accounts else None

def get_task_platform(task_type):
    """
    Get the platform name from a task type
    """
    if task_type.startswith('twitter_'):
        return 'twitter'
    elif task_type.startswith('discord_'):
        return 'discord'
    elif task_type.startswith('telegram_'):
        return 'telegram'
    elif task_type.startswith('website_') or task_type in ['wallet_connect', 'wallet_transaction']:
        return 'web'
    elif task_type.startswith('email_'):
        return 'email'
    elif task_type.startswith('social_'):
        # For social tasks, we need more context from the parameters
        return 'social'
    else:
        return 'unknown'

def distribute_airdrop_to_accounts(airdrop_id, account_ids=None, replicate=False):
    """
    Distribute airdrop tasks across multiple accounts.
    
    Args:
        airdrop_id: ID of the airdrop to distribute
        account_ids: Optional list of specific account IDs to use
        replicate: If True, replicate all tasks to all accounts. If False,
                  distribute tasks intelligently across accounts
                  
    Returns:
        Tuple of (success, message)
    """
    logger.info(f"Distributing airdrop ID: {airdrop_id} to accounts")
    
    # Get the airdrop
    airdrop = db.session.get(Airdrop, airdrop_id)
    if not airdrop:
        logger.error(f"Airdrop ID {airdrop_id} not found")
        return False, "Airdrop not found"
    
    # Get all tasks for this airdrop
    tasks = Task.query.filter_by(airdrop_id=airdrop_id).order_by(Task.priority.desc()).all()
    if not tasks:
        logger.warning(f"No tasks found for airdrop ID {airdrop_id}")
        return False, "No tasks found for this airdrop"
    
    # Get accounts that can be used
    user_id = airdrop.user_id
    
    if account_ids:
        # If specific accounts are provided, use them (after verifying ownership)
        accounts = Account.query.filter(
            Account.id.in_(account_ids),
            Account.user_id == user_id
        ).all()
        
        if len(accounts) != len(account_ids):
            logger.warning(f"Some account IDs are invalid or don't belong to user {user_id}")
            return False, "Some account IDs are invalid or don't belong to you"
    else:
        # Otherwise, use all accounts for this user
        accounts = Account.query.filter_by(user_id=user_id).all()
    
    if not accounts:
        logger.warning(f"No accounts found for user ID {user_id}")
        return False, "No accounts available"
    
    # Group accounts by platform
    platform_accounts = {}
    for account in accounts:
        platform = account.platform.lower()
        if platform not in platform_accounts:
            platform_accounts[platform] = []
        platform_accounts[platform].append(account)
    
    # Group tasks by required platform
    platform_tasks = {}
    for task in tasks:
        platform = get_task_platform(task.task_type)
        if platform not in platform_tasks:
            platform_tasks[platform] = []
        platform_tasks[platform].append(task)
    
    # Track distribution stats
    distribution_stats = {
        'account_assignments': {},   # account_id -> task_count
        'platform_coverage': {},     # platform -> coverage_percent
        'unassigned_tasks': []       # list of task IDs with no suitable account
    }
    
    # Initialize account assignment counters
    for account in accounts:
        distribution_stats['account_assignments'][account.id] = 0
    
    # For each platform, distribute tasks among that platform's accounts
    for platform, platform_task_list in platform_tasks.items():
        available_accounts = platform_accounts.get(platform, [])
        
        if not available_accounts:
            # No accounts for this platform
            for task in platform_task_list:
                distribution_stats['unassigned_tasks'].append(task.id)
            
            distribution_stats['platform_coverage'][platform] = 0.0
            continue
        
        if replicate:
            # Replicate all tasks to all accounts for this platform
            for task in platform_task_list:
                for account in available_accounts:
                    # Queue this task for execution on this account
                    # We'll create task execution entries for each
                    queue_task_for_account(task, account)
                    distribution_stats['account_assignments'][account.id] += 1
            
            distribution_stats['platform_coverage'][platform] = 100.0
        else:
            # Distribute tasks intelligently across accounts
            # Try to balance workload while matching account skills
            
            # Sort tasks by priority (highest first)
            sorted_tasks = sorted(platform_task_list, key=lambda t: t.priority, reverse=True)
            
            # Initialize assignment tracking
            assigned_tasks = set()
            
            # First, try to assign high-priority tasks based on past success
            for task in sorted_tasks:
                if task.id in assigned_tasks:
                    continue
                
                # Find best account for this task
                best_account = find_best_account(task, available_accounts)
                if best_account:
                    # Queue this task for execution on this account
                    queue_task_for_account(task, best_account)
                    distribution_stats['account_assignments'][best_account.id] += 1
                    assigned_tasks.add(task.id)
            
            # Then, assign any remaining tasks to balance the workload
            remaining_tasks = [t for t in sorted_tasks if t.id not in assigned_tasks]
            
            if remaining_tasks:
                # Sort accounts by current task count (lowest first)
                sorted_accounts = sorted(
                    available_accounts,
                    key=lambda a: distribution_stats['account_assignments'][a.id]
                )
                
                # Assign remaining tasks to accounts with lowest workload
                for task in remaining_tasks:
                    if not sorted_accounts:
                        distribution_stats['unassigned_tasks'].append(task.id)
                        continue
                    
                    account = sorted_accounts[0]
                    queue_task_for_account(task, account)
                    distribution_stats['account_assignments'][account.id] += 1
                    
                    # Re-sort accounts after assignment
                    sorted_accounts = sorted(
                        sorted_accounts,
                        key=lambda a: distribution_stats['account_assignments'][a.id]
                    )
            
            # Calculate platform coverage
            covered_task_count = len(sorted_tasks) - len(remaining_tasks)
            distribution_stats['platform_coverage'][platform] = (
                (covered_task_count / len(sorted_tasks)) * 100.0 if sorted_tasks else 0.0
            )
    
    # Update airdrop status
    airdrop.status = 'distributed'
    db.session.commit()
    
    # Prepare summary message
    assigned_count = sum(1 for tasks in platform_tasks.values() for _ in tasks) - len(distribution_stats['unassigned_tasks'])
    total_tasks = sum(1 for tasks in platform_tasks.values() for _ in tasks)
    
    message = f"Successfully distributed {assigned_count} of {total_tasks} tasks across {len(accounts)} accounts"
    return True, message

def queue_task_for_account(task, account):
    """
    Queue a task for execution on a specific account
    """
    # You could use a message queue system like Celery for production
    # For now we'll create a task-account assignment record
    
    # Check if a task execution already exists
    existing = TaskExecution.query.filter_by(
        task_id=task.id,
        account_id=account.id,
        status='queued'
    ).first()
    
    if not existing:
        execution = TaskExecution()
        execution.task_id = task.id
        execution.account_id = account.id
        execution.status = 'queued'
        execution.created_at = datetime.now()
        db.session.add(execution)
        db.session.commit()

def execute_airdrop(airdrop_id, account_id=None):
    """
    Execute all tasks for an airdrop using available accounts
    """
    logger.info(f"Executing airdrop ID: {airdrop_id}")
    
    # Get the airdrop from database
    airdrop = db.session.get(Airdrop, airdrop_id)
    if not airdrop:
        logger.error(f"Airdrop ID {airdrop_id} not found")
        return False
    
    try:
        # Update airdrop status
        airdrop.status = 'in_progress'
        airdrop.last_run = datetime.utcnow()
        db.session.commit()
        
        # Get all tasks for this airdrop
        tasks = Task.query.filter_by(airdrop_id=airdrop_id).order_by(Task.priority.desc()).all()
        if not tasks:
            logger.warning(f"No tasks found for airdrop ID {airdrop_id}")
            airdrop.status = 'no_tasks'
            db.session.commit()
            return False
        
        # Get all accounts for the user
        user_id = airdrop.user_id
        accounts = Account.query.filter_by(user_id=user_id).all()
        if not accounts:
            logger.warning(f"No accounts found for user ID {user_id}")
            airdrop.status = 'no_accounts'
            db.session.commit()
            return False
        
        # Group accounts by platform
        platform_accounts = {}
        for account in accounts:
            if account.platform not in platform_accounts:
                platform_accounts[account.platform] = []
            platform_accounts[account.platform].append(account)
        
        # Execute each task with appropriate accounts
        total_tasks = len(tasks)
        successful_tasks = 0
        
        for task in tasks:
            # Skip already completed tasks
            if task.status == 'completed':
                successful_tasks += 1
                continue
            
            # Determine which platform to use based on task type
            platform = None
            if task.task_type.startswith('twitter'):
                platform = 'twitter'
            elif task.task_type.startswith('discord'):
                platform = 'discord'
            elif task.task_type.startswith('telegram'):
                platform = 'telegram'
            else:
                platform = 'web'  # Default to web for other task types
            
            # Get accounts for this platform
            accounts_for_task = platform_accounts.get(platform, [])
            if not accounts_for_task and platform != 'web':
                # For tasks that require specific platform accounts
                logger.warning(f"No {platform} accounts available for task ID {task.id}")
                continue
            
            # Update task status
            task.status = 'in_progress'
            db.session.commit()
            
            # Try to execute the task with each account
            task_success = False
            
            # If this is a web task, just use one account if available
            if platform == 'web' and accounts:
                accounts_for_task = [accounts[0]]
            
            for account in accounts_for_task:
                # Get the best strategy for this task type and platform from learning system
                strategy = learning.get_best_strategy(task.task_type, platform)
                
                # Execute the task
                task_params = task.get_params()
                start_time = time.time()
                
                try:
                    result = automation.execute_task(
                        task_type=task.task_type,
                        params=task_params,
                        account=account,
                        strategy=strategy
                    )
                    
                    execution_time = time.time() - start_time
                    
                    # Record task history
                    history = TaskHistory()
                    history.task_id = task.id
                    history.account_id = account.id
                    history.status = 'success' if result['success'] else 'failed'
                    history.details = result['details']
                    history.execution_time = execution_time
                    db.session.add(history)
                    
                    # Update learning system
                    learning.update_strategy(
                        task_type=task.task_type,
                        platform=platform,
                        success=result['success'],
                        execution_time=execution_time,
                        details=result['details']
                    )
                    
                    if result['success']:
                        task_success = True
                        break  # Stop trying with other accounts if successful
                    
                    # If failure, log and continue with next account
                    logger.warning(f"Task execution failed with account {account.username}: {result['details']}")
                    
                    # Add exponential backoff between retries
                    time.sleep(min(5 * (task.retry_count + 1), 60))  # Max 60 seconds
                    
                except Exception as e:
                    logger.exception(f"Error executing task {task.id} with account {account.id}: {str(e)}")
                    
                    # Record task history
                    history = TaskHistory()
                    history.task_id = task.id
                    history.account_id = account.id
                    history.status = 'failed'
                    history.details = f"Exception: {str(e)}"
                    history.execution_time = time.time() - start_time
                    db.session.add(history)
                    
                    # Update learning system
                    learning.update_strategy(
                        task_type=task.task_type,
                        platform=platform,
                        success=False,
                        execution_time=time.time() - start_time,
                        details=f"Exception: {str(e)}"
                    )
            
            # Update task status based on execution result
            if task_success:
                task.status = 'completed'
                successful_tasks += 1
            else:
                task.retry_count += 1
                if task.retry_count >= task.max_retries:
                    task.status = 'failed'
                else:
                    task.status = 'pending'  # Set back to pending for future retry
            
            # Calculate success rate
            task_histories = TaskHistory.query.filter_by(task_id=task.id).all()
            if task_histories:
                success_count = sum(1 for h in task_histories if h.status == 'success')
                task.success_rate = (success_count / len(task_histories)) * 100
            
            db.session.commit()
        
        # Update airdrop status and success rate
        if successful_tasks == total_tasks:
            airdrop.status = 'completed'
        elif successful_tasks > 0:
            airdrop.status = 'partially_completed'
        else:
            airdrop.status = 'failed'
        
        airdrop.success_rate = (successful_tasks / total_tasks) * 100 if total_tasks > 0 else 0
        db.session.commit()
        
        logger.info(f"Airdrop execution completed: {successful_tasks}/{total_tasks} tasks successful")
        return True
    
    except Exception as e:
        logger.exception(f"Error executing airdrop: {str(e)}")
        airdrop.status = 'execution_failed'
        db.session.commit()
        return False
