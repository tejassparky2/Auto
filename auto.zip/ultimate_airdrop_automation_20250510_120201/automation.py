import logging
import json
import time
import random
from datetime import datetime
import re
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException, NoSuchElementException, 
    ElementClickInterceptedException, StaleElementReferenceException
)
from selenium.webdriver.common.keys import Keys
from urllib.parse import urlparse

# Configure logging
logger = logging.getLogger(__name__)

# Initialize ChromeDriver options (headless mode for server environment)
def get_chrome_options():
    options = Options()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_argument('--window-size=1920,1080')
    options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36')
    return options

def execute_task(task_type, params, account, strategy=None):
    """
    Execute a specific airdrop task with the given account
    
    Args:
        task_type: Type of task (twitter_follow, discord_join, etc.)
        params: Dictionary of parameters for the task
        account: Account model instance
        strategy: Optional dictionary of strategy parameters from learning system
    
    Returns:
        dict: {'success': bool, 'details': str}
    """
    logger.info(f"Executing {task_type} task with account {account.username}")
    
    # Use default strategy if none provided
    if not strategy:
        strategy = {}
    
    # Execute the appropriate task based on type
    if task_type.startswith('twitter_'):
        return execute_twitter_task(task_type, params, account, strategy)
    elif task_type.startswith('discord_'):
        return execute_discord_task(task_type, params, account, strategy)
    elif task_type.startswith('telegram_'):
        return execute_telegram_task(task_type, params, account, strategy)
    elif task_type.startswith('website_'):
        return execute_website_task(task_type, params, account, strategy)
    elif task_type == 'email_verification':
        return execute_email_task(params, account, strategy)
    elif task_type == 'manual_check':
        return {'success': False, 'details': 'Manual check required for this task'}
    else:
        return {'success': False, 'details': f'Unknown task type: {task_type}'}

def execute_twitter_task(task_type, params, account, strategy):
    """Execute a Twitter-related task"""
    driver = None
    try:
        options = get_chrome_options()
        driver = webdriver.Chrome(options=options)
        
        # Apply wait time from strategy or use default
        wait_time = strategy.get('wait_time', 10)
        wait = WebDriverWait(driver, wait_time)
        
        # Login to Twitter
        login_result = twitter_login(driver, wait, account)
        if not login_result['success']:
            return login_result
        
        # Execute specific Twitter task
        if task_type == 'twitter_follow':
            return twitter_follow(driver, wait, params, strategy)
        elif task_type == 'twitter_retweet':
            return twitter_retweet(driver, wait, params, strategy)
        elif task_type == 'twitter_like':
            return twitter_like(driver, wait, params, strategy)
        else:
            return {'success': False, 'details': f'Unknown Twitter task type: {task_type}'}
    
    except Exception as e:
        logger.exception(f"Error executing Twitter task: {str(e)}")
        return {'success': False, 'details': f'Exception: {str(e)}'}
    
    finally:
        if driver:
            driver.quit()

def twitter_login(driver, wait, account):
    """Login to Twitter with the given account"""
    try:
        # Navigate to Twitter login page
        driver.get('https://twitter.com/login')
        time.sleep(2)  # Wait for page to load
        
        # Enter username
        username_input = wait.until(EC.presence_of_element_located((By.NAME, 'text')))
        username_input.send_keys(account.username)
        username_input.send_keys(Keys.RETURN)
        time.sleep(1)
        
        # Sometimes Twitter asks for phone/email instead of username
        try:
            verify_input = WebDriverWait(driver, 3).until(
                EC.presence_of_element_located((By.NAME, 'text'))
            )
            verify_input.send_keys(account.username)  # Use email or phone if required
            verify_input.send_keys(Keys.RETURN)
            time.sleep(1)
        except (TimeoutException, NoSuchElementException):
            pass  # This step isn't always required
        
        # Enter password
        password_input = wait.until(EC.presence_of_element_located((By.NAME, 'password')))
        password_input.send_keys(account.password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(3)
        
        # Check for successful login
        if 'home' in driver.current_url:
            return {'success': True, 'details': 'Successfully logged in to Twitter'}
        else:
            return {'success': False, 'details': 'Failed to login to Twitter'}
    
    except Exception as e:
        logger.exception(f"Twitter login error: {str(e)}")
        return {'success': False, 'details': f'Twitter login error: {str(e)}'}

def twitter_follow(driver, wait, params, strategy):
    """Follow a Twitter user"""
    try:
        username = params.get('username')
        if not username:
            return {'success': False, 'details': 'No username specified for Twitter follow'}
        
        # Make sure username doesn't have @ prefix
        username = username.lstrip('@')
        
        # Navigate to user's profile
        driver.get(f'https://twitter.com/{username}')
        time.sleep(2)
        
        # Check if already following
        follow_buttons = driver.find_elements(By.XPATH, "//div[@aria-label='Follow @" + username + "']")
        following_buttons = driver.find_elements(By.XPATH, "//div[@aria-label='Following @" + username + "']")
        
        if following_buttons:
            return {'success': True, 'details': f'Already following @{username}'}
        
        if not follow_buttons:
            # Try alternative selectors
            follow_buttons = driver.find_elements(By.XPATH, "//span[text()='Follow']")
            
        if follow_buttons:
            # Click follow button
            follow_button = follow_buttons[0]
            driver.execute_script("arguments[0].scrollIntoView();", follow_button)
            follow_button.click()
            time.sleep(2)
            
            # Check if now following
            following_buttons = driver.find_elements(By.XPATH, "//div[@aria-label='Following @" + username + "']")
            if following_buttons or "Following" in driver.page_source:
                return {'success': True, 'details': f'Successfully followed @{username}'}
        
        return {'success': False, 'details': f'Failed to follow @{username}'}
    
    except Exception as e:
        logger.exception(f"Twitter follow error: {str(e)}")
        return {'success': False, 'details': f'Twitter follow error: {str(e)}'}

def twitter_retweet(driver, wait, params, strategy):
    """Retweet a Twitter post"""
    try:
        tweet_link = params.get('tweet_link')
        if not tweet_link:
            return {'success': False, 'details': 'No tweet link specified for retweet'}
        
        # Navigate to tweet
        driver.get(tweet_link)
        time.sleep(3)
        
        # Find and click retweet button
        retweet_buttons = driver.find_elements(By.XPATH, "//div[@aria-label='Retweet']")
        
        if not retweet_buttons:
            return {'success': False, 'details': 'Retweet button not found'}
        
        retweet_button = retweet_buttons[0]
        driver.execute_script("arguments[0].scrollIntoView();", retweet_button)
        retweet_button.click()
        time.sleep(1)
        
        # Click confirm retweet
        confirm_buttons = driver.find_elements(By.XPATH, "//span[text()='Retweet']")
        if confirm_buttons:
            confirm_buttons[0].click()
            time.sleep(2)
            return {'success': True, 'details': 'Successfully retweeted the post'}
        
        return {'success': False, 'details': 'Failed to confirm retweet'}
    
    except Exception as e:
        logger.exception(f"Twitter retweet error: {str(e)}")
        return {'success': False, 'details': f'Twitter retweet error: {str(e)}'}

def twitter_like(driver, wait, params, strategy):
    """Like a Twitter post"""
    try:
        tweet_link = params.get('tweet_link')
        if not tweet_link:
            return {'success': False, 'details': 'No tweet link specified for like'}
        
        # Navigate to tweet
        driver.get(tweet_link)
        time.sleep(3)
        
        # Find and click like button
        like_buttons = driver.find_elements(By.XPATH, "//div[@aria-label='Like']")
        
        if not like_buttons:
            # Check if already liked
            if driver.find_elements(By.XPATH, "//div[@aria-label='Liked']"):
                return {'success': True, 'details': 'Tweet already liked'}
            return {'success': False, 'details': 'Like button not found'}
        
        like_button = like_buttons[0]
        driver.execute_script("arguments[0].scrollIntoView();", like_button)
        like_button.click()
        time.sleep(2)
        
        # Check if like was successful
        if driver.find_elements(By.XPATH, "//div[@aria-label='Liked']"):
            return {'success': True, 'details': 'Successfully liked the tweet'}
        
        return {'success': False, 'details': 'Failed to like the tweet'}
    
    except Exception as e:
        logger.exception(f"Twitter like error: {str(e)}")
        return {'success': False, 'details': f'Twitter like error: {str(e)}'}

def execute_discord_task(task_type, params, account, strategy):
    """Execute a Discord-related task"""
    driver = None
    try:
        options = get_chrome_options()
        driver = webdriver.Chrome(options=options)
        
        # Apply wait time from strategy or use default
        wait_time = strategy.get('wait_time', 10)
        wait = WebDriverWait(driver, wait_time)
        
        # Login to Discord
        login_result = discord_login(driver, wait, account)
        if not login_result['success']:
            return login_result
        
        # Execute specific Discord task
        if task_type == 'discord_join':
            return discord_join_server(driver, wait, params, strategy)
        elif task_type == 'discord_message':
            return discord_send_message(driver, wait, params, strategy)
        else:
            return {'success': False, 'details': f'Unknown Discord task type: {task_type}'}
    
    except Exception as e:
        logger.exception(f"Error executing Discord task: {str(e)}")
        return {'success': False, 'details': f'Exception: {str(e)}'}
    
    finally:
        if driver:
            driver.quit()

def discord_login(driver, wait, account):
    """Login to Discord with the given account"""
    try:
        # Navigate to Discord login page
        driver.get('https://discord.com/login')
        time.sleep(2)  # Wait for page to load
        
        # Enter email
        email_input = wait.until(EC.presence_of_element_located((By.NAME, 'email')))
        email_input.send_keys(account.username)
        
        # Enter password
        password_input = wait.until(EC.presence_of_element_located((By.NAME, 'password')))
        password_input.send_keys(account.password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(5)  # Discord can take some time to load
        
        # Check for successful login
        if "login" not in driver.current_url:
            return {'success': True, 'details': 'Successfully logged in to Discord'}
        else:
            return {'success': False, 'details': 'Failed to login to Discord'}
    
    except Exception as e:
        logger.exception(f"Discord login error: {str(e)}")
        return {'success': False, 'details': f'Discord login error: {str(e)}'}

def discord_join_server(driver, wait, params, strategy):
    """Join a Discord server"""
    try:
        invite_link = params.get('invite_link')
        invite_code = params.get('invite_code')
        
        if not invite_link and invite_code:
            invite_link = f"https://discord.gg/{invite_code}"
        
        if not invite_link:
            return {'success': False, 'details': 'No invite link specified for Discord join'}
        
        # Navigate to invite link
        driver.get(invite_link)
        time.sleep(3)
        
        # Look for join button or accept invite button
        join_buttons = driver.find_elements(By.XPATH, "//button[contains(text(), 'Accept Invite') or contains(text(), 'Join')]")
        
        if not join_buttons:
            # Check if already in server
            if "You're already in this server" in driver.page_source or "This server is unavailable" in driver.page_source:
                return {'success': True, 'details': 'Already in this Discord server'}
            
            return {'success': False, 'details': 'Join button not found on Discord invite page'}
        
        # Click join button
        join_button = join_buttons[0]
        join_button.click()
        time.sleep(5)  # Give time for server to load
        
        # Check if join was successful
        if "This server is unavailable" not in driver.page_source:
            return {'success': True, 'details': 'Successfully joined Discord server'}
        
        return {'success': False, 'details': 'Failed to join Discord server'}
    
    except Exception as e:
        logger.exception(f"Discord join error: {str(e)}")
        return {'success': False, 'details': f'Discord join error: {str(e)}'}

def discord_send_message(driver, wait, params, strategy):
    """Send a message in a Discord channel"""
    try:
        channel_url = params.get('channel_url')
        message = params.get('message')
        
        if not channel_url:
            return {'success': False, 'details': 'No channel URL specified for Discord message'}
        
        if not message:
            return {'success': False, 'details': 'No message content specified for Discord message'}
        
        # Navigate to channel
        driver.get(channel_url)
        time.sleep(5)  # Discord channels take time to load
        
        # Find message input
        message_input = wait.until(EC.presence_of_element_located((By.XPATH, "//div[@role='textbox']")))
        message_input.send_keys(message)
        message_input.send_keys(Keys.RETURN)
        time.sleep(2)
        
        return {'success': True, 'details': 'Successfully sent Discord message'}
    
    except Exception as e:
        logger.exception(f"Discord message error: {str(e)}")
        return {'success': False, 'details': f'Discord message error: {str(e)}'}

def execute_telegram_task(task_type, params, account, strategy):
    """Execute a Telegram-related task"""
    driver = None
    try:
        options = get_chrome_options()
        driver = webdriver.Chrome(options=options)
        
        # Apply wait time from strategy or use default
        wait_time = strategy.get('wait_time', 10)
        wait = WebDriverWait(driver, wait_time)
        
        # For Telegram, we typically use the web version
        if task_type == 'telegram_join':
            return telegram_join_group(driver, wait, params, account, strategy)
        else:
            return {'success': False, 'details': f'Unknown Telegram task type: {task_type}'}
    
    except Exception as e:
        logger.exception(f"Error executing Telegram task: {str(e)}")
        return {'success': False, 'details': f'Exception: {str(e)}'}
    
    finally:
        if driver:
            driver.quit()

def telegram_join_group(driver, wait, params, account, strategy):
    """Join a Telegram group/channel"""
    try:
        group_link = params.get('group_link')
        if not group_link:
            return {'success': False, 'details': 'No group link specified for Telegram join'}
        
        # Navigate to Telegram group link
        driver.get(group_link)
        time.sleep(3)
        
        # Check if we're asked to open in app
        app_buttons = driver.find_elements(By.XPATH, "//a[contains(text(), 'Open in app') or contains(text(), 'Open in Telegram')]")
        if app_buttons:
            # Telegram web may require app, which is hard to automate
            return {'success': False, 'details': 'Telegram is requesting to open in app, which is not supported in automation'}
        
        # Look for join button
        join_buttons = driver.find_elements(By.XPATH, "//a[contains(text(), 'Join Channel') or contains(text(), 'Join Group')]")
        
        if join_buttons:
            # Found join button, but we can't fully automate this as it requires the Telegram app
            return {'success': False, 'details': 'Telegram join button found, but requires manual intervention with Telegram app'}
        
        # Check if preview is available
        if "Preview channel" in driver.page_source or "View in Telegram" in driver.page_source:
            return {'success': True, 'details': 'Telegram group/channel preview accessed successfully'}
        
        return {'success': False, 'details': 'Failed to join Telegram group/channel'}
    
    except Exception as e:
        logger.exception(f"Telegram join error: {str(e)}")
        return {'success': False, 'details': f'Telegram join error: {str(e)}'}

def execute_website_task(task_type, params, account, strategy):
    """Execute a website-related task"""
    driver = None
    try:
        options = get_chrome_options()
        driver = webdriver.Chrome(options=options)
        
        # Apply wait time from strategy or use default
        wait_time = strategy.get('wait_time', 10)
        wait = WebDriverWait(driver, wait_time)
        
        url = params.get('url')
        if not url:
            return {'success': False, 'details': 'No URL specified for website task'}
        
        # Navigate to website
        driver.get(url)
        time.sleep(3)  # Wait for page to load
        
        if task_type == 'website_signup':
            return website_signup(driver, wait, url, account, strategy)
        elif task_type == 'website_form':
            return website_form(driver, wait, url, account, strategy)
        else:
            return {'success': False, 'details': f'Unknown website task type: {task_type}'}
    
    except Exception as e:
        logger.exception(f"Error executing website task: {str(e)}")
        return {'success': False, 'details': f'Exception: {str(e)}'}
    
    finally:
        if driver:
            driver.quit()

def website_signup(driver, wait, url, account, strategy):
    """Sign up on a website"""
    try:
        # This is a complex task as signup forms can vary widely
        # We'll implement a generic approach with common patterns
        
        # Look for signup/register links
        signup_links = driver.find_elements(By.XPATH, 
            "//a[contains(text(), 'Sign up') or contains(text(), 'Register') or contains(text(), 'Create account')]"
        )
        
        if signup_links:
            signup_links[0].click()
            time.sleep(2)
        
        # Look for email input
        email_inputs = driver.find_elements(By.XPATH, 
            "//input[@type='email' or contains(@id, 'email') or contains(@name, 'email')]"
        )
        
        if email_inputs:
            email_inputs[0].send_keys(account.username)
        else:
            # Try to find username input
            username_inputs = driver.find_elements(By.XPATH, 
                "//input[contains(@id, 'user') or contains(@name, 'user') or contains(@placeholder, 'user')]"
            )
            if username_inputs:
                username_inputs[0].send_keys(account.username)
        
        # Look for password input
        password_inputs = driver.find_elements(By.XPATH, 
            "//input[@type='password' or contains(@id, 'password') or contains(@name, 'password')]"
        )
        
        if password_inputs:
            password_inputs[0].send_keys(account.password)
            # If there's a second password field (confirm password), fill it too
            if len(password_inputs) > 1:
                password_inputs[1].send_keys(account.password)
        
        # Look for submit/signup button
        submit_buttons = driver.find_elements(By.XPATH, 
            "//button[@type='submit' or contains(text(), 'Sign up') or contains(text(), 'Register') or contains(text(), 'Create')]"
        )
        
        if submit_buttons:
            submit_buttons[0].click()
            time.sleep(3)
            
            # Check for success indicators
            if any(text in driver.page_source for text in ['successfully', 'welcome', 'verify', 'thank you']):
                return {'success': True, 'details': 'Successfully signed up on the website'}
        
        return {'success': False, 'details': 'Attempted to sign up but could not verify success'}
    
    except Exception as e:
        logger.exception(f"Website signup error: {str(e)}")
        return {'success': False, 'details': f'Website signup error: {str(e)}'}

def website_form(driver, wait, url, account, strategy):
    """Fill out a form on a website"""
    try:
        # This is a complex task as forms can vary widely
        # We'll implement a generic approach
        
        # Find form elements
        form = driver.find_elements(By.TAG_NAME, 'form')
        if not form:
            return {'success': False, 'details': 'No form found on the page'}
        
        # Find all input fields
        input_fields = driver.find_elements(By.XPATH, "//input[not(@type='hidden') and not(@type='submit') and not(@type='button')]")
        
        for input_field in input_fields:
            field_type = input_field.get_attribute('type')
            field_name = input_field.get_attribute('name') or input_field.get_attribute('id') or ''
            field_placeholder = input_field.get_attribute('placeholder') or ''
            
            # Skip already filled fields
            if input_field.get_attribute('value'):
                continue
            
            if field_type == 'email' or 'email' in field_name.lower() or 'email' in field_placeholder.lower():
                input_field.send_keys(account.username)
            elif field_type == 'password' or 'password' in field_name.lower():
                input_field.send_keys(account.password)
            elif 'name' in field_name.lower() or 'name' in field_placeholder.lower():
                # Generate a generic name from the username
                name_parts = account.username.split('@')[0].split('.')
                if len(name_parts) > 1:
                    input_field.send_keys(f"{name_parts[0].capitalize()} {name_parts[1].capitalize()}")
                else:
                    input_field.send_keys(name_parts[0].capitalize())
            elif field_type == 'checkbox':
                # Check boxes that might be for terms acceptance
                if any(term in field_name.lower() for term in ['agree', 'terms', 'accept']):
                    if not input_field.is_selected():
                        input_field.click()
            elif field_type != 'radio' and field_type != 'checkbox':
                # Fill other text fields with some generic data
                input_field.send_keys("Airdrop Participant")
        
        # Find and fill textareas
        textareas = driver.find_elements(By.TAG_NAME, 'textarea')
        for textarea in textareas:
            textarea.send_keys("I'm interested in participating in this airdrop. Thank you for the opportunity.")
        
        # Find and select dropdowns
        selects = driver.find_elements(By.TAG_NAME, 'select')
        for select in selects:
            # Try to select a non-default option
            options = select.find_elements(By.TAG_NAME, 'option')
            if len(options) > 1:
                # Select the second option (index 1) as first is often a placeholder
                options[1].click()
        
        # Find and click submit button
        submit_buttons = driver.find_elements(By.XPATH, 
            "//button[@type='submit' or contains(text(), 'Submit') or contains(text(), 'Send')]"
        )
        
        if not submit_buttons:
            submit_inputs = driver.find_elements(By.XPATH, "//input[@type='submit']")
            if submit_inputs:
                submit_inputs[0].click()
        else:
            submit_buttons[0].click()
        
        time.sleep(3)
        
        # Check for success indicators
        if any(text in driver.page_source for text in ['successfully', 'thank you', 'received', 'completed']):
            return {'success': True, 'details': 'Successfully submitted the form'}
        
        return {'success': False, 'details': 'Attempted to submit form but could not verify success'}
    
    except Exception as e:
        logger.exception(f"Website form error: {str(e)}")
        return {'success': False, 'details': f'Website form error: {str(e)}'}

def execute_email_task(params, account, strategy):
    """Execute email verification task"""
    # Email verification typically requires accessing the inbox
    # This is a placeholder as actual implementation would need email API integration
    return {'success': False, 'details': 'Email verification requires manual intervention or email API integration'}
