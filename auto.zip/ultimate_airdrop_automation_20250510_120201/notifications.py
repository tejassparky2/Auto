import logging
import os
import json
import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from urllib.parse import urlencode
from datetime import datetime

from app import db
from models import User, NotificationSettings, TaskHistory, Airdrop, Task, Account

logger = logging.getLogger(__name__)

# Notification event types
EVENT_TYPES = {
    'AIRDROP_ADDED': {
        'level': 'important',
        'title': 'New Airdrop Added',
        'description': 'A new airdrop has been added to your account'
    },
    'TASK_COMPLETED': {
        'level': 'important',
        'title': 'Task Completed Successfully',
        'description': 'A task was completed successfully'
    },
    'TASK_FAILED': {
        'level': 'important',
        'title': 'Task Failed',
        'description': 'A task has failed to execute'
    },
    'AIRDROP_COMPLETED': {
        'level': 'important',
        'title': 'Airdrop Completed',
        'description': 'An airdrop has been fully completed'
    },
    'ACCOUNT_LOCKED': {
        'level': 'critical',
        'title': 'Account Locked',
        'description': 'One of your social accounts has been locked or requires attention'
    },
    'PROXY_ERROR': {
        'level': 'important',
        'title': 'Proxy Server Error',
        'description': 'There is an issue with one of your proxy servers'
    },
    'RETRY_LIMIT_REACHED': {
        'level': 'important',
        'title': 'Task Retry Limit Reached',
        'description': 'A task has reached its retry limit and requires manual intervention'
    }
}

def send_notification(user_id, event_type, context=None):
    """
    Send a notification based on user's notification settings
    
    Args:
        user_id: ID of the user to notify
        event_type: Type of event (e.g., 'AIRDROP_ADDED', 'TASK_COMPLETED')
        context: Additional context data for the notification
    
    Returns:
        dict: Results of notification attempts
    """
    if event_type not in EVENT_TYPES:
        logger.error(f"Unknown event type: {event_type}")
        return {'success': False, 'error': 'Unknown event type'}
    
    event_config = EVENT_TYPES[event_type]
    notification_level = event_config['level']
    
    # Get user notification settings
    settings = NotificationSettings.query.filter_by(user_id=user_id).first()
    if not settings:
        logger.info(f"No notification settings for user {user_id}")
        return {'success': False, 'error': 'No notification settings'}
    
    # Check if the user wants to receive this level of notification
    if settings.notification_level == 'critical' and notification_level != 'critical':
        return {'success': True, 'skipped': 'User only wants critical notifications'}
    
    user = User.query.get(user_id)
    if not user:
        logger.error(f"User {user_id} not found")
        return {'success': False, 'error': 'User not found'}
    
    # Prepare notification content
    title = event_config['title']
    description = event_config['description']
    
    # Add context information if available
    content = f"{description}\n\n"
    if context:
        if 'airdrop_id' in context and context['airdrop_id']:
            airdrop = Airdrop.query.get(context['airdrop_id'])
            if airdrop:
                content += f"Airdrop: {airdrop.name}\n"
                content += f"URL: {airdrop.url}\n\n"
        
        if 'task_id' in context and context['task_id']:
            task = Task.query.get(context['task_id'])
            if task:
                content += f"Task: {task.description}\n"
                content += f"Type: {task.task_type}\n"
                content += f"Status: {task.status}\n\n"
        
        if 'account_id' in context and context['account_id']:
            account = Account.query.get(context['account_id'])
            if account:
                content += f"Account: {account.username} on {account.platform}\n\n"
        
        if 'details' in context and context['details']:
            content += f"Details: {context['details']}\n\n"
    
    content += f"Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC"
    
    # Track notification results
    results = {'success': True, 'channels': {}}
    
    # Send notifications through enabled channels
    if settings.email_notifications and settings.email:
        email_result = send_email_notification(settings.email, title, content)
        results['channels']['email'] = email_result
    
    if settings.telegram_notifications and settings.telegram_chat_id:
        telegram_result = send_telegram_notification(settings.telegram_chat_id, title, content)
        results['channels']['telegram'] = telegram_result
    
    if settings.slack_notifications and settings.slack_webhook_url:
        slack_result = send_slack_notification(settings.slack_webhook_url, title, content)
        results['channels']['slack'] = slack_result
    
    if settings.sms_notifications and settings.phone_number:
        sms_result = send_sms_notification(settings.phone_number, title, content)
        results['channels']['sms'] = sms_result
    
    return results

def send_email_notification(email_address, subject, content):
    """Send notification via email"""
    try:
        # This is just a placeholder - in production you'd use a service like SendGrid or SMTP
        # For demonstration purposes, we'll just log the email content
        logger.info(f"Email notification to {email_address}: {subject}")
        logger.info(f"Content: {content}")
        
        return {'success': True, 'message': 'Email notification sent'}
    except Exception as e:
        logger.error(f"Failed to send email notification: {str(e)}")
        return {'success': False, 'error': str(e)}

def send_telegram_notification(chat_id, title, content):
    """Send notification via Telegram"""
    try:
        telegram_bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
        if not telegram_bot_token:
            return {'success': False, 'error': 'No Telegram bot token configured'}
        
        url = f"https://api.telegram.org/bot{telegram_bot_token}/sendMessage"
        message = f"*{title}*\n\n{content}"
        
        payload = {
            'chat_id': chat_id,
            'text': message,
            'parse_mode': 'Markdown'
        }
        
        response = requests.post(url, data=payload)
        response.raise_for_status()
        
        return {'success': True, 'message': 'Telegram notification sent'}
    except Exception as e:
        logger.error(f"Failed to send Telegram notification: {str(e)}")
        return {'success': False, 'error': str(e)}

def send_slack_notification(webhook_url, title, content):
    """Send notification via Slack webhook"""
    try:
        message = {
            "blocks": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": title
                    }
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": content.replace('\n', '\n>')
                    }
                }
            ]
        }
        
        response = requests.post(webhook_url, json=message)
        response.raise_for_status()
        
        return {'success': True, 'message': 'Slack notification sent'}
    except Exception as e:
        logger.error(f"Failed to send Slack notification: {str(e)}")
        return {'success': False, 'error': str(e)}

def send_sms_notification(phone_number, title, content):
    """Send notification via SMS (Twilio)"""
    try:
        # This would typically use Twilio or a similar service
        # For demonstration purposes, we'll just log the SMS content
        logger.info(f"SMS notification to {phone_number}: {title}")
        logger.info(f"Content: {content[:160]}...")  # SMS length limitation
        
        return {'success': True, 'message': 'SMS notification sent (simulated)'}
    except Exception as e:
        logger.error(f"Failed to send SMS notification: {str(e)}")
        return {'success': False, 'error': str(e)}

# Event handler functions
def on_task_completed(task_id, account_id, details):
    """Handle task completion event"""
    task = Task.query.get(task_id)
    if not task:
        logger.error(f"Task {task_id} not found")
        return
    
    airdrop = Airdrop.query.get(task.airdrop_id)
    if not airdrop:
        logger.error(f"Airdrop {task.airdrop_id} not found")
        return
    
    # Send notification
    context = {
        'task_id': task_id,
        'airdrop_id': airdrop.id,
        'account_id': account_id,
        'details': details
    }
    
    send_notification(airdrop.user_id, 'TASK_COMPLETED', context)
    
    # Check if all tasks for this airdrop are completed
    pending_tasks = Task.query.filter_by(
        airdrop_id=airdrop.id
    ).filter(Task.status != 'completed').count()
    
    if pending_tasks == 0:
        # All tasks completed, send airdrop completion notification
        send_notification(airdrop.user_id, 'AIRDROP_COMPLETED', {'airdrop_id': airdrop.id})

def on_task_failed(task_id, account_id, details, retry_count, max_retries):
    """Handle task failure event"""
    task = Task.query.get(task_id)
    if not task:
        logger.error(f"Task {task_id} not found")
        return
    
    airdrop = Airdrop.query.get(task.airdrop_id)
    if not airdrop:
        logger.error(f"Airdrop {task.airdrop_id} not found")
        return
    
    # Send notification
    context = {
        'task_id': task_id,
        'airdrop_id': airdrop.id,
        'account_id': account_id,
        'details': details
    }
    
    # If retry limit reached, send specific notification
    if retry_count >= max_retries:
        context['details'] = f"Task has failed after {retry_count} attempts. {details}"
        send_notification(airdrop.user_id, 'RETRY_LIMIT_REACHED', context)
    else:
        send_notification(airdrop.user_id, 'TASK_FAILED', context)