import logging
from app import app
import scheduler
import init_data

# Setup logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    # Initialize default data (including user Tejas)
    logger.info("Initializing default data...")
    init_data.init_default_data()
    
    # Start the background scheduler for automated tasks
    logger.info("Starting background scheduler...")
    scheduler.start_scheduler()
    
    # Start the Flask application
    logger.info("Starting Flask application...")
    app.run(host="0.0.0.0", port=5000, debug=True)
