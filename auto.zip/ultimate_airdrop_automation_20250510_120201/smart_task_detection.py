import logging
import json
import re
import hashlib
import time
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin

from app import db
from models import Airdrop, Task, AIModel

logger = logging.getLogger(__name__)

class SmartTaskDetector:
    """
    Advanced task detection system that combines multiple approaches:
    - Pattern matching and regex
    - DOM structure analysis
    - Network request analysis
    - Visual element recognition
    - Historical task database matching
    """
    
    def __init__(self):
        self.load_task_patterns()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        }
        self.task_history_db = {}  # Will be populated from DB
        self.load_task_history()
    
    def load_task_patterns(self):
        """Load task detection patterns"""
        try:
            # Try to load from database first
            ai_model = AIModel.query.filter_by(
                model_type='pattern_matching',
                is_active=True
            ).order_by(AIModel.updated_at.desc()).first()
            
            if ai_model and ai_model.params:
                self.patterns = json.loads(ai_model.params)
                logger.info(f"Loaded patterns from AI model {ai_model.id}")
                return
        except Exception as e:
            logger.error(f"Error loading patterns from DB: {str(e)}")
        
        # Default patterns
        self.patterns = {
            'twitter': {
                'follow': [
                    r'(?i)follow\s+(?:us|me)?\s*(?:on)?\s*(?:twitter|x)?\s*[@:]?\s*(\w+)',
                    r'(?i)follow\s+\@(\w+)',
                    r'(?i)twitter\.com/(\w+)(?:\s|$)',
                    r'(?i)x\.com/(\w+)(?:\s|$)'
                ],
                'like': [
                    r'(?i)like\s+(?:our|the|this)?\s*(?:tweet|post|x|twitter)',
                    r'(?i)twitter\.com/\w+/status/(\d+).*like',
                    r'(?i)x\.com/\w+/status/(\d+).*like'
                ],
                'retweet': [
                    r'(?i)re(?:[\s-])?tweet\s+(?:our|the|this)?\s*(?:tweet|post)',
                    r'(?i)twitter\.com/\w+/status/(\d+).*retweet',
                    r'(?i)x\.com/\w+/status/(\d+).*retweet'
                ],
                'tweet': [
                    r'(?i)tweet\s+(?:about|with)',
                    r'(?i)post\s+(?:on|with)\s*(?:twitter|x)',
                    r'(?i)share\s+(?:on)\s*(?:twitter|x)'
                ],
                'comment': [
                    r'(?i)comment\s+(?:on|under|below)',
                    r'(?i)reply\s+(?:to|on|under)',
                    r'(?i)tag\s+(?:friends|people)'
                ]
            },
            'discord': {
                'join': [
                    r'(?i)join\s+(?:our|the)?\s*discord\s*(?:server|community|group)?',
                    r'(?i)discord\.(?:com|gg)/(?:invite/)?([a-zA-Z0-9]+)'
                ],
                'message': [
                    r'(?i)(?:send|post|write)\s+(?:a)?\s*message\s+(?:in|on|to)\s*(?:discord|the\s+server)',
                    r'(?i)chat\s+in\s+(?:the)?\s*(?:discord|server|channel)'
                ],
                'verify': [
                    r'(?i)verify\s+(?:yourself|your\s+account)?\s*(?:in|on|through)?\s*discord',
                    r'(?i)get\s+(?:verified|the\s+role)'
                ],
                'react': [
                    r'(?i)react\s+(?:to|with)',
                    r'(?i)add\s+(?:a)?\s*reaction'
                ]
            },
            'telegram': {
                'join': [
                    r'(?i)join\s+(?:our|the)?\s*telegram\s*(?:group|channel|community)?',
                    r'(?i)t\.me/([a-zA-Z0-9_]+)'
                ],
                'message': [
                    r'(?i)(?:send|post|write)\s+(?:a)?\s*message\s+(?:in|on|to)\s*(?:telegram|the\s+group|the\s+channel)',
                    r'(?i)chat\s+in\s+(?:the)?\s*(?:telegram|group|channel)'
                ]
            },
            'website': {
                'signup': [
                    r'(?i)sign[\s-]?up',
                    r'(?i)register\s+(?:an|your)?\s*account',
                    r'(?i)create\s+(?:an|your)?\s*account'
                ],
                'email': [
                    r'(?i)enter\s+(?:your)?\s*email',
                    r'(?i)submit\s+(?:your)?\s*email',
                    r'(?i)subscribe\s+(?:to)?'
                ],
                'wallet': [
                    r'(?i)connect\s+(?:your)?\s*wallet',
                    r'(?i)add\s+(?:your)?\s*(?:ethereum|eth|polygon|matic|binance|bnb|solana|sol|near)\s*(?:address|wallet)',
                    r'(?i)link\s+(?:your)?\s*wallet'
                ],
                'claim': [
                    r'(?i)claim\s+(?:your|the)?\s*(?:free)?\s*(?:tokens|airdrop|nft)',
                    r'(?i)mint\s+(?:your|the)?\s*(?:free)?\s*(?:nft|token)'
                ],
                'quiz': [
                    r'(?i)(?:answer|complete|solve|take)\s+(?:the|a|our)?\s*quiz',
                    r'(?i)(?:answer|complete|solve)\s+(?:the|a|our)?\s*questions'
                ],
                'swap': [
                    r'(?i)swap\s+(?:your|some)?\s*(?:tokens|coins|eth|btc)',
                    r'(?i)exchange\s+(?:your|some)?\s*(?:tokens|coins|eth|btc)'
                ],
                'bridge': [
                    r'(?i)bridge\s+(?:your|some)?\s*(?:tokens|eth|assets)',
                    r'(?i)transfer\s+(?:your|some)?\s*(?:tokens|eth|assets)\s+(?:to|from)'
                ],
                'stake': [
                    r'(?i)stake\s+(?:your|some)?\s*(?:tokens|coins|eth|sol)',
                    r'(?i)deposit\s+(?:your|some)?\s*(?:tokens|coins|eth|sol)'
                ]
            }
        }
    
    def load_task_history(self):
        """Load task history from database for better matching"""
        try:
            # Get all tasks from the database
            from models import Task
            tasks = Task.query.all()
            
            # Group by domain and task type
            for task in tasks:
                try:
                    # Get airdrop URL
                    airdrop = Airdrop.query.get(task.airdrop_id)
                    if not airdrop:
                        continue
                    
                    domain = urlparse(airdrop.url).netloc
                    
                    if domain not in self.task_history_db:
                        self.task_history_db[domain] = {}
                    
                    if task.task_type not in self.task_history_db[domain]:
                        self.task_history_db[domain][task.task_type] = []
                    
                    # Add task parameters
                    try:
                        params = json.loads(task.params)
                    except:
                        params = {}
                    
                    self.task_history_db[domain][task.task_type].append({
                        'task_id': task.id,
                        'params': params,
                        'description': task.description
                    })
                    
                except Exception as task_error:
                    logger.error(f"Error processing task {task.id}: {str(task_error)}")
            
            logger.info(f"Loaded {len(self.task_history_db)} domains into task history database")
            
        except Exception as e:
            logger.exception(f"Error loading task history: {str(e)}")
    
    def detect_tasks(self, airdrop_id, refresh=False):
        """
        Detect tasks for an airdrop using multiple methods
        
        Args:
            airdrop_id: ID of the airdrop to analyze
            refresh: Whether to refresh existing tasks
            
        Returns:
            list: Detected tasks
        """
        try:
            # Get airdrop
            airdrop = Airdrop.query.get(airdrop_id)
            if not airdrop:
                logger.error(f"Airdrop {airdrop_id} not found")
                return None
            
            # Check if airdrop already has tasks
            existing_tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
            if existing_tasks and not refresh:
                logger.info(f"Airdrop {airdrop_id} already has {len(existing_tasks)} tasks. Use refresh=True to detect new tasks.")
                return existing_tasks
            
            url = airdrop.url
            logger.info(f"Detecting tasks for airdrop {airdrop_id} at URL: {url}")
            
            # Get page content
            html, text_content = self._fetch_page_content(url)
            if not html:
                logger.error(f"Failed to fetch content from {url}")
                return None
            
            # Extract links for additional analysis
            links = self._extract_links(html, url)
            
            # Parse domain
            domain = urlparse(url).netloc
            
            # Detect tasks using different methods
            tasks = []
            
            # 1. Pattern-based text analysis
            pattern_tasks = self._detect_tasks_with_patterns(text_content, links, url, domain)
            tasks.extend(pattern_tasks)
            
            # 2. DOM structure analysis
            dom_tasks = self._detect_tasks_from_dom(html, url, domain)
            tasks.extend(dom_tasks)
            
            # 3. Check for known tasks from history
            history_tasks = self._detect_tasks_from_history(domain, url, html, text_content)
            tasks.extend(history_tasks)
            
            # 4. Analyze forms separately
            form_tasks = self._analyze_forms(html, url, domain)
            tasks.extend(form_tasks)
            
            # 5. Check for special web3 interactions
            web3_tasks = self._detect_web3_interactions(html, text_content, url, domain)
            tasks.extend(web3_tasks)
            
            # Remove duplicates
            unique_tasks = self._deduplicate_tasks(tasks)
            
            # Prioritize and refine tasks
            final_tasks = self._prioritize_tasks(unique_tasks, text_content)
            
            # Save tasks to database
            saved_tasks = self._save_tasks(final_tasks, airdrop_id, refresh)
            
            return saved_tasks
            
        except Exception as e:
            logger.exception(f"Error detecting tasks for airdrop {airdrop_id}: {str(e)}")
            return None
    
    def _fetch_page_content(self, url):
        """Fetch HTML and text content from a URL"""
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            html = response.text
            
            # Parse HTML to extract text
            soup = BeautifulSoup(html, 'html.parser')
            
            # Remove script and style elements
            for element in soup(['script', 'style', 'meta', 'noscript']):
                element.extract()
            
            # Get text
            text = soup.get_text()
            
            # Clean up text
            lines = (line.strip() for line in text.splitlines())
            text = '\n'.join(line for line in lines if line)
            
            return html, text
            
        except Exception as e:
            logger.error(f"Error fetching URL {url}: {str(e)}")
            return None, None
    
    def _extract_links(self, html, base_url):
        """Extract links from HTML with context"""
        links = []
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            for a in soup.find_all('a', href=True):
                href = a['href']
                # Convert relative URLs to absolute
                if not href.startswith(('http://', 'https://')):
                    href = urljoin(base_url, href)
                
                link_info = {
                    'url': href,
                    'text': a.get_text().strip(),
                    'title': a.get('title', '')
                }
                links.append(link_info)
            
            return links
        except Exception as e:
            logger.error(f"Error extracting links: {str(e)}")
            return []
    
    def _detect_tasks_with_patterns(self, text_content, links, url, domain):
        """Detect tasks using regex pattern matching"""
        tasks = []
        
        # Function to check text against patterns
        def check_patterns(platform, task_type, patterns):
            for pattern in patterns:
                matches = re.finditer(pattern, text_content)
                for match in matches:
                    context_start = max(0, match.start() - 100)
                    context_end = min(len(text_content), match.end() + 100)
                    context = text_content[context_start:context_end]
                    
                    task = self._create_task(platform, task_type, match, links, url, domain, context)
                    if task:
                        tasks.append(task)
        
        # Check each platform and task type
        for platform, task_types in self.patterns.items():
            for task_type, patterns in task_types.items():
                check_patterns(platform, task_type, patterns)
        
        return tasks
    
    def _detect_tasks_from_dom(self, html, url, domain):
        """Detect tasks by analyzing DOM structure"""
        tasks = []
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            # Check for Twitter elements
            twitter_elements = soup.find_all(["a", "div", "button"], 
                                           string=lambda s: s and any(kw in str(s).lower() for kw in 
                                                                     ["follow on twitter", "follow @", "follow us on twitter"]))
            
            for element in twitter_elements:
                # Try to extract username
                username = None
                if "@" in str(element):
                    username_match = re.search(r'@(\w+)', str(element))
                    if username_match:
                        username = username_match.group(1)
                
                href = element.get('href', '')
                if 'twitter.com/' in href or 'x.com/' in href:
                    parts = href.split('/')
                    for i, part in enumerate(parts):
                        if part in ['twitter.com', 'x.com'] and i+1 < len(parts):
                            username = parts[i+1].split('?')[0].split('#')[0]
                            break
                
                if username:
                    tasks.append({
                        'task_type': 'twitter_follow',
                        'description': f"Follow Twitter user @{username}",
                        'params': {
                            'username': username
                        },
                        'confidence': 0.9
                    })
            
            # Check for Discord elements
            discord_elements = soup.find_all(["a", "div", "button"], 
                                          string=lambda s: s and any(kw in str(s).lower() for kw in 
                                                                    ["join discord", "join our discord", "discord server"]))
            
            for element in discord_elements:
                # Try to extract invite
                invite_code = None
                href = element.get('href', '')
                if 'discord.gg/' in href or 'discord.com/invite/' in href:
                    if 'discord.gg/' in href:
                        invite_code = href.split('discord.gg/')[1].split('?')[0].split('#')[0]
                    else:
                        invite_code = href.split('discord.com/invite/')[1].split('?')[0].split('#')[0]
                
                if invite_code:
                    tasks.append({
                        'task_type': 'discord_join',
                        'description': f"Join Discord server",
                        'params': {
                            'invite_code': invite_code,
                            'invite_link': href
                        },
                        'confidence': 0.9
                    })
            
            # Check for Telegram elements
            telegram_elements = soup.find_all(["a", "div", "button"], 
                                           string=lambda s: s and any(kw in str(s).lower() for kw in 
                                                                     ["join telegram", "join our telegram", "telegram channel", "telegram group"]))
            
            for element in telegram_elements:
                # Try to extract group name
                group_name = None
                href = element.get('href', '')
                if 't.me/' in href:
                    group_name = href.split('t.me/')[1].split('?')[0].split('#')[0]
                
                if group_name:
                    tasks.append({
                        'task_type': 'telegram_join',
                        'description': f"Join Telegram group/channel {group_name}",
                        'params': {
                            'group_name': group_name,
                            'group_link': href
                        },
                        'confidence': 0.9
                    })
            
            # Check for wallet connection elements
            wallet_elements = soup.find_all(["button", "a", "div"], 
                                          string=lambda s: s and any(kw in str(s).lower() for kw in 
                                                                    ["connect wallet", "connect your wallet", "connect to wallet"]))
            
            for element in wallet_elements:
                tasks.append({
                    'task_type': 'wallet_connect',
                    'description': f"Connect your wallet",
                    'params': {
                        'url': url,
                        'element_text': element.get_text().strip()
                    },
                    'confidence': 0.9
                })
            
            return tasks
            
        except Exception as e:
            logger.error(f"Error detecting DOM tasks: {str(e)}")
            return []
    
    def _detect_tasks_from_history(self, domain, url, html, text_content):
        """Detect tasks by matching against historical task database"""
        tasks = []
        
        try:
            # Check if we have history for this domain
            if domain in self.task_history_db:
                domain_history = self.task_history_db[domain]
                
                # For each task type historically found on this domain
                for task_type, historical_tasks in domain_history.items():
                    # Check if any indicators of this task type exist in the content
                    task_platform = task_type.split('_')[0]
                    task_action = task_type.split('_')[1] if len(task_type.split('_')) > 1 else ''
                    
                    # Simple keyword matching for now
                    keywords = [task_platform, task_action]
                    
                    if any(keyword in text_content.lower() for keyword in keywords if keyword):
                        # Use the most recent historical task as a template
                        if historical_tasks:
                            latest_task = historical_tasks[-1]
                            
                            # Clone the task with the same parameters
                            tasks.append({
                                'task_type': task_type,
                                'description': latest_task['description'],
                                'params': latest_task['params'].copy(),
                                'confidence': 0.7,  # Lower confidence for history-based matches
                                'source': 'history'
                            })
            
            return tasks
            
        except Exception as e:
            logger.error(f"Error detecting tasks from history: {str(e)}")
            return []
    
    def _analyze_forms(self, html, url, domain):
        """Analyze forms to detect tasks"""
        tasks = []
        try:
            soup = BeautifulSoup(html, 'html.parser')
            forms = soup.find_all('form')
            
            for form in forms:
                # Check form purpose
                form_action = form.get('action', '')
                inputs = form.find_all(['input', 'textarea', 'select'])
                
                input_types = [inp.get('type', '') for inp in inputs]
                input_names = [inp.get('name', '') for inp in inputs]
                
                # Look for email signup forms
                if ('email' in input_types or any('email' in name.lower() for name in input_names)) and \
                   (not any(password_type in input_types for password_type in ['password', 'pwd'])):
                    tasks.append({
                        'task_type': 'website_email',
                        'description': f"Subscribe with email on {domain}",
                        'params': {
                            'url': url,
                            'form_action': form_action
                        },
                        'confidence': 0.85
                    })
                
                # Look for registration forms
                elif 'password' in input_types or any('password' in name.lower() for name in input_names):
                    tasks.append({
                        'task_type': 'website_signup',
                        'description': f"Create account on {domain}",
                        'params': {
                            'url': url,
                            'form_action': form_action
                        },
                        'confidence': 0.9
                    })
                
                # Look for wallet connection forms
                elif any(wallet_term in str(form).lower() for wallet_term in ['wallet', 'connect', 'eth', 'sol', 'address']):
                    tasks.append({
                        'task_type': 'wallet_connect',
                        'description': f"Connect wallet on {domain}",
                        'params': {
                            'url': url,
                            'form_action': form_action
                        },
                        'confidence': 0.85
                    })
            
            return tasks
            
        except Exception as e:
            logger.error(f"Error analyzing forms: {str(e)}")
            return []
    
    def _detect_web3_interactions(self, html, text_content, url, domain):
        """Detect web3-specific interactions"""
        tasks = []
        try:
            # Check for web3 indicators
            web3_indicators = {
                'swap': [
                    'swap', 'swapping', 'exchange', 'trade', 'trading', 'convert'
                ],
                'bridge': [
                    'bridge', 'bridging', 'transfer between chains', 'cross-chain'
                ],
                'stake': [
                    'stake', 'staking', 'deposit', 'earn', 'yield', 'rewards'
                ],
                'mint': [
                    'mint', 'minting', 'claim nft', 'get your nft', 'free nft'
                ],
                'farm': [
                    'farm', 'farming', 'yield farm', 'liquidity mining'
                ]
            }
            
            for action, keywords in web3_indicators.items():
                if any(keyword in text_content.lower() for keyword in keywords):
                    tasks.append({
                        'task_type': f'wallet_{action}',
                        'description': f"{action.title()} tokens on {domain}",
                        'params': {
                            'url': url,
                            'action': action
                        },
                        'confidence': 0.8
                    })
            
            # Check for blockchain indicators
            chains = {
                'ethereum': ['ethereum', 'eth', 'erc20', 'erc721'],
                'polygon': ['polygon', 'matic', 'polygon network'],
                'binance': ['binance', 'bnb', 'bsc', 'binance smart chain'],
                'solana': ['solana', 'sol'],
                'arbitrum': ['arbitrum', 'arbitrum one'],
                'optimism': ['optimism', 'op'],
                'avalanche': ['avalanche', 'avax'],
                'base': ['base', 'base chain', 'coinbase layer 2']
            }
            
            detected_chains = []
            for chain, keywords in chains.items():
                if any(keyword in text_content.lower() for keyword in keywords):
                    detected_chains.append(chain)
            
            # If we found chain information, add it to all wallet tasks
            if detected_chains:
                for task in tasks:
                    if task['task_type'].startswith('wallet_'):
                        task['params']['chains'] = detected_chains
            
            return tasks
            
        except Exception as e:
            logger.error(f"Error detecting web3 interactions: {str(e)}")
            return []
    
    def _create_task(self, platform, task_type, match, links, url, domain, context):
        """Create a task from a regex match"""
        full_task_type = f"{platform}_{task_type}"
        
        # Task creation helpers for different platforms
        if platform == 'twitter':
            if task_type == 'follow':
                # Try to extract username from match
                username = None
                if match.groups():
                    username = match.group(1)
                
                # If no username in match, look in links
                if not username:
                    for link in links:
                        link_url = link['url'].lower()
                        if 'twitter.com/' in link_url or 'x.com/' in link_url:
                            parts = link_url.split('/')
                            for i, part in enumerate(parts):
                                if part in ['twitter.com', 'x.com'] and i+1 < len(parts):
                                    if parts[i+1] not in ['search', 'hashtag', 'explore', 'home']:
                                        username = parts[i+1].split('?')[0]
                                        break
                
                if username:
                    return {
                        'task_type': full_task_type,
                        'description': f"Follow Twitter user @{username}",
                        'params': {
                            'username': username
                        },
                        'confidence': 0.9,
                        'context': context
                    }
            
            elif task_type == 'like':
                # Try to find a tweet URL
                tweet_url = None
                tweet_id = None
                
                if match.groups():
                    tweet_id = match.group(1)
                
                for link in links:
                    link_url = link['url'].lower()
                    if ('twitter.com/' in link_url or 'x.com/' in link_url) and '/status/' in link_url:
                        tweet_url = link['url']
                        # Extract tweet ID if we don't have it yet
                        if not tweet_id:
                            tweet_id = link_url.split('/status/')[1].split('?')[0].split('/')[0]
                        break
                
                if tweet_url:
                    return {
                        'task_type': full_task_type,
                        'description': "Like the tweet",
                        'params': {
                            'tweet_link': tweet_url,
                            'tweet_id': tweet_id
                        },
                        'confidence': 0.85,
                        'context': context
                    }
                else:
                    return {
                        'task_type': full_task_type,
                        'description': "Like a tweet",
                        'params': {
                            'context': context
                        },
                        'confidence': 0.6,
                        'context': context
                    }
            
            elif task_type == 'retweet':
                # Similar to like task
                tweet_url = None
                tweet_id = None
                
                if match.groups():
                    tweet_id = match.group(1)
                
                for link in links:
                    link_url = link['url'].lower()
                    if ('twitter.com/' in link_url or 'x.com/' in link_url) and '/status/' in link_url:
                        tweet_url = link['url']
                        if not tweet_id:
                            tweet_id = link_url.split('/status/')[1].split('?')[0].split('/')[0]
                        break
                
                if tweet_url:
                    return {
                        'task_type': full_task_type,
                        'description': "Retweet the tweet",
                        'params': {
                            'tweet_link': tweet_url,
                            'tweet_id': tweet_id
                        },
                        'confidence': 0.85,
                        'context': context
                    }
                else:
                    return {
                        'task_type': full_task_type,
                        'description': "Retweet a tweet",
                        'params': {
                            'context': context
                        },
                        'confidence': 0.6,
                        'context': context
                    }
            
            elif task_type == 'comment':
                # Similar to like/retweet
                tweet_url = None
                tweet_id = None
                
                for link in links:
                    link_url = link['url'].lower()
                    if ('twitter.com/' in link_url or 'x.com/' in link_url) and '/status/' in link_url:
                        tweet_url = link['url']
                        tweet_id = link_url.split('/status/')[1].split('?')[0].split('/')[0]
                        break
                
                if tweet_url:
                    return {
                        'task_type': full_task_type,
                        'description': "Comment on the tweet",
                        'params': {
                            'tweet_link': tweet_url,
                            'tweet_id': tweet_id
                        },
                        'confidence': 0.8,
                        'context': context
                    }
                else:
                    return {
                        'task_type': full_task_type,
                        'description': "Comment on a tweet",
                        'params': {
                            'context': context
                        },
                        'confidence': 0.6,
                        'context': context
                    }
        
        elif platform == 'discord':
            if task_type == 'join':
                # Try to find Discord invite
                invite_url = None
                invite_code = None
                
                # Check match for invite code
                if match.groups():
                    invite_code = match.group(1)
                
                # Check links for Discord invites
                for link in links:
                    link_url = link['url'].lower()
                    if 'discord.gg/' in link_url or 'discord.com/invite/' in link_url:
                        invite_url = link['url']
                        if 'discord.gg/' in link_url:
                            invite_code = link_url.split('discord.gg/')[1].split('?')[0].split('/')[0]
                        else:
                            invite_code = link_url.split('discord.com/invite/')[1].split('?')[0].split('/')[0]
                        break
                
                if invite_code:
                    if not invite_url:
                        invite_url = f"https://discord.gg/{invite_code}"
                    
                    return {
                        'task_type': full_task_type,
                        'description': f"Join Discord server with invite {invite_code}",
                        'params': {
                            'invite_code': invite_code,
                            'invite_link': invite_url
                        },
                        'confidence': 0.9,
                        'context': context
                    }
            
            elif task_type == 'message':
                # This requires more context
                channel_name = None
                
                # Try to extract channel from context
                channel_match = re.search(r'#(\w+[-\w]*)', context)
                if channel_match:
                    channel_name = channel_match.group(1)
                
                return {
                    'task_type': full_task_type,
                    'description': f"Send a message in Discord" + (f" channel #{channel_name}" if channel_name else ""),
                    'params': {
                        'channel': channel_name,
                        'context': context
                    },
                    'confidence': 0.7,
                    'context': context
                }
        
        elif platform == 'telegram':
            if task_type == 'join':
                # Try to find Telegram group/channel link
                group_url = None
                group_name = None
                
                # Check match for group name
                if match.groups():
                    group_name = match.group(1)
                
                # Check links for Telegram groups
                for link in links:
                    link_url = link['url'].lower()
                    if 't.me/' in link_url:
                        group_url = link['url']
                        group_name = link_url.split('t.me/')[1].split('?')[0].split('/')[0]
                        break
                
                if group_name:
                    if not group_url:
                        group_url = f"https://t.me/{group_name}"
                    
                    return {
                        'task_type': full_task_type,
                        'description': f"Join Telegram group/channel {group_name}",
                        'params': {
                            'group_name': group_name,
                            'group_link': group_url
                        },
                        'confidence': 0.9,
                        'context': context
                    }
        
        elif platform == 'website':
            if task_type == 'signup':
                return {
                    'task_type': full_task_type,
                    'description': f"Create account on {domain}",
                    'params': {
                        'url': url
                    },
                    'confidence': 0.8,
                    'context': context
                }
            
            elif task_type == 'email':
                return {
                    'task_type': full_task_type,
                    'description': f"Subscribe with email on {domain}",
                    'params': {
                        'url': url
                    },
                    'confidence': 0.8,
                    'context': context
                }
            
            elif task_type == 'wallet':
                # Try to determine wallet type
                wallet_type = None
                wallet_types = ['metamask', 'phantom', 'trustwallet', 'coinbase', 'walletconnect']
                
                for wtype in wallet_types:
                    if wtype.lower() in context.lower():
                        wallet_type = wtype
                        break
                
                return {
                    'task_type': full_task_type,
                    'description': f"Connect wallet on {domain}" + (f" ({wallet_type})" if wallet_type else ""),
                    'params': {
                        'url': url,
                        'wallet_type': wallet_type
                    },
                    'confidence': 0.85,
                    'context': context
                }
            
            elif task_type in ['claim', 'quiz', 'swap', 'bridge', 'stake']:
                return {
                    'task_type': full_task_type,
                    'description': f"{task_type.title()} on {domain}",
                    'params': {
                        'url': url
                    },
                    'confidence': 0.8,
                    'context': context
                }
        
        return None
    
    def _deduplicate_tasks(self, tasks):
        """Remove duplicate tasks"""
        unique_tasks = []
        task_signatures = set()
        
        for task in tasks:
            # Create a unique signature for the task
            task_type = task['task_type']
            
            # Use key parameters for the signature
            signature_parts = [task_type]
            
            if 'username' in task.get('params', {}):
                signature_parts.append(f"username:{task['params']['username']}")
            
            if 'tweet_id' in task.get('params', {}):
                signature_parts.append(f"tweet:{task['params']['tweet_id']}")
            
            if 'invite_code' in task.get('params', {}):
                signature_parts.append(f"invite:{task['params']['invite_code']}")
            
            if 'group_name' in task.get('params', {}):
                signature_parts.append(f"group:{task['params']['group_name']}")
            
            if 'wallet_type' in task.get('params', {}):
                signature_parts.append(f"wallet:{task['params']['wallet_type']}")
            
            signature = "|".join(signature_parts)
            
            if signature not in task_signatures:
                task_signatures.add(signature)
                unique_tasks.append(task)
        
        return unique_tasks
    
    def _prioritize_tasks(self, tasks, text_content):
        """Prioritize and refine tasks"""
        if not tasks:
            return []
        
        # Sort by confidence
        sorted_tasks = sorted(tasks, key=lambda x: x.get('confidence', 0), reverse=True)
        
        # Apply priority rules
        prioritized_tasks = []
        for task in sorted_tasks:
            # Skip low confidence tasks if we already have a better one of the same type
            if any(pt['task_type'] == task['task_type'] and pt.get('confidence', 0) > task.get('confidence', 0) + 0.2 for pt in prioritized_tasks):
                continue
            
            # Format the task for database storage
            final_task = {
                'task_type': task['task_type'],
                'description': task['description'],
                'params': task['params'],
                'priority': self._calculate_priority(task, text_content)
            }
            
            prioritized_tasks.append(final_task)
        
        return prioritized_tasks
    
    def _calculate_priority(self, task, text_content):
        """Calculate task priority (1-5, lower is higher priority)"""
        confidence = task.get('confidence', 0)
        
        # Base priority on confidence
        if confidence > 0.9:
            priority = 1
        elif confidence > 0.8:
            priority = 2
        elif confidence > 0.7:
            priority = 3
        elif confidence > 0.6:
            priority = 4
        else:
            priority = 5
        
        # Adjust based on task type importance
        task_type = task['task_type']
        if task_type in ['discord_join', 'telegram_join', 'wallet_connect']:
            priority -= 1  # Higher priority
        elif task_type in ['twitter_follow', 'twitter_like', 'twitter_retweet']:
            priority -= 1  # Higher priority
        elif 'wallet_' in task_type:
            priority -= 1  # Higher priority for wallet tasks
        
        # Adjust based on context importance
        context = task.get('context', '')
        important_terms = ['required', 'mandatory', 'must', 'step 1', 'first']
        if context and any(term in context.lower() for term in important_terms):
            priority -= 1
        
        # Ensure valid range
        return max(1, min(5, priority))
    
    def _save_tasks(self, tasks, airdrop_id, refresh=False):
        """Save tasks to database"""
        saved_tasks = []
        
        try:
            # Get existing tasks
            existing_tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
            
            # If refreshing, delete existing tasks
            if refresh and existing_tasks:
                for task in existing_tasks:
                    db.session.delete(task)
                db.session.commit()
                existing_tasks = []
            
            # Get existing task types to avoid duplicates
            existing_types = {task.task_type for task in existing_tasks}
            
            # Save new tasks
            for task_data in tasks:
                # Skip if this task type already exists (unless refreshing)
                if task_data['task_type'] in existing_types and not refresh:
                    continue
                
                task = Task()
                task.airdrop_id = airdrop_id
                task.task_type = task_data['task_type']
                task.description = task_data['description']
                task.params = json.dumps(task_data['params'])
                task.status = 'pending'
                task.priority = task_data.get('priority', 3)
                
                db.session.add(task)
                saved_tasks.append(task)
                existing_types.add(task_data['task_type'])
            
            db.session.commit()
            logger.info(f"Saved {len(saved_tasks)} new tasks for airdrop {airdrop_id}")
            
            # Return all tasks (existing + new)
            return existing_tasks + saved_tasks
            
        except Exception as e:
            logger.exception(f"Error saving tasks: {str(e)}")
            db.session.rollback()
            return []

# Function to detect tasks for an airdrop
def detect_airdrop_tasks(airdrop_id, refresh=False):
    """
    Detect tasks for an airdrop
    
    Args:
        airdrop_id: ID of the airdrop to analyze
        refresh: Whether to refresh existing tasks
        
    Returns:
        list: Detected tasks
    """
    detector = SmartTaskDetector()
    return detector.detect_tasks(airdrop_id, refresh)