import logging
import json
import time
import random
from datetime import datetime, timedelta
import threading
import queue
import networkx as nx
from concurrent.futures import ThreadPoolExecutor, as_completed

from app import db
from models import User, Account, Airdrop, Task, TaskExecution, TaskHistory, ProxyServer

logger = logging.getLogger(__name__)

class AdvancedDistributor:
    """
    Advanced airdrop task distribution system with:
    - Multi-threading for parallel execution
    - Smart account rotation to avoid detection
    - IP/fingerprint variation between accounts
    - Intelligent scheduling based on optimal times
    - Automatic retry and recovery
    - Distribution graph optimization
    """
    
    def __init__(self, max_workers=5):
        self.max_workers = max_workers
        self.task_queue = queue.Queue()
        self.results = {}
        self.proxy_pool = {}
        self.stop_event = threading.Event()
        self.executor = None
        self.load_proxies()
    
    def load_proxies(self):
        """Load proxies from database into memory pool"""
        try:
            proxies = ProxyServer.query.filter_by(status='active').all()
            for proxy in proxies:
                user_id = proxy.user_id
                if user_id not in self.proxy_pool:
                    self.proxy_pool[user_id] = []
                
                self.proxy_pool[user_id].append({
                    'id': proxy.id,
                    'url': proxy.get_proxy_url(),
                    'country': proxy.country,
                    'speed': proxy.speed or 1000,  # Default to 1000ms if no speed data
                    'last_used': None
                })
            
            logger.info(f"Loaded {len(proxies)} proxies into proxy pool")
        except Exception as e:
            logger.error(f"Error loading proxies: {str(e)}")
    
    def get_proxy(self, user_id, task_type=None):
        """Get a proxy for a user, optimized for the task type"""
        if user_id not in self.proxy_pool or not self.proxy_pool[user_id]:
            return None
        
        proxies = self.proxy_pool[user_id]
        
        # Filter for not recently used proxies
        now = datetime.utcnow()
        available_proxies = [p for p in proxies if not p['last_used'] or 
                           (now - p['last_used']).total_seconds() > 300]  # 5 minutes cooldown
        
        if not available_proxies:
            # If all proxies are on cooldown, use the least recently used
            proxies.sort(key=lambda x: x['last_used'] or datetime.min)
            proxy = proxies[0]
        else:
            # Prioritize faster proxies
            available_proxies.sort(key=lambda x: x['speed'])
            
            # Specific task type preferences
            if task_type and task_type.startswith('twitter_'):
                # For Twitter, use US proxies if available
                us_proxies = [p for p in available_proxies if p.get('country') == 'US']
                if us_proxies:
                    proxy = random.choice(us_proxies[:3])  # Choose from top 3 US proxies
                else:
                    proxy = available_proxies[0]
            else:
                # For other tasks, just use a random fast proxy
                proxy_count = min(3, len(available_proxies))
                proxy = random.choice(available_proxies[:proxy_count])
        
        # Mark proxy as used
        proxy['last_used'] = now
        return proxy
    
    def optimize_task_distribution(self, airdrop_id, account_ids=None, replicate=False):
        """
        Optimize task distribution for an airdrop across accounts
        
        Args:
            airdrop_id: ID of the airdrop to distribute
            account_ids: Optional list of specific account IDs to use
            replicate: If True, replicate all tasks to all accounts. If False,
                      distribute tasks intelligently across accounts
                      
        Returns:
            dict: Distribution plan
        """
        try:
            # Get airdrop and tasks
            airdrop = Airdrop.query.get(airdrop_id)
            if not airdrop:
                logger.error(f"Airdrop {airdrop_id} not found")
                return None
            
            tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
            if not tasks:
                logger.error(f"No tasks found for airdrop {airdrop_id}")
                return None
            
            # Get accounts
            if account_ids:
                accounts = Account.query.filter(Account.id.in_(account_ids)).all()
            else:
                accounts = Account.query.filter_by(user_id=airdrop.user_id).all()
            
            if not accounts:
                logger.error(f"No accounts found for airdrop {airdrop_id}")
                return None
            
            # Simple replication case
            if replicate:
                distribution_plan = {}
                for account in accounts:
                    distribution_plan[account.id] = [task.id for task in tasks]
                
                logger.info(f"Created replication plan: all {len(tasks)} tasks to all {len(accounts)} accounts")
                return distribution_plan
            
            # Complex optimization case
            return self._create_optimized_distribution(tasks, accounts)
            
        except Exception as e:
            logger.exception(f"Error optimizing task distribution: {str(e)}")
            return None
    
    def _create_optimized_distribution(self, tasks, accounts):
        """Create an optimized distribution plan using graph theory"""
        try:
            # Group tasks by platform
            task_groups = {}
            for task in tasks:
                platform = task.task_type.split('_')[0] if '_' in task.task_type else 'other'
                if platform not in task_groups:
                    task_groups[platform] = []
                task_groups[platform].append(task)
            
            # Group accounts by platform
            account_groups = {}
            for account in accounts:
                platform = account.platform
                if platform not in account_groups:
                    account_groups[platform] = []
                account_groups[platform].append(account)
            
            # Create a bipartite graph
            G = nx.Graph()
            
            # Add task nodes
            for task in tasks:
                G.add_node(f"task_{task.id}", type='task', priority=task.priority or 3)
            
            # Add account nodes
            for account in accounts:
                G.add_node(f"account_{account.id}", type='account', platform=account.platform)
            
            # Add edges between tasks and suitable accounts
            for task in tasks:
                task_platform = task.task_type.split('_')[0] if '_' in task.task_type else 'other'
                
                # Find suitable accounts for this task
                suitable_accounts = []
                
                # Direct platform match
                if task_platform in account_groups:
                    suitable_accounts.extend(account_groups[task_platform])
                
                # Web tasks can be done by any account
                if task_platform == 'website':
                    for platform, accts in account_groups.items():
                        suitable_accounts.extend(accts)
                
                # Wallet tasks need special accounts
                if task_platform == 'wallet':
                    if 'ethereum' in account_groups:
                        suitable_accounts.extend(account_groups['ethereum'])
                    if 'metamask' in account_groups:
                        suitable_accounts.extend(account_groups['metamask'])
                    if 'wallet' in account_groups:
                        suitable_accounts.extend(account_groups['wallet'])
                
                # Add edges to suitable accounts
                for account in suitable_accounts:
                    # Calculate edge weight based on account suitability
                    weight = 1.0  # Base weight
                    
                    # Adjust based on platform match
                    if account.platform == task_platform:
                        weight *= 0.5  # Lower is better
                    
                    # Adjust based on account task history
                    success_rate = self._get_account_success_rate(account.id, task.task_type)
                    if success_rate > 0:
                        weight *= (1.0 - success_rate)  # More successful = lower weight
                    
                    # Add the edge
                    G.add_edge(f"task_{task.id}", f"account_{account.id}", weight=weight)
            
            # Use minimum weight matching algorithm
            matching = nx.algorithms.bipartite.minimum_weight_matching(G, weight='weight')
            
            # Convert matching to distribution plan
            distribution_plan = {}
            for task_node, account_node in matching:
                # Extract IDs from node names
                if task_node.startswith('task_'):
                    task_id = int(task_node.split('_')[1])
                    account_id = int(account_node.split('_')[1])
                else:
                    task_id = int(account_node.split('_')[1])
                    account_id = int(task_node.split('_')[1])
                
                if account_id not in distribution_plan:
                    distribution_plan[account_id] = []
                
                distribution_plan[account_id].append(task_id)
            
            # Handle unmatched tasks (if any)
            matched_tasks = set()
            for account_id, task_ids in distribution_plan.items():
                matched_tasks.update(task_ids)
            
            unmatched_tasks = [task.id for task in tasks if task.id not in matched_tasks]
            
            if unmatched_tasks:
                # Distribute unmatched tasks round-robin
                account_ids = list(account_groups.get('other', accounts))
                for i, task_id in enumerate(unmatched_tasks):
                    account_id = account_ids[i % len(account_ids)].id
                    if account_id not in distribution_plan:
                        distribution_plan[account_id] = []
                    distribution_plan[account_id].append(task_id)
            
            logger.info(f"Created optimized distribution plan for {len(tasks)} tasks across {len(accounts)} accounts")
            return distribution_plan
            
        except Exception as e:
            logger.exception(f"Error creating optimized distribution: {str(e)}")
            
            # Fall back to simple round-robin distribution
            distribution_plan = {}
            for i, task in enumerate(tasks):
                account = accounts[i % len(accounts)]
                if account.id not in distribution_plan:
                    distribution_plan[account.id] = []
                distribution_plan[account.id].append(task.id)
            
            return distribution_plan
    
    def _get_account_success_rate(self, account_id, task_type):
        """Get the success rate for an account with a specific task type"""
        try:
            # Get recent executions (last 30)
            executions = TaskExecution.query.join(Task).filter(
                TaskExecution.account_id == account_id,
                Task.task_type == task_type
            ).order_by(TaskExecution.completed_at.desc()).limit(30).all()
            
            if not executions:
                return 0.0
            
            success_count = sum(1 for e in executions if e.status == 'success')
            return success_count / len(executions)
            
        except Exception as e:
            logger.error(f"Error getting account success rate: {str(e)}")
            return 0.0
    
    def calculate_execution_times(self, tasks, accounts):
        """
        Calculate optimal execution times for tasks to avoid detection
        
        Returns:
            dict: {task_id: execution_time}
        """
        execution_times = {}
        now = datetime.utcnow()
        
        # Group tasks by platform
        platform_tasks = {}
        for task in tasks:
            platform = task.task_type.split('_')[0] if '_' in task.task_type else 'other'
            if platform not in platform_tasks:
                platform_tasks[platform] = []
            platform_tasks[platform].append(task)
        
        # Calculate base delay between tasks of the same platform
        platform_delays = {
            'twitter': timedelta(minutes=random.randint(2, 5)),   # 2-5 minutes between Twitter tasks
            'discord': timedelta(minutes=random.randint(3, 8)),   # 3-8 minutes between Discord tasks
            'telegram': timedelta(minutes=random.randint(3, 7)),  # 3-7 minutes between Telegram tasks
            'website': timedelta(minutes=random.randint(1, 3)),   # 1-3 minutes between website tasks
            'wallet': timedelta(minutes=random.randint(5, 10)),   # 5-10 minutes between wallet tasks
            'other': timedelta(minutes=random.randint(2, 4))      # 2-4 minutes between other tasks
        }
        
        # Calculate execution times for each platform
        for platform, tasks in platform_tasks.items():
            # Sort tasks by priority
            sorted_tasks = sorted(tasks, key=lambda t: t.priority or 3)
            
            # Start time with small random offset
            next_time = now + timedelta(seconds=random.randint(30, 120))
            
            # Assign times to each task
            for task in sorted_tasks:
                execution_times[task.id] = next_time
                
                # Add delay for next task
                delay = platform_delays.get(platform, platform_delays['other'])
                # Add some randomness to delay
                jitter = timedelta(seconds=random.randint(-30, 30))
                next_time += delay + jitter
        
        return execution_times
    
    def execute_distribution_plan(self, airdrop_id, distribution_plan, execution_method='api'):
        """
        Execute a distribution plan
        
        Args:
            airdrop_id: ID of the airdrop to distribute
            distribution_plan: Distribution plan from optimize_task_distribution
            execution_method: 'api' or 'browser'
            
        Returns:
            bool: Success flag
        """
        try:
            # Get airdrop
            airdrop = Airdrop.query.get(airdrop_id)
            if not airdrop:
                logger.error(f"Airdrop {airdrop_id} not found")
                return False
            
            # Update airdrop status
            airdrop.status = 'in_progress'
            db.session.commit()
            
            # Get all tasks for this distribution
            all_task_ids = []
            for account_id, task_ids in distribution_plan.items():
                all_task_ids.extend(task_ids)
            
            tasks = Task.query.filter(Task.id.in_(all_task_ids)).all()
            task_map = {task.id: task for task in tasks}
            
            # Get all accounts for this distribution
            account_ids = list(distribution_plan.keys())
            accounts = Account.query.filter(Account.id.in_(account_ids)).all()
            account_map = {account.id: account for account in accounts}
            
            # Calculate optimal execution times
            execution_times = self.calculate_execution_times(tasks, accounts)
            
            # Organize execution plan
            execution_plan = []
            for account_id, task_ids in distribution_plan.items():
                account = account_map.get(account_id)
                if not account:
                    continue
                
                # Get proxy for this account
                proxy = self.get_proxy(airdrop.user_id)
                
                for task_id in task_ids:
                    task = task_map.get(task_id)
                    if not task:
                        continue
                    
                    # Create execution item
                    execution_item = {
                        'task_id': task_id,
                        'account_id': account_id,
                        'execution_time': execution_times.get(task_id, datetime.utcnow()),
                        'execution_method': execution_method,
                        'proxy': proxy
                    }
                    
                    execution_plan.append(execution_item)
            
            # Sort execution plan by time
            execution_plan.sort(key=lambda x: x['execution_time'])
            
            # Execute the plan
            self.execute_plan(execution_plan, airdrop_id)
            
            return True
            
        except Exception as e:
            logger.exception(f"Error executing distribution plan: {str(e)}")
            return False
    
    def execute_plan(self, execution_plan, airdrop_id):
        """Execute tasks according to the execution plan"""
        # Set up the thread pool
        self.executor = ThreadPoolExecutor(max_workers=self.max_workers)
        futures = []
        
        try:
            # Submit initial batch of tasks
            active_count = 0
            for item in execution_plan:
                # Stop if requested
                if self.stop_event.is_set():
                    break
                
                # Calculate delay until execution time
                now = datetime.utcnow()
                execution_time = item['execution_time']
                
                if execution_time > now:
                    delay = (execution_time - now).total_seconds()
                else:
                    delay = 0
                
                # Schedule execution with delay
                future = self.executor.submit(
                    self._delayed_execute_task,
                    item['task_id'],
                    item['account_id'],
                    item['execution_method'],
                    item['proxy'],
                    delay
                )
                futures.append(future)
                
                active_count += 1
                
                # If we've scheduled all available workers, wait for some to complete
                if active_count >= self.max_workers:
                    # Wait for at least one task to complete
                    try:
                        done, not_done = wait(futures, return_when='FIRST_COMPLETED', timeout=60)
                        
                        # Process completed tasks
                        for future in done:
                            try:
                                result = future.result()
                                if result:
                                    task_id, success = result
                                    self.results[task_id] = success
                            except Exception as exec_error:
                                logger.error(f"Error processing task result: {str(exec_error)}")
                            
                            # Remove from futures list
                            futures.remove(future)
                            active_count -= 1
                    except Exception as wait_error:
                        logger.error(f"Error waiting for tasks: {str(wait_error)}")
            
            # Wait for all remaining tasks to complete
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result:
                        task_id, success = result
                        self.results[task_id] = success
                except Exception as exec_error:
                    logger.error(f"Error processing task result: {str(exec_error)}")
            
            # Update airdrop status
            try:
                airdrop = Airdrop.query.get(airdrop_id)
                if airdrop:
                    # Check if all tasks are completed
                    tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
                    completed_count = sum(1 for t in tasks if t.status in ['completed', 'failed'])
                    
                    if completed_count == len(tasks):
                        airdrop.status = 'completed'
                    else:
                        airdrop.status = 'partially_completed'
                    
                    db.session.commit()
            except Exception as status_error:
                logger.error(f"Error updating airdrop status: {str(status_error)}")
            
        except Exception as e:
            logger.exception(f"Error in execute_plan: {str(e)}")
        finally:
            # Clean up
            self.executor.shutdown(wait=False)
            self.executor = None
    
    def _delayed_execute_task(self, task_id, account_id, execution_method, proxy, delay):
        """Execute a task after a delay"""
        try:
            if delay > 0:
                time.sleep(delay)
            
            # Check if we should stop
            if self.stop_event.is_set():
                return None
            
            # Execute task
            success = self._execute_task(task_id, account_id, execution_method, proxy)
            return (task_id, success)
            
        except Exception as e:
            logger.exception(f"Error in _delayed_execute_task for task {task_id}: {str(e)}")
            return (task_id, False)
    
    def _execute_task(self, task_id, account_id, execution_method, proxy):
        """Execute a single task"""
        try:
            # Get task and account
            task = Task.query.get(task_id)
            account = Account.query.get(account_id)
            
            if not task or not account:
                logger.error(f"Task {task_id} or account {account_id} not found")
                return False
            
            # Update task status
            task.status = 'in_progress'
            db.session.commit()
            
            success = False
            error_details = None
            
            # Execute task based on method
            if execution_method == 'api':
                # Try API execution first
                try:
                    # Check task type
                    if task.task_type.startswith('wallet_'):
                        # Use web3 automation
                        import web3_automation
                        success = web3_automation.execute_wallet_task(task_id, account_id)
                    else:
                        # Use API automation
                        import api_automation
                        success = api_automation.execute_airdrop_api(task.airdrop_id, account_id)
                except Exception as api_error:
                    logger.error(f"API execution failed for task {task_id}: {str(api_error)}")
                    error_details = str(api_error)
                    
                    # Fall back to browser automation
                    try:
                        import automation
                        import learning
                        
                        # Get strategy
                        strategy = learning.get_best_strategy(task.task_type, account.platform)
                        
                        # Set proxy if available
                        if proxy:
                            strategy['proxy'] = proxy['url']
                        
                        # Execute task
                        start_time = time.time()
                        result = automation.execute_task(task.task_type, task.get_params(), account, strategy)
                        execution_time = time.time() - start_time
                        
                        success = result['success']
                        if not success:
                            error_details = result.get('details', None)
                        
                        # Record execution
                        execution = TaskExecution()
                        execution.task_id = task_id
                        execution.account_id = account_id
                        execution.status = 'success' if success else 'failure'
                        execution.details = result.get('details', '')
                        execution.execution_time = execution_time
                        execution.started_at = datetime.utcnow() - timedelta(seconds=execution_time)
                        execution.completed_at = datetime.utcnow()
                        
                        db.session.add(execution)
                        
                        # Update task status
                        task.status = 'completed' if success else 'failed'
                        
                        db.session.commit()
                    except Exception as browser_error:
                        logger.error(f"Browser execution also failed for task {task_id}: {str(browser_error)}")
                        error_details = f"API Error: {error_details}\nBrowser Error: {str(browser_error)}"
                        
                        # Update task status
                        task.status = 'failed'
                        
                        # Create execution record
                        execution = TaskExecution()
                        execution.task_id = task_id
                        execution.account_id = account_id
                        execution.status = 'failure'
                        execution.details = error_details
                        execution.execution_time = 0.0
                        execution.started_at = datetime.utcnow()
                        execution.completed_at = datetime.utcnow()
                        
                        db.session.add(execution)
                        db.session.commit()
            else:
                # Use browser automation directly
                try:
                    import automation
                    import learning
                    
                    # Get strategy
                    strategy = learning.get_best_strategy(task.task_type, account.platform)
                    
                    # Set proxy if available
                    if proxy:
                        strategy['proxy'] = proxy['url']
                    
                    # Execute task
                    start_time = time.time()
                    result = automation.execute_task(task.task_type, task.get_params(), account, strategy)
                    execution_time = time.time() - start_time
                    
                    success = result['success']
                    if not success:
                        error_details = result.get('details', None)
                    
                    # Record execution
                    execution = TaskExecution()
                    execution.task_id = task_id
                    execution.account_id = account_id
                    execution.status = 'success' if success else 'failure'
                    execution.details = result.get('details', '')
                    execution.execution_time = execution_time
                    execution.started_at = datetime.utcnow() - timedelta(seconds=execution_time)
                    execution.completed_at = datetime.utcnow()
                    
                    db.session.add(execution)
                    
                    # Update task status
                    task.status = 'completed' if success else 'failed'
                    
                    db.session.commit()
                except Exception as browser_error:
                    logger.error(f"Browser execution failed for task {task_id}: {str(browser_error)}")
                    error_details = str(browser_error)
                    
                    # Update task status
                    task.status = 'failed'
                    
                    # Create execution record
                    execution = TaskExecution()
                    execution.task_id = task_id
                    execution.account_id = account_id
                    execution.status = 'failure'
                    execution.details = error_details
                    execution.execution_time = 0.0
                    execution.started_at = datetime.utcnow()
                    execution.completed_at = datetime.utcnow()
                    
                    db.session.add(execution)
                    db.session.commit()
            
            # Process error with error handler if task failed
            if not success and error_details:
                try:
                    import error_handler
                    handler = error_handler.ErrorHandler()
                    analysis = handler.analyze_error(
                        error_details,
                        task.task_type,
                        account.platform,
                        {
                            'task_id': task_id,
                            'account_id': account_id,
                            'execution_method': execution_method
                        }
                    )
                    
                    # Save friendly error message to task
                    friendly_error = error_handler.format_user_friendly_error(analysis)
                    task.result = json.dumps({
                        'success': False,
                        'error': friendly_error,
                        'suggestions': analysis.get('specific_suggestions', [])
                    })
                    
                    db.session.commit()
                except Exception as eh_error:
                    logger.error(f"Error handling task error: {str(eh_error)}")
            
            return success
            
        except Exception as e:
            logger.exception(f"Error executing task {task_id}: {str(e)}")
            
            # Update task status
            try:
                task = Task.query.get(task_id)
                if task:
                    task.status = 'failed'
                    
                    # Create execution record
                    execution = TaskExecution()
                    execution.task_id = task_id
                    execution.account_id = account_id
                    execution.status = 'failure'
                    execution.details = f"Unexpected error: {str(e)}"
                    execution.execution_time = 0.0
                    execution.started_at = datetime.utcnow()
                    execution.completed_at = datetime.utcnow()
                    
                    db.session.add(execution)
                    db.session.commit()
            except Exception as db_error:
                logger.error(f"Error updating task status: {str(db_error)}")
            
            return False
    
    def stop_execution(self):
        """Stop execution of all tasks"""
        self.stop_event.set()
        
        if self.executor:
            self.executor.shutdown(wait=False)
            self.executor = None
        
        logger.info("Stopped execution of all tasks")

# Create a function to distribute and execute an airdrop
def distribute_and_execute_airdrop(airdrop_id, account_ids=None, replicate=False, execution_method='api'):
    """
    Distribute and execute an airdrop with advanced optimization
    
    Args:
        airdrop_id: ID of the airdrop to distribute
        account_ids: Optional list of specific account IDs to use
        replicate: If True, replicate all tasks to all accounts. If False,
                  distribute tasks intelligently across accounts
        execution_method: 'api' or 'browser'
        
    Returns:
        bool: Success flag
    """
    try:
        # Create distributor
        distributor = AdvancedDistributor()
        
        # Create distribution plan
        distribution_plan = distributor.optimize_task_distribution(airdrop_id, account_ids, replicate)
        
        if not distribution_plan:
            logger.error(f"Failed to create distribution plan for airdrop {airdrop_id}")
            return False
        
        # Execute the plan
        success = distributor.execute_distribution_plan(airdrop_id, distribution_plan, execution_method)
        
        return success
    
    except Exception as e:
        logger.exception(f"Error distributing and executing airdrop {airdrop_id}: {str(e)}")
        return False