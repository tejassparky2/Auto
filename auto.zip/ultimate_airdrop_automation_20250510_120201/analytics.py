import logging
import json
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import math

from app import db
from models import TaskHistory, Task, Account, Airdrop, LearningData, User

logger = logging.getLogger(__name__)

def get_user_performance_metrics(user_id, time_period=None):
    """
    Get performance metrics for a specific user
    
    Args:
        user_id: ID of the user
        time_period: Time period to analyze (e.g., '7d', '30d', 'all')
    
    Returns:
        dict: Performance metrics
    """
    try:
        # Define time range based on period
        start_date = None
        if time_period:
            now = datetime.utcnow()
            if time_period == '1d':
                start_date = now - timedelta(days=1)
            elif time_period == '7d':
                start_date = now - timedelta(days=7)
            elif time_period == '30d':
                start_date = now - timedelta(days=30)
            elif time_period == '90d':
                start_date = now - timedelta(days=90)
        
        # Base query for user's task histories
        base_query = TaskHistory.query.join(Task).join(Airdrop).filter(
            Airdrop.user_id == user_id
        )
        
        if start_date:
            base_query = base_query.filter(TaskHistory.timestamp >= start_date)
        
        # Get all task histories
        task_histories = base_query.all()
        
        # Initialize metrics
        metrics = {
            'total_executions': len(task_histories),
            'success_count': sum(1 for h in task_histories if h.status == 'success'),
            'failure_count': sum(1 for h in task_histories if h.status == 'failed'),
            'success_rate': 0,
            'avg_execution_time': 0,
            'total_airdrops_completed': 0,
            'total_tasks_completed': 0,
            'platform_success_rates': {},
            'task_type_success_rates': {},
            'account_success_rates': {},
            'hourly_distribution': {},
            'daily_distribution': {},
            'common_errors': []
        }
        
        # Calculate success rate
        if metrics['total_executions'] > 0:
            metrics['success_rate'] = (metrics['success_count'] / metrics['total_executions']) * 100
        
        # Calculate average execution time
        execution_times = [h.execution_time for h in task_histories if h.execution_time]
        if execution_times:
            metrics['avg_execution_time'] = sum(execution_times) / len(execution_times)
        
        # Count completed airdrops
        completed_airdrops = Airdrop.query.filter_by(
            user_id=user_id, 
            status='completed'
        ).count()
        metrics['total_airdrops_completed'] = completed_airdrops
        
        # Count completed tasks
        completed_tasks = Task.query.join(Airdrop).filter(
            Airdrop.user_id == user_id,
            Task.status == 'completed'
        ).count()
        metrics['total_tasks_completed'] = completed_tasks
        
        # Platform success rates
        platform_data = defaultdict(lambda: {'success': 0, 'total': 0})
        
        for history in task_histories:
            if history.account_id:
                account = Account.query.get(history.account_id)
                if account:
                    platform = account.platform.lower()
                    platform_data[platform]['total'] += 1
                    if history.status == 'success':
                        platform_data[platform]['success'] += 1
        
        # Calculate success rates for each platform
        for platform, data in platform_data.items():
            if data['total'] > 0:
                metrics['platform_success_rates'][platform] = (data['success'] / data['total']) * 100
        
        # Task type success rates
        task_type_data = defaultdict(lambda: {'success': 0, 'total': 0})
        
        for history in task_histories:
            task = Task.query.get(history.task_id)
            if task:
                task_type = task.task_type
                task_type_data[task_type]['total'] += 1
                if history.status == 'success':
                    task_type_data[task_type]['success'] += 1
        
        # Calculate success rates for each task type
        for task_type, data in task_type_data.items():
            if data['total'] > 0:
                metrics['task_type_success_rates'][task_type] = (data['success'] / data['total']) * 100
        
        # Account success rates
        account_data = defaultdict(lambda: {'success': 0, 'total': 0})
        
        for history in task_histories:
            if history.account_id:
                account_data[history.account_id]['total'] += 1
                if history.status == 'success':
                    account_data[history.account_id]['success'] += 1
        
        # Calculate success rates for each account
        for account_id, data in account_data.items():
            if data['total'] > 0:
                account = Account.query.get(account_id)
                if account:
                    account_name = f"{account.platform} - {account.username}"
                    metrics['account_success_rates'][account_name] = (data['success'] / data['total']) * 100
        
        # Time-based distributions
        hourly_counts = defaultdict(int)
        daily_counts = defaultdict(int)
        
        for history in task_histories:
            hour = history.timestamp.hour
            day = history.timestamp.strftime('%A')  # Day name
            
            hourly_counts[hour] += 1
            daily_counts[day] += 1
        
        # Convert to percentages
        total_count = len(task_histories)
        if total_count > 0:
            for hour, count in hourly_counts.items():
                metrics['hourly_distribution'][hour] = (count / total_count) * 100
            
            for day, count in daily_counts.items():
                metrics['daily_distribution'][day] = (count / total_count) * 100
        
        # Extract common errors
        error_counter = Counter()
        
        for history in task_histories:
            if history.status == 'failed' and history.details:
                # Extract error type from details
                error_type = extract_error_type(history.details)
                if error_type:
                    error_counter[error_type] += 1
        
        # Get top errors
        metrics['common_errors'] = [
            {'error': error, 'count': count}
            for error, count in error_counter.most_common(5)
        ]
        
        return metrics
    
    except Exception as e:
        logger.exception(f"Error getting user performance metrics: {str(e)}")
        return {'error': str(e)}

def extract_error_type(error_details):
    """Extract error type from error details"""
    # Simple extraction based on common patterns
    if not error_details:
        return "Unknown Error"
    
    error_text = error_details.lower()
    
    if "rate limit" in error_text or "too many requests" in error_text:
        return "Rate Limit Exceeded"
    elif "login" in error_text and ("failed" in error_text or "error" in error_text):
        return "Authentication Failed"
    elif "element not found" in error_text or "could not find" in error_text:
        return "Element Not Found"
    elif "timeout" in error_text:
        return "Timeout"
    elif "captcha" in error_text:
        return "Captcha Detected"
    elif "permission" in error_text or "unauthorized" in error_text:
        return "Permission Denied"
    elif "network" in error_text or "connection" in error_text:
        return "Network Error"
    elif "proxy" in error_text:
        return "Proxy Error"
    else:
        # Try to extract the first sentence or meaningful chunk
        parts = error_details.split('.')
        if parts:
            return parts[0][:50] + ("..." if len(parts[0]) > 50 else "")
        return "Unknown Error"

def get_learning_progress():
    """
    Get the learning progress across all task types and platforms
    
    Returns:
        dict: Learning progress data
    """
    try:
        learning_data = LearningData.query.all()
        
        progress = {
            'task_types': set(),
            'platforms': set(),
            'strategies': [],
            'success_rates': {},
            'improvement_rates': {},
            'total_attempts': 0,
            'total_success': 0
        }
        
        for data in learning_data:
            progress['task_types'].add(data.task_type)
            progress['platforms'].add(data.platform)
            
            # Get strategy
            strategy = data.get_strategy()
            if strategy:
                progress['strategies'].append({
                    'task_type': data.task_type,
                    'platform': data.platform,
                    'strategy': strategy
                })
            
            # Calculate success rate
            total_attempts = data.success_count + data.failure_count
            if total_attempts > 0:
                success_rate = (data.success_count / total_attempts) * 100
                key = f"{data.task_type}_{data.platform}"
                progress['success_rates'][key] = success_rate
            
            progress['total_attempts'] += total_attempts
            progress['total_success'] += data.success_count
        
        # Convert sets to lists for JSON serialization
        progress['task_types'] = list(progress['task_types'])
        progress['platforms'] = list(progress['platforms'])
        
        # Calculate overall success rate
        if progress['total_attempts'] > 0:
            progress['overall_success_rate'] = (progress['total_success'] / progress['total_attempts']) * 100
        else:
            progress['overall_success_rate'] = 0
        
        return progress
    
    except Exception as e:
        logger.exception(f"Error getting learning progress: {str(e)}")
        return {'error': str(e)}

def get_task_difficulty(task_type, platform=None):
    """
    Estimate the difficulty of a task based on historical performance
    
    Args:
        task_type: Type of task
        platform: Optional platform filter
    
    Returns:
        float: Difficulty score (0-10, where 10 is most difficult)
    """
    try:
        # Get task history for this task type
        query = TaskHistory.query.join(Task).filter(Task.task_type == task_type)
        
        if platform:
            query = query.join(Account).filter(Account.platform == platform)
        
        histories = query.all()
        
        if not histories:
            # No history, assume medium difficulty
            return 5.0
        
        # Calculate success rate
        success_count = sum(1 for h in histories if h.status == 'success')
        total_count = len(histories)
        success_rate = (success_count / total_count) if total_count > 0 else 0
        
        # Calculate average number of retries
        retry_data = db.session.query(
            Task.id,
            Task.retry_count
        ).filter(Task.task_type == task_type).all()
        
        if retry_data:
            avg_retries = sum(item[1] for item in retry_data) / len(retry_data)
        else:
            avg_retries = 0
        
        # Calculate average execution time
        execution_times = [h.execution_time for h in histories if h.execution_time]
        avg_execution_time = sum(execution_times) / len(execution_times) if execution_times else 0
        
        # Normalize execution time (assume anything over 60s is "slow")
        normalized_time = min(avg_execution_time / 60, 1)
        
        # Calculate difficulty score based on inverse success rate, retries, and execution time
        # Success rate contributes 70%, retries 20%, execution time 10%
        difficulty_score = (
            (1 - success_rate) * 0.7 * 10 +  # 0-7 points from success rate
            min(avg_retries, 3) / 3 * 0.2 * 10 +  # 0-2 points from retries (cap at 3)
            normalized_time * 0.1 * 10  # 0-1 points from execution time
        )
        
        return round(difficulty_score, 1)
    
    except Exception as e:
        logger.exception(f"Error calculating task difficulty: {str(e)}")
        return 5.0  # Default medium difficulty on error

def recommend_optimal_accounts(task_type, available_account_ids=None):
    """
    Recommend the best accounts for a specific task type
    
    Args:
        task_type: Type of task
        available_account_ids: Optional list of account IDs to choose from
    
    Returns:
        list: Recommended accounts in order of preference
    """
    try:
        # Determine platform for this task type
        platform = None
        if task_type.startswith('twitter_'):
            platform = 'twitter'
        elif task_type.startswith('discord_'):
            platform = 'discord'
        elif task_type.startswith('telegram_'):
            platform = 'telegram'
        
        # Base query for accounts
        account_query = Account.query
        
        # Filter by platform if determined
        if platform:
            account_query = account_query.filter_by(platform=platform)
        
        # Filter by available account IDs if provided
        if available_account_ids:
            account_query = account_query.filter(Account.id.in_(available_account_ids))
        
        # Get all matching accounts
        accounts = account_query.all()
        
        if not accounts:
            return []
        
        # Calculate success rates for each account on this task type
        account_scores = []
        
        for account in accounts:
            # Get task histories for this account and task type
            histories = TaskHistory.query.join(Task).filter(
                TaskHistory.account_id == account.id,
                Task.task_type == task_type
            ).all()
            
            if histories:
                # Calculate success rate
                success_count = sum(1 for h in histories if h.status == 'success')
                total_count = len(histories)
                success_rate = (success_count / total_count) if total_count > 0 else 0
                
                # Calculate recent performance (last 10 attempts)
                recent_histories = histories[-10:] if len(histories) > 10 else histories
                recent_success = sum(1 for h in recent_histories if h.status == 'success')
                recent_rate = (recent_success / len(recent_histories)) if recent_histories else 0
                
                # Score is weighted 40% on overall success rate, 60% on recent performance
                score = (success_rate * 0.4) + (recent_rate * 0.6)
            else:
                # No history, assign base score
                score = 0.5  # Neutral score for untested accounts
            
            account_scores.append((account, score))
        
        # Sort by score (highest first)
        sorted_accounts = [
            {
                'id': account.id,
                'platform': account.platform,
                'username': account.username,
                'score': score,
                'recommended': True if i < 3 else False  # Mark top 3 as recommended
            }
            for i, (account, score) in enumerate(sorted(account_scores, key=lambda x: x[1], reverse=True))
        ]
        
        return sorted_accounts
    
    except Exception as e:
        logger.exception(f"Error recommending optimal accounts: {str(e)}")
        return []

def get_system_stats():
    """
    Get overall system statistics
    
    Returns:
        dict: System statistics
    """
    try:
        stats = {
            'user_count': User.query.count(),
            'airdrop_count': Airdrop.query.count(),
            'task_count': Task.query.count(),
            'account_count': Account.query.count(),
            'execution_count': TaskHistory.query.count(),
            'success_rate': 0,
            'platform_distribution': {},
            'task_type_distribution': {},
            'daily_executions': []
        }
        
        # Success rate
        success_count = TaskHistory.query.filter_by(status='success').count()
        if stats['execution_count'] > 0:
            stats['success_rate'] = (success_count / stats['execution_count']) * 100
        
        # Platform distribution
        platform_counts = db.session.query(
            Account.platform, 
            db.func.count(Account.id)
        ).group_by(Account.platform).all()
        
        for platform, count in platform_counts:
            stats['platform_distribution'][platform] = count
        
        # Task type distribution
        task_type_counts = db.session.query(
            Task.task_type, 
            db.func.count(Task.id)
        ).group_by(Task.task_type).all()
        
        for task_type, count in task_type_counts:
            stats['task_type_distribution'][task_type] = count
        
        # Daily executions (last 7 days)
        last_week = datetime.utcnow() - timedelta(days=7)
        
        daily_counts = db.session.query(
            db.func.date(TaskHistory.timestamp),
            db.func.count(TaskHistory.id)
        ).filter(TaskHistory.timestamp >= last_week).group_by(
            db.func.date(TaskHistory.timestamp)
        ).all()
        
        for date, count in daily_counts:
            stats['daily_executions'].append({
                'date': date.strftime('%Y-%m-%d'),
                'count': count
            })
        
        return stats
    
    except Exception as e:
        logger.exception(f"Error getting system stats: {str(e)}")
        return {'error': str(e)}