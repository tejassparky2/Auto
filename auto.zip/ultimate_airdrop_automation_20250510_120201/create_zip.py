import os
import zipfile
import datetime

def create_project_zip():
    """Create a zip file of the entire project"""
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    zip_filename = f"ultimate_airdrop_automation_{timestamp}.zip"
    
    # Files to exclude
    exclude = [
        '.git', '__pycache__', '.venv', '.env', 'venv',
        'node_modules', 'dist', 'build', 'instance',
        '.DS_Store', '.vscode', '.idea', '.pytest_cache',
        'ultimate_airdrop_automation_*.zip'  # Exclude previous zip files
    ]
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude]
            
            for file in files:
                # Skip if file is in excluded list
                if file in exclude or file == zip_filename:
                    continue
                
                file_path = os.path.join(root, file)
                # Skip hidden files
                if '/.' in file_path or file.startswith('.'):
                    continue
                
                # Add file to zip
                zipf.write(file_path)
    
    print(f"Created zip file: {zip_filename}")
    return zip_filename

if __name__ == "__main__":
    create_project_zip()
