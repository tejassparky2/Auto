import logging
import json
import time
import os
import base64
import hashlib
from datetime import datetime
from urllib.parse import urlparse, urljoin
import requests
import threading
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

from app import db
from models import Account, Airdrop, Task, TaskExecution, LearningData

logger = logging.getLogger(__name__)

class BrowserRecorder:
    """
    Advanced browser recorder that captures all user actions when completing an airdrop manually.
    It records everything: clicks, form inputs, scrolls, cookies, local storage, and network requests.
    This allows perfect replication across all other accounts.
    """
    
    def __init__(self, account_id, airdrop_id):
        """Initialize recorder with account and airdrop IDs"""
        self.account_id = account_id
        self.airdrop_id = airdrop_id
        self.actions = []
        self.cookies = []
        self.local_storage = {}
        self.network_requests = []
        self.dom_snapshots = []
        self.screenshot_dir = "static/recordings"
        self.recording = False
        self.driver = None
        self.record_thread = None
        self.stop_event = threading.Event()
        
        # Create screenshots directory if it doesn't exist
        os.makedirs(self.screenshot_dir, exist_ok=True)
    
    def start_recording(self):
        """Start recording user actions"""
        if self.recording:
            logger.warning("Recording already in progress")
            return False
        
        # Get account and airdrop
        account = Account.query.get(self.account_id)
        airdrop = Airdrop.query.get(self.airdrop_id)
        
        if not account or not airdrop:
            logger.error(f"Account {self.account_id} or Airdrop {self.airdrop_id} not found")
            return False
        
        try:
            # Set up Chrome options
            chrome_options = webdriver.ChromeOptions()
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("--disable-infobars")
            
            # Add performance logging for network requests
            chrome_options.set_capability("goog:loggingPrefs", {"performance": "ALL", "browser": "ALL"})
            
            # Initialize driver
            self.driver = webdriver.Chrome(options=chrome_options)
            
            # Add event listeners via JavaScript
            self._inject_event_listeners()
            
            # Start recording thread
            self.recording = True
            self.stop_event.clear()
            self.record_thread = threading.Thread(target=self._record_actions)
            self.record_thread.daemon = True
            self.record_thread.start()
            
            # Start a separate thread for network recording
            network_thread = threading.Thread(target=self._record_network)
            network_thread.daemon = True
            network_thread.start()
            
            # Navigate to airdrop URL
            self.driver.get(airdrop.url)
            
            # Take initial DOM snapshot
            self._take_dom_snapshot("initial")
            
            # Record initial cookies and local storage
            self._record_cookies()
            self._record_local_storage()
            
            # Log start
            logger.info(f"Started recording actions for airdrop {self.airdrop_id} with account {self.account_id}")
            return True
            
        except Exception as e:
            logger.exception(f"Error starting recording: {str(e)}")
            self._cleanup()
            return False
    
    def stop_recording(self):
        """Stop recording and process the recorded actions"""
        if not self.recording:
            logger.warning("No recording in progress")
            return False
        
        try:
            # Stop recording
            self.recording = False
            self.stop_event.set()
            
            # Wait for thread to finish
            if self.record_thread and self.record_thread.is_alive():
                self.record_thread.join(timeout=10)
            
            # Take final snapshot
            self._take_dom_snapshot("final")
            self._record_cookies()
            self._record_local_storage()
            
            # Process recorded actions
            tasks = self._process_actions()
            
            # Clean up
            self._cleanup()
            
            return tasks
            
        except Exception as e:
            logger.exception(f"Error stopping recording: {str(e)}")
            self._cleanup()
            return False
    
    def _inject_event_listeners(self):
        """Inject JavaScript to capture all user events"""
        script = """
        window.recordedEvents = [];
        
        function recordEvent(eventType, event) {
            const target = event.target;
            const targetInfo = {
                tagName: target.tagName,
                id: target.id,
                className: target.className,
                name: target.name,
                value: target.value,
                type: target.type,
                href: target.href,
                textContent: target.innerText,
                xpath: getXPath(target)
            };
            
            const eventData = {
                type: eventType,
                timestamp: new Date().getTime(),
                target: targetInfo,
                pageUrl: window.location.href,
                position: eventType.includes('mouse') ? {x: event.clientX, y: event.clientY} : null
            };
            
            window.recordedEvents.push(eventData);
        }
        
        function getXPath(element) {
            if (!element) return '';
            
            // If element has an ID, use that
            if (element.id !== '')
                return '//*[@id="' + element.id + '"]';
                
            // Get the path parts
            let parts = [];
            while (element && element.nodeType === Node.ELEMENT_NODE) {
                let siblings = Array.from(element.parentNode.children).filter(c => c.tagName === element.tagName);
                let idx = siblings.indexOf(element) + 1;
                
                if (siblings.length > 1)
                    parts.unshift(element.tagName.toLowerCase() + '[' + idx + ']');
                else
                    parts.unshift(element.tagName.toLowerCase());
                    
                element = element.parentNode;
            }
            
            return '/' + parts.join('/');
        }
        
        // Capture clicks, form inputs, scroll events
        document.addEventListener('click', (e) => recordEvent('click', e));
        document.addEventListener('input', (e) => recordEvent('input', e));
        document.addEventListener('change', (e) => recordEvent('change', e));
        document.addEventListener('scroll', (e) => recordEvent('scroll', e));
        document.addEventListener('submit', (e) => recordEvent('submit', e));
        document.addEventListener('focus', (e) => recordEvent('focus', e));
        document.addEventListener('blur', (e) => recordEvent('blur', e));
        
        // Capture navigation events
        let lastUrl = window.location.href;
        setInterval(() => {
            if (lastUrl !== window.location.href) {
                recordEvent('navigation', {target: document, href: window.location.href});
                lastUrl = window.location.href;
            }
        }, 500);
        """
        
        try:
            self.driver.execute_script(script)
            logger.info("Injected event listener script")
        except Exception as e:
            logger.error(f"Error injecting event listeners: {str(e)}")
    
    def _record_actions(self):
        """Record user actions in the browser"""
        try:
            previous_url = self.driver.current_url
            previous_events_count = 0
            screenshot_counter = 0
            
            while self.recording and not self.stop_event.is_set():
                try:
                    # Get current state
                    current_url = self.driver.current_url
                    
                    # Check for URL changes
                    if current_url != previous_url:
                        self._record_url_change(previous_url, current_url)
                        previous_url = current_url
                        
                        # Take screenshot and DOM snapshot on URL change
                        self._take_screenshot(f"url_change_{screenshot_counter}")
                        self._take_dom_snapshot(f"url_change_{screenshot_counter}")
                        screenshot_counter += 1
                    
                    # Retrieve recorded events from JavaScript
                    try:
                        recorded_events = self.driver.execute_script("return window.recordedEvents || [];")
                        
                        if recorded_events and len(recorded_events) > previous_events_count:
                            new_events = recorded_events[previous_events_count:]
                            
                            for event in new_events:
                                self.actions.append({
                                    'type': 'browser_event',
                                    'event_type': event.get('type'),
                                    'target': event.get('target'),
                                    'page_url': event.get('pageUrl'),
                                    'position': event.get('position'),
                                    'timestamp': event.get('timestamp')
                                })
                            
                            previous_events_count = len(recorded_events)
                            
                            # Take periodic screenshots after significant events
                            significant_events = [e for e in new_events if e.get('type') in ['click', 'submit', 'change']]
                            if significant_events:
                                self._take_screenshot(f"event_{screenshot_counter}")
                                screenshot_counter += 1
                    
                    except Exception as js_error:
                        logger.error(f"Error retrieving events from JavaScript: {str(js_error)}")
                    
                    # Take a DOM snapshot every 10 seconds
                    if screenshot_counter % 10 == 0:
                        self._take_dom_snapshot(f"periodic_{screenshot_counter}")
                    
                    # Sleep to reduce CPU usage
                    time.sleep(0.5)
                    
                except Exception as loop_error:
                    logger.error(f"Error in recording loop: {str(loop_error)}")
            
        except Exception as e:
            logger.exception(f"Error in _record_actions: {str(e)}")
            self.recording = False
    
    def _record_network(self):
        """Record network requests"""
        try:
            while self.recording and not self.stop_event.is_set():
                try:
                    # Get performance logs
                    logs = self.driver.get_log('performance')
                    
                    for log in logs:
                        try:
                            log_entry = json.loads(log['message'])
                            
                            # Filter for network requests
                            if 'message' in log_entry and 'method' in log_entry['message']:
                                method = log_entry['message']['method']
                                
                                if method.startswith('Network.'):
                                    self.network_requests.append(log_entry)
                                    
                                    # If it's a request that might include authentication, log it specially
                                    if method == 'Network.requestWillBeSent':
                                        request = log_entry['message'].get('params', {}).get('request', {})
                                        url = request.get('url', '')
                                        
                                        # Look for authentication flows, API calls, form submissions
                                        if any(term in url.lower() for term in ['login', 'auth', 'token', 'api', 'verify']):
                                            headers = request.get('headers', {})
                                            post_data = request.get('postData', '')
                                            
                                            self.actions.append({
                                                'type': 'api_request',
                                                'url': url,
                                                'method': request.get('method', ''),
                                                'headers': headers,
                                                'data': post_data,
                                                'timestamp': log_entry.get('timestamp', datetime.utcnow().isoformat())
                                            })
                        
                        except json.JSONDecodeError:
                            pass
                        
                except Exception as log_error:
                    logger.error(f"Error retrieving network logs: {str(log_error)}")
                
                time.sleep(1)
        
        except Exception as e:
            logger.exception(f"Error in _record_network: {str(e)}")
    
    def _record_url_change(self, old_url, new_url):
        """Record URL change as an action"""
        logger.info(f"URL changed from {old_url} to {new_url}")
        
        self.actions.append({
            'type': 'url_change',
            'old_url': old_url,
            'new_url': new_url,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def _record_cookies(self):
        """Record browser cookies"""
        try:
            cookies = self.driver.get_cookies()
            
            for cookie in cookies:
                # Check if cookie already recorded
                existing = next((c for c in self.cookies if c['name'] == cookie['name']), None)
                
                if not existing or existing['value'] != cookie['value']:
                    cookie['timestamp'] = datetime.utcnow().isoformat()
                    
                    if existing:
                        # Update existing cookie
                        existing.update(cookie)
                    else:
                        # Add new cookie
                        self.cookies.append(cookie)
            
            # Record as action
            self.actions.append({
                'type': 'cookies_snapshot',
                'cookies': self.cookies.copy(),
                'timestamp': datetime.utcnow().isoformat(),
                'url': self.driver.current_url
            })
            
        except Exception as e:
            logger.error(f"Error recording cookies: {str(e)}")
    
    def _record_local_storage(self):
        """Record localStorage data"""
        try:
            # Get all localStorage items
            local_storage_items = self.driver.execute_script("""
                let items = {};
                for (let i = 0; i < localStorage.length; i++) {
                    const key = localStorage.key(i);
                    items[key] = localStorage.getItem(key);
                }
                return items;
            """)
            
            # Update local storage record
            self.local_storage.update(local_storage_items)
            
            # Record as action
            self.actions.append({
                'type': 'local_storage_snapshot',
                'local_storage': self.local_storage.copy(),
                'timestamp': datetime.utcnow().isoformat(),
                'url': self.driver.current_url
            })
            
        except Exception as e:
            logger.error(f"Error recording localStorage: {str(e)}")
    
    def _take_screenshot(self, label):
        """Take a screenshot of the current page"""
        try:
            timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
            filename = f"{self.airdrop_id}_{self.account_id}_{label}_{timestamp}.png"
            filepath = os.path.join(self.screenshot_dir, filename)
            
            self.driver.save_screenshot(filepath)
            
            self.actions.append({
                'type': 'screenshot',
                'path': filepath,
                'timestamp': datetime.utcnow().isoformat(),
                'url': self.driver.current_url,
                'label': label
            })
            
        except Exception as e:
            logger.error(f"Error taking screenshot: {str(e)}")
    
    def _take_dom_snapshot(self, label):
        """Take a snapshot of the current DOM state"""
        try:
            html = self.driver.page_source
            url = self.driver.current_url
            title = self.driver.title
            
            snapshot = {
                'html': base64.b64encode(html.encode()).decode(),  # Encode to save space in DB
                'url': url,
                'title': title,
                'timestamp': datetime.utcnow().isoformat(),
                'label': label
            }
            
            self.dom_snapshots.append(snapshot)
            
            self.actions.append({
                'type': 'dom_snapshot',
                'index': len(self.dom_snapshots) - 1,
                'url': url,
                'timestamp': datetime.utcnow().isoformat(),
                'label': label
            })
            
        except Exception as e:
            logger.error(f"Error taking DOM snapshot: {str(e)}")
    
    def _process_actions(self):
        """Process recorded actions into automation tasks"""
        if not self.actions:
            logger.warning("No actions recorded")
            return None
        
        try:
            logger.info(f"Processing {len(self.actions)} recorded actions")
            
            # Save the complete recording
            self._save_recording()
            
            # Extract key tasks
            tasks = self._extract_tasks()
            
            # Save tasks to database
            stored_tasks = self._save_tasks(tasks)
            
            return stored_tasks
            
        except Exception as e:
            logger.exception(f"Error processing actions: {str(e)}")
            return None
    
    def _save_recording(self):
        """Save the complete recording to the database for future replay"""
        try:
            from models import TaskRecording
            
            # Check if recording already exists
            existing_recording = TaskRecording.query.filter_by(
                airdrop_id=self.airdrop_id,
                account_id=self.account_id
            ).first()
            
            if existing_recording:
                # Update existing recording
                existing_recording.actions = json.dumps(self.actions)
                existing_recording.cookies = json.dumps(self.cookies)
                existing_recording.local_storage = json.dumps(self.local_storage)
                existing_recording.network_requests = json.dumps(self.network_requests[:500])  # Limit size
                existing_recording.dom_snapshots = json.dumps(self.dom_snapshots[:10])  # Limit size
                existing_recording.updated_at = datetime.utcnow()
            else:
                # Create new recording
                recording = TaskRecording()
                recording.airdrop_id = self.airdrop_id
                recording.account_id = self.account_id
                recording.actions = json.dumps(self.actions)
                recording.cookies = json.dumps(self.cookies)
                recording.local_storage = json.dumps(self.local_storage)
                recording.network_requests = json.dumps(self.network_requests[:500])  # Limit size
                recording.dom_snapshots = json.dumps(self.dom_snapshots[:10])  # Limit size
                recording.created_at = datetime.utcnow()
                
                db.session.add(recording)
            
            db.session.commit()
            logger.info(f"Saved recording for airdrop {self.airdrop_id}")
            
        except Exception as e:
            logger.exception(f"Error saving recording: {str(e)}")
            db.session.rollback()
    
    def _extract_tasks(self):
        """Extract executable tasks from the recorded actions"""
        tasks = []
        
        # Group actions by context
        url_changes = [a for a in self.actions if a['type'] == 'url_change']
        browser_events = [a for a in self.actions if a['type'] == 'browser_event']
        api_requests = [a for a in self.actions if a['type'] == 'api_request']
        
        # Process URL changes to identify platform tasks
        for url_change in url_changes:
            new_url = url_change.get('new_url', '')
            
            # Extract Twitter tasks
            if 'twitter.com' in new_url or 'x.com' in new_url:
                tasks.extend(self._extract_twitter_tasks(new_url, browser_events, api_requests))
            
            # Extract Discord tasks
            elif 'discord.com' in new_url or 'discord.gg' in new_url:
                tasks.extend(self._extract_discord_tasks(new_url, browser_events, api_requests))
            
            # Extract Telegram tasks
            elif 't.me/' in new_url:
                tasks.extend(self._extract_telegram_tasks(new_url, browser_events, api_requests))
            
            # Process forms on other websites
            else:
                tasks.extend(self._extract_website_tasks(new_url, browser_events, api_requests))
        
        # Deduplicate tasks
        unique_tasks = []
        task_types = set()
        
        for task in tasks:
            task_key = f"{task['task_type']}_{json.dumps(task['params'], sort_keys=True)}"
            
            if task_key not in task_types:
                task_types.add(task_key)
                unique_tasks.append(task)
        
        return unique_tasks
    
    def _extract_twitter_tasks(self, url, events, api_requests):
        """Extract Twitter specific tasks"""
        tasks = []
        
        # Check for follow tasks
        if any(('/profile/' in url, '/status/' not in url)):
            # Extract username from URL
            username = None
            parts = url.split('/')
            for i, part in enumerate(parts):
                if part in ['twitter.com', 'x.com'] and i+1 < len(parts):
                    if parts[i+1] not in ['search', 'hashtag', 'explore', 'home']:
                        username = parts[i+1].split('?')[0]
                        break
            
            if username:
                # Look for follow button clicks
                follow_clicks = [e for e in events if e['event_type'] == 'click' and 
                               e.get('target', {}).get('textContent', '').lower() in ['follow', 'follow @'+username]]
                
                if follow_clicks:
                    tasks.append({
                        'task_type': 'twitter_follow',
                        'description': f"Follow Twitter user @{username}",
                        'params': {
                            'username': username,
                            'twitter_url': url,
                            'xpath': follow_clicks[0].get('target', {}).get('xpath')
                        }
                    })
        
        # Check for tweet interaction tasks
        if '/status/' in url:
            tweet_id = url.split('/status/')[1].split('?')[0].split('/')[0]
            
            # Check for like clicks
            like_clicks = [e for e in events if e['event_type'] == 'click' and 
                         (e.get('target', {}).get('xpath', '').lower().find('like') >= 0 or
                          e.get('target', {}).get('textContent', '').lower() == 'like')]
            
            if like_clicks:
                tasks.append({
                    'task_type': 'twitter_like',
                    'description': "Like the tweet",
                    'params': {
                        'tweet_link': url,
                        'tweet_id': tweet_id,
                        'xpath': like_clicks[0].get('target', {}).get('xpath')
                    }
                })
            
            # Check for retweet clicks
            retweet_clicks = [e for e in events if e['event_type'] == 'click' and 
                            (e.get('target', {}).get('xpath', '').lower().find('retweet') >= 0 or
                             e.get('target', {}).get('textContent', '').lower() in ['retweet', 'rt'])]
            
            if retweet_clicks:
                tasks.append({
                    'task_type': 'twitter_retweet',
                    'description': "Retweet the tweet",
                    'params': {
                        'tweet_link': url,
                        'tweet_id': tweet_id,
                        'xpath': retweet_clicks[0].get('target', {}).get('xpath')
                    }
                })
            
            # Check for comment/reply activities
            comment_events = [e for e in events if (e['event_type'] == 'input' and 
                                                 e.get('page_url', '') == url)]
            
            comment_submits = [e for e in events if e['event_type'] == 'click' and 
                             (e.get('target', {}).get('textContent', '').lower() in ['reply', 'tweet', 'post'])]
            
            if comment_events and comment_submits:
                # Try to extract the comment text
                comment_text = None
                for e in comment_events:
                    if e.get('target', {}).get('value'):
                        comment_text = e.get('target', {}).get('value')
                        break
                
                tasks.append({
                    'task_type': 'twitter_comment',
                    'description': "Comment on the tweet",
                    'params': {
                        'tweet_link': url,
                        'tweet_id': tweet_id,
                        'comment_text': comment_text,
                        'input_xpath': comment_events[0].get('target', {}).get('xpath'),
                        'submit_xpath': comment_submits[0].get('target', {}).get('xpath')
                    }
                })
        
        return tasks
    
    def _extract_discord_tasks(self, url, events, api_requests):
        """Extract Discord specific tasks"""
        tasks = []
        
        # Check for Discord server joins
        if 'discord.gg/' in url or '/invite/' in url:
            # Extract invite code
            invite_code = None
            if 'discord.gg/' in url:
                invite_code = url.split('discord.gg/')[1].split('?')[0].split('/')[0]
            elif '/invite/' in url:
                invite_code = url.split('/invite/')[1].split('?')[0].split('/')[0]
            
            if invite_code:
                # Look for join button clicks
                join_clicks = [e for e in events if e['event_type'] == 'click' and 
                             (e.get('target', {}).get('textContent', '').lower() in ['accept invite', 'join', 'continue'])]
                
                if join_clicks or any('/channels/' in a.get('new_url', '') for a in self.actions if a['type'] == 'url_change'):
                    tasks.append({
                        'task_type': 'discord_join',
                        'description': f"Join Discord server with invite {invite_code}",
                        'params': {
                            'invite_code': invite_code,
                            'invite_link': url,
                            'xpath': join_clicks[0].get('target', {}).get('xpath') if join_clicks else None
                        }
                    })
        
        # Check for message sending
        message_inputs = [e for e in events if e['event_type'] in ['input', 'change'] and 
                        e.get('target', {}).get('xpath', '').lower().find('message') >= 0]
        
        message_sends = [e for e in events if e['event_type'] == 'click' and 
                       (e.get('target', {}).get('xpath', '').lower().find('message') >= 0 or
                        e.get('target', {}).get('textContent', '').lower() == 'send')]
        
        if message_inputs and message_sends:
            message_text = message_inputs[-1].get('target', {}).get('value', '')
            
            channel_id = None
            channel_name = None
            
            # Try to extract channel from URL
            if '/channels/' in url:
                parts = url.split('/channels/')
                if len(parts) > 1:
                    channel_parts = parts[1].split('/')
                    if len(channel_parts) >= 3:
                        channel_id = channel_parts[2]
            
            tasks.append({
                'task_type': 'discord_message',
                'description': f"Send message in Discord channel" + (f" {channel_name}" if channel_name else ""),
                'params': {
                    'message_text': message_text,
                    'channel_id': channel_id,
                    'input_xpath': message_inputs[-1].get('target', {}).get('xpath'),
                    'send_xpath': message_sends[-1].get('target', {}).get('xpath')
                }
            })
        
        return tasks
    
    def _extract_telegram_tasks(self, url, events, api_requests):
        """Extract Telegram specific tasks"""
        tasks = []
        
        # Check for Telegram group/channel joins
        if 't.me/' in url:
            # Extract group name
            group_name = url.split('t.me/')[1].split('?')[0].split('/')[0]
            
            if group_name:
                # Look for join button clicks
                join_clicks = [e for e in events if e['event_type'] == 'click' and 
                             (e.get('target', {}).get('textContent', '').lower() in ['join', 'join channel', 'join group'])]
                
                if join_clicks:
                    tasks.append({
                        'task_type': 'telegram_join',
                        'description': f"Join Telegram group/channel {group_name}",
                        'params': {
                            'group_name': group_name,
                            'group_link': url,
                            'xpath': join_clicks[0].get('target', {}).get('xpath')
                        }
                    })
        
        return tasks
    
    def _extract_website_tasks(self, url, events, api_requests):
        """Extract website form submission and other tasks"""
        tasks = []
        domain = urlparse(url).netloc
        
        # Check for form submissions
        form_inputs = [e for e in events if e['event_type'] in ['input', 'change']]
        form_submits = [e for e in events if e['event_type'] in ['click', 'submit'] and
                       (e.get('target', {}).get('tagName', '').lower() == 'button' or
                        e.get('target', {}).get('textContent', '').lower() in ['submit', 'register', 'sign up', 'connect', 'continue'])]
        
        if form_inputs and form_submits:
            # Try to categorize the form
            input_types = [i.get('target', {}).get('type', '') for i in form_inputs]
            input_names = [i.get('target', {}).get('name', '') for i in form_inputs]
            input_values = {i.get('target', {}).get('name', ''): i.get('target', {}).get('value', '') 
                          for i in form_inputs if i.get('target', {}).get('name')}
            
            # Check for email subscription
            if ('email' in input_types or any('email' in n.lower() for n in input_names)) and \
               not any(t in input_types for t in ['password', 'pwd']):
                tasks.append({
                    'task_type': 'website_email',
                    'description': f"Subscribe with email on {domain}",
                    'params': {
                        'url': url,
                        'form_data': input_values,
                        'input_xpaths': {i.get('target', {}).get('name', ''): i.get('target', {}).get('xpath') 
                                         for i in form_inputs if i.get('target', {}).get('name')},
                        'submit_xpath': form_submits[-1].get('target', {}).get('xpath')
                    }
                })
            
            # Check for signup/registration
            elif ('password' in input_types or any('password' in n.lower() for n in input_names)):
                tasks.append({
                    'task_type': 'website_signup',
                    'description': f"Create account on {domain}",
                    'params': {
                        'url': url,
                        'form_data': input_values,
                        'input_xpaths': {i.get('target', {}).get('name', ''): i.get('target', {}).get('xpath') 
                                         for i in form_inputs if i.get('target', {}).get('name')},
                        'submit_xpath': form_submits[-1].get('target', {}).get('xpath')
                    }
                })
            
            # Check for wallet connection
            elif any(term in ' '.join(input_values.values()).lower() for term in ['wallet', 'address', 'eth', 'bsc']):
                tasks.append({
                    'task_type': 'website_wallet',
                    'description': f"Connect wallet on {domain}",
                    'params': {
                        'url': url,
                        'form_data': input_values,
                        'input_xpaths': {i.get('target', {}).get('name', ''): i.get('target', {}).get('xpath') 
                                         for i in form_inputs if i.get('target', {}).get('name')},
                        'submit_xpath': form_submits[-1].get('target', {}).get('xpath'),
                        'wallet_type': self._detect_wallet_type(events, form_inputs)
                    }
                })
            
            # Generic form submission
            else:
                tasks.append({
                    'task_type': 'website_form',
                    'description': f"Complete form on {domain}",
                    'params': {
                        'url': url,
                        'form_data': input_values,
                        'input_xpaths': {i.get('target', {}).get('name', ''): i.get('target', {}).get('xpath') 
                                         for i in form_inputs if i.get('target', {}).get('name')},
                        'submit_xpath': form_submits[-1].get('target', {}).get('xpath')
                    }
                })
        
        # Check for button clicks that might be important (e.g., wallet connection popups)
        important_clicks = [e for e in events if e['event_type'] == 'click' and
                          any(term in (e.get('target', {}).get('textContent', '') or '').lower() 
                              for term in ['connect', 'authorize', 'allow', 'enable', 'approve'])]
        
        if important_clicks and not tasks:  # Only if we didn't already detect a form submission
            for click in important_clicks:
                click_text = click.get('target', {}).get('textContent', '').lower()
                
                if 'wallet' in click_text or 'connect' in click_text:
                    tasks.append({
                        'task_type': 'website_button',
                        'description': f"Click '{click.get('target', {}).get('textContent')}' on {domain}",
                        'params': {
                            'url': url,
                            'button_text': click.get('target', {}).get('textContent'),
                            'xpath': click.get('target', {}).get('xpath')
                        }
                    })
        
        return tasks
    
    def _detect_wallet_type(self, events, form_inputs):
        """Try to detect wallet type from events and inputs"""
        wallet_types = {
            'metamask': ['metamask', 'ethereum', 'eth'],
            'wallet_connect': ['walletconnect', 'wallet connect'],
            'phantom': ['phantom', 'solana', 'sol'],
            'trust_wallet': ['trust wallet', 'trustwallet'],
            'binance': ['binance', 'bnb', 'bsc'],
            'coinbase': ['coinbase']
        }
        
        all_text = ' '.join([
            e.get('target', {}).get('textContent', '') for e in events if e.get('target', {}).get('textContent')
        ]).lower()
        
        for wallet, keywords in wallet_types.items():
            if any(keyword in all_text for keyword in keywords):
                return wallet
        
        return None
    
    def _save_tasks(self, tasks):
        """Save tasks to database"""
        if not tasks:
            return []
        
        stored_tasks = []
        
        try:
            airdrop = Airdrop.query.get(self.airdrop_id)
            
            if not airdrop:
                logger.error(f"Airdrop {self.airdrop_id} not found")
                return []
            
            # Get existing tasks
            existing_tasks = Task.query.filter_by(airdrop_id=self.airdrop_id).all()
            existing_types = {(task.task_type, task.description) for task in existing_tasks}
            
            for task_data in tasks:
                # Skip if similar task already exists
                if (task_data['task_type'], task_data['description']) in existing_types:
                    continue
                
                task = Task()
                task.airdrop_id = self.airdrop_id
                task.task_type = task_data['task_type']
                task.description = task_data['description']
                task.params = json.dumps(task_data['params'])
                task.status = 'pending'
                task.priority = 1  # High priority since it's manually verified
                
                db.session.add(task)
                stored_tasks.append(task)
            
            db.session.commit()
            logger.info(f"Created {len(stored_tasks)} tasks from recording")
            
        except Exception as e:
            logger.exception(f"Error saving tasks: {str(e)}")
            db.session.rollback()
        
        return stored_tasks
    
    def _cleanup(self):
        """Clean up resources"""
        self.recording = False
        self.stop_event.set()
        
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            
        self.driver = None

def start_browser_recording(account_id, airdrop_id):
    """
    Start a browser recording session to learn airdrop tasks
    
    Args:
        account_id: ID of the account to use
        airdrop_id: ID of the airdrop to learn
        
    Returns:
        BrowserRecorder instance or None if failed
    """
    try:
        # Create recorder
        recorder = BrowserRecorder(account_id, airdrop_id)
        
        # Start recording
        success = recorder.start_recording()
        
        if not success:
            logger.error("Failed to start browser recording session")
            return None
        
        return recorder
        
    except Exception as e:
        logger.exception(f"Error starting browser recording session: {str(e)}")
        return None

def stop_browser_recording(recorder):
    """
    Stop a browser recording session and create tasks
    
    Args:
        recorder: BrowserRecorder instance
        
    Returns:
        list: Created tasks or None if failed
    """
    if not recorder:
        logger.error("Invalid recorder")
        return None
    
    try:
        # Stop recording
        tasks = recorder.stop_recording()
        
        if not tasks:
            logger.warning("No tasks created from recording")
            return None
        
        logger.info(f"Created {len(tasks)} tasks from recording")
        return tasks
        
    except Exception as e:
        logger.exception(f"Error stopping browser recording session: {str(e)}")
        return None

def replay_recording(recording_id, account_id):
    """
    Replay a recorded airdrop with another account
    
    Args:
        recording_id: ID of the recording to replay
        account_id: ID of the account to use
        
    Returns:
        bool: Success flag
    """
    try:
        from models import TaskRecording, Account, Airdrop
        
        # Get recording
        recording = TaskRecording.query.get(recording_id)
        
        if not recording:
            logger.error(f"Recording {recording_id} not found")
            return False
        
        # Get account
        account = Account.query.get(account_id)
        
        if not account:
            logger.error(f"Account {account_id} not found")
            return False
        
        # Get airdrop
        airdrop = Airdrop.query.get(recording.airdrop_id)
        
        if not airdrop:
            logger.error(f"Airdrop {recording.airdrop_id} not found")
            return False
        
        # Set up Chrome options
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument("--disable-infobars")
        
        # Initialize driver
        driver = webdriver.Chrome(options=chrome_options)
        
        try:
            # Load actions
            actions = json.loads(recording.actions)
            cookies = json.loads(recording.cookies)
            local_storage = json.loads(recording.local_storage)
            
            # Navigate to airdrop URL
            driver.get(airdrop.url)
            
            # Wait for page to load
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            
            # Set cookies
            for cookie in cookies:
                try:
                    # Remove unnecessary fields
                    if 'sameSite' in cookie:
                        del cookie['sameSite']
                    if 'expiry' in cookie and not isinstance(cookie['expiry'], (int, float)):
                        del cookie['expiry']
                    
                    driver.add_cookie(cookie)
                except Exception as cookie_error:
                    logger.error(f"Error setting cookie {cookie.get('name')}: {str(cookie_error)}")
            
            # Refresh page to apply cookies
            driver.refresh()
            
            # Set localStorage
            for key, value in local_storage.items():
                driver.execute_script(f"localStorage.setItem('{key}', '{value}')")
            
            # Execute actions
            for action in actions:
                if action['type'] == 'browser_event' and action['event_type'] == 'click':
                    try:
                        xpath = action.get('target', {}).get('xpath')
                        if xpath:
                            element = WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, xpath)))
                            element.click()
                            time.sleep(1)
                    except Exception as click_error:
                        logger.error(f"Error replaying click: {str(click_error)}")
                
                elif action['type'] == 'browser_event' and action['event_type'] in ['input', 'change']:
                    try:
                        xpath = action.get('target', {}).get('xpath')
                        value = action.get('target', {}).get('value')
                        
                        if xpath and value is not None:
                            element = WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, xpath)))
                            element.clear()
                            element.send_keys(value)
                            time.sleep(0.5)
                    except Exception as input_error:
                        logger.error(f"Error replaying input: {str(input_error)}")
                
                elif action['type'] == 'url_change':
                    try:
                        new_url = action.get('new_url')
                        if new_url and new_url != driver.current_url:
                            driver.get(new_url)
                            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))
                    except Exception as url_error:
                        logger.error(f"Error navigating to URL: {str(url_error)}")
                
                # Sleep between actions
                time.sleep(0.5)
            
            logger.info(f"Successfully replayed recording {recording_id} with account {account_id}")
            return True
            
        finally:
            # Clean up
            driver.quit()
        
    except Exception as e:
        logger.exception(f"Error replaying recording: {str(e)}")
        return False