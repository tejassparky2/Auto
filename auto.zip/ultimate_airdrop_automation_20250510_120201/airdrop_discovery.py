import logging
import json
import re
import time
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse

from app import db
from models import Airdrop, User
import scraper
import airdrop_manager

logger = logging.getLogger(__name__)

# List of common airdrop aggregator sites
AIRDROP_SOURCES = [
    {
        'name': 'Airdrops.io',
        'url': 'https://airdrops.io/hot-airdrops/',
        'selector': '.projects-container .project-box',
        'name_selector': '.project-box-title',
        'link_selector': '.project-box-title a',
        'active': True
    },
    {
        'name': 'CoinMarketCap Airdrops',
        'url': 'https://coinmarketcap.com/airdrop/',
        'selector': '.sc-66133f36-2',
        'name_selector': '.name-col',
        'link_selector': '.sc-66133f36-2 a',
        'active': True
    },
    {
        'name': 'Airdrop Alert',
        'url': 'https://airdropalert.com/new-airdrops',
        'selector': '.active-airdrop-item',
        'name_selector': '.active-airdrop-item h3',
        'link_selector': '.active-airdrop-item a',
        'active': True
    }
]

def discover_airdrops(sources=None):
    """
    Discover new airdrops from various sources
    
    Args:
        sources: List of source configurations to use (defaults to all active sources)
    
    Returns:
        list: Discovered airdrops
    """
    if sources is None:
        sources = [source for source in AIRDROP_SOURCES if source.get('active', True)]
    
    discovered_airdrops = []
    
    for source in sources:
        try:
            logger.info(f"Discovering airdrops from {source['name']}")
            airdrops = scrape_airdrop_source(source)
            discovered_airdrops.extend(airdrops)
            logger.info(f"Discovered {len(airdrops)} airdrops from {source['name']}")
            
            # Sleep to avoid hitting rate limits
            time.sleep(2)
        except Exception as e:
            logger.error(f"Error discovering airdrops from {source['name']}: {str(e)}")
    
    # Remove duplicates
    seen_urls = set()
    unique_airdrops = []
    
    for airdrop in discovered_airdrops:
        # Normalize URL
        url = airdrop.get('url', '').lower().strip()
        if url and url not in seen_urls:
            seen_urls.add(url)
            unique_airdrops.append(airdrop)
    
    logger.info(f"Discovered {len(unique_airdrops)} unique airdrops")
    return unique_airdrops

def scrape_airdrop_source(source):
    """
    Scrape airdrops from a specific source
    
    Args:
        source: Source configuration dictionary
        
    Returns:
        list: Discovered airdrops
    """
    discovered = []
    
    try:
        # Fetch the page content
        page_content = scraper.fetch_page_content(source['url'])
        if not page_content:
            logger.warning(f"Failed to fetch content from {source['url']}")
            return discovered
        
        # Parse the HTML content
        soup = BeautifulSoup(page_content, 'html.parser')
        
        # Find all airdrop entries
        airdrop_elements = soup.select(source['selector'])
        
        for element in airdrop_elements:
            try:
                # Extract name
                name_element = element.select_one(source['name_selector'])
                if name_element:
                    name = name_element.text.strip()
                else:
                    name = "Unknown Airdrop"
                
                # Extract link
                link_element = element.select_one(source['link_selector'])
                if link_element and link_element.has_attr('href'):
                    url = link_element['href']
                    # Handle relative URLs
                    if url.startswith('/'):
                        parsed_source = urlparse(source['url'])
                        url = f"{parsed_source.scheme}://{parsed_source.netloc}{url}"
                else:
                    # Skip airdrops without URLs
                    continue
                
                # Gather available information
                airdrop_info = {
                    'name': name,
                    'url': url,
                    'source': source['name'],
                    'discovered_at': datetime.utcnow().isoformat()
                }
                
                discovered.append(airdrop_info)
            
            except Exception as e:
                logger.error(f"Error extracting airdrop info: {str(e)}")
        
    except Exception as e:
        logger.error(f"Error scraping source {source['name']}: {str(e)}")
    
    return discovered

def add_discovered_airdrops(discovered_airdrops, user_id):
    """
    Add discovered airdrops to a user's account
    
    Args:
        discovered_airdrops: List of discovered airdrop dictionaries
        user_id: ID of the user to add the airdrops to
        
    Returns:
        dict: Count of added, skipped, and failed airdrops
    """
    user = User.query.get(user_id)
    if not user:
        logger.error(f"User {user_id} not found")
        return {'added': 0, 'skipped': 0, 'failed': 0}
    
    # Get existing airdrop URLs for this user
    existing_urls = {airdrop.url.lower().strip() 
                    for airdrop in Airdrop.query.filter_by(user_id=user_id).all()}
    
    result = {'added': 0, 'skipped': 0, 'failed': 0}
    
    for airdrop_info in discovered_airdrops:
        try:
            url = airdrop_info['url'].lower().strip()
            
            # Skip if already exists
            if url in existing_urls:
                result['skipped'] += 1
                continue
            
            # Create new airdrop
            new_airdrop = Airdrop()
            new_airdrop.user_id = user_id
            new_airdrop.name = airdrop_info['name']
            new_airdrop.url = airdrop_info['url']
            new_airdrop.status = 'pending'
            
            db.session.add(new_airdrop)
            db.session.commit()
            
            # Analyze the airdrop to find tasks
            try:
                airdrop_manager.analyze_airdrop(new_airdrop.id)
                
                # Mark as added
                result['added'] += 1
                logger.info(f"Added and analyzed airdrop: {new_airdrop.name}")
            except Exception as analyze_error:
                logger.error(f"Error analyzing airdrop {new_airdrop.id}: {str(analyze_error)}")
                
                # Still count as added even if analysis fails
                result['added'] += 1
        
        except Exception as e:
            logger.error(f"Error adding airdrop {airdrop_info.get('name')}: {str(e)}")
            result['failed'] += 1
    
    return result

def search_custom_sources(keywords=None, platforms=None, user_id=None):
    """
    Search for airdrops from custom sources (Twitter, Discord, etc.)
    
    Args:
        keywords: List of keywords to search for
        platforms: List of platforms to search on
        user_id: ID of the user to customize the search for
        
    Returns:
        list: Discovered airdrops
    """
    discovered = []
    
    # Default keywords if none provided
    if not keywords:
        keywords = ['airdrop', 'free token', 'token giveaway', 'crypto airdrop']
    
    # Default platforms if none provided
    if not platforms:
        platforms = ['twitter', 'reddit']
    
    # Search on each platform
    for platform in platforms:
        try:
            if platform == 'twitter':
                twitter_results = search_twitter_airdrops(keywords)
                discovered.extend(twitter_results)
            elif platform == 'reddit':
                reddit_results = search_reddit_airdrops(keywords)
                discovered.extend(reddit_results)
            # Add more platforms as needed
        except Exception as e:
            logger.error(f"Error searching {platform} for airdrops: {str(e)}")
    
    return discovered

def search_twitter_airdrops(keywords):
    """
    Search for airdrops on Twitter
    
    Args:
        keywords: List of keywords to search for
        
    Returns:
        list: Discovered airdrops
    """
    discovered = []
    
    try:
        # In a real implementation, this would use the Twitter API
        # For demonstration purposes, we'll return some sample data
        logger.info(f"Searching Twitter for airdrops with keywords: {keywords}")
        
        # This is just a placeholder - in production, replace with actual Twitter API calls
        sample_twitter_results = [
            {
                'name': 'Sample Twitter Airdrop 1',
                'url': 'https://example.com/airdrop1',
                'source': 'Twitter (Sample)',
                'discovered_at': datetime.utcnow().isoformat()
            },
            {
                'name': 'Sample Twitter Airdrop 2',
                'url': 'https://example.com/airdrop2',
                'source': 'Twitter (Sample)',
                'discovered_at': datetime.utcnow().isoformat()
            }
        ]
        
        discovered.extend(sample_twitter_results)
        logger.info(f"Discovered {len(sample_twitter_results)} airdrops from Twitter (sample data)")
    
    except Exception as e:
        logger.error(f"Error searching Twitter for airdrops: {str(e)}")
    
    return discovered

def search_reddit_airdrops(keywords):
    """
    Search for airdrops on Reddit
    
    Args:
        keywords: List of keywords to search for
        
    Returns:
        list: Discovered airdrops
    """
    discovered = []
    
    try:
        # In a real implementation, this would use the Reddit API
        # For demonstration purposes, we'll return some sample data
        logger.info(f"Searching Reddit for airdrops with keywords: {keywords}")
        
        # This is just a placeholder - in production, replace with actual Reddit API calls
        sample_reddit_results = [
            {
                'name': 'Sample Reddit Airdrop 1',
                'url': 'https://example.com/redditairdrop1',
                'source': 'Reddit (Sample)',
                'discovered_at': datetime.utcnow().isoformat()
            }
        ]
        
        discovered.extend(sample_reddit_results)
        logger.info(f"Discovered {len(sample_reddit_results)} airdrops from Reddit (sample data)")
    
    except Exception as e:
        logger.error(f"Error searching Reddit for airdrops: {str(e)}")
    
    return discovered

def start_discovery_job(user_id, auto_add=False, keywords=None, platforms=None):
    """
    Start a discovery job for a user
    
    Args:
        user_id: ID of the user to discover airdrops for
        auto_add: Whether to automatically add discovered airdrops
        keywords: List of keywords to search for
        platforms: List of platforms to search on
        
    Returns:
        dict: Discovery results
    """
    try:
        logger.info(f"Starting airdrop discovery job for user {user_id}")
        
        # Discover from standard sources
        standard_airdrops = discover_airdrops()
        
        # Discover from custom sources
        custom_airdrops = search_custom_sources(keywords, platforms, user_id)
        
        # Combine results
        all_discovered = standard_airdrops + custom_airdrops
        
        logger.info(f"Discovered {len(all_discovered)} total airdrops")
        
        # Auto-add if requested
        if auto_add and all_discovered:
            add_results = add_discovered_airdrops(all_discovered, user_id)
            logger.info(f"Auto-added airdrops for user {user_id}: {add_results}")
            
            return {
                'discovered': len(all_discovered),
                'added': add_results['added'],
                'skipped': add_results['skipped'],
                'failed': add_results['failed']
            }
        
        return {
            'discovered': len(all_discovered),
            'airdrops': all_discovered
        }
    
    except Exception as e:
        logger.exception(f"Error in airdrop discovery job: {str(e)}")
        return {'error': str(e)}