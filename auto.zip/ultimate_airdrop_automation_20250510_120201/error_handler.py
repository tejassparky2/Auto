import logging
import json
import time
import re
import traceback
from datetime import datetime

from app import db
from models import TaskExecution, ErrorLog, LearningData

logger = logging.getLogger(__name__)

class ErrorHandler:
    """
    Advanced error handling system that provides detailed diagnostics,
    suggestions for fixes, and automatic learning from errors.
    """
    
    def __init__(self):
        self.common_errors = {
            # Platform-specific errors
            'twitter': {
                'rate_limit': {
                    'patterns': [
                        'rate limit exceeded',
                        'too many requests',
                        '429',
                        'try again later'
                    ],
                    'suggestions': [
                        'Wait for 15-30 minutes before trying again',
                        'Use a different account',
                        'Use a different proxy server',
                        'Schedule the task for a later time'
                    ]
                },
                'login_failed': {
                    'patterns': [
                        'incorrect username or password',
                        'login verification',
                        'unusual login',
                        'suspicious activity'
                    ],
                    'suggestions': [
                        'Check account credentials',
                        'Login manually to clear any security verifications',
                        'Update the account with fresh cookies',
                        'Use a different account'
                    ]
                },
                'account_locked': {
                    'patterns': [
                        'account locked',
                        'account suspended',
                        'verify your identity',
                        'confirm your phone'
                    ],
                    'suggestions': [
                        'Login manually and follow verification steps',
                        'Use a different account',
                        'Contact Twitter support to unlock the account'
                    ]
                }
            },
            'discord': {
                'captcha': {
                    'patterns': [
                        'captcha',
                        'robot check',
                        'human verification',
                        'are you human'
                    ],
                    'suggestions': [
                        'Complete the verification manually',
                        'Use a different account',
                        'Verify the account manually before automation'
                    ]
                },
                'invite_expired': {
                    'patterns': [
                        'invite invalid',
                        'invite expired',
                        'invalid invite',
                        'invite no longer valid'
                    ],
                    'suggestions': [
                        'Get an updated invite link',
                        'Check if the server still exists',
                        'Make sure the invite hasn\'t reached its limit'
                    ]
                },
                'server_full': {
                    'patterns': [
                        'server full',
                        'reached maximum capacity',
                        'cannot accept more members'
                    ],
                    'suggestions': [
                        'Try again later when some users may have left',
                        'Check official channels for alternative servers'
                    ]
                }
            },
            'telegram': {
                'join_limit': {
                    'patterns': [
                        'joined too many channels',
                        'join too many supergroups',
                        'wait for some time'
                    ],
                    'suggestions': [
                        'Wait for 24 hours before trying again',
                        'Leave some other channels/groups',
                        'Use a different account'
                    ]
                },
                'group_private': {
                    'patterns': [
                        'group is private',
                        'not in group',
                        'channel private',
                        'you need an invite'
                    ],
                    'suggestions': [
                        'Get a valid invite link',
                        'Ensure the group is public',
                        'Contact admins for access'
                    ]
                }
            },
            'wallet': {
                'connection_failed': {
                    'patterns': [
                        'wallet connection failed',
                        'unable to connect wallet',
                        'wallet not detected',
                        'metamask not found'
                    ],
                    'suggestions': [
                        'Ensure wallet extension is installed and unlocked',
                        'Refresh the page and try again',
                        'Switch to a supported browser',
                        'Check if the website supports your wallet type'
                    ]
                },
                'wrong_network': {
                    'patterns': [
                        'wrong network',
                        'unsupported network',
                        'switch to',
                        'please connect to',
                        'change network'
                    ],
                    'suggestions': [
                        'Switch to the required network in your wallet',
                        'Add the custom network to your wallet',
                        'Check network configuration'
                    ]
                },
                'gas_fee': {
                    'patterns': [
                        'insufficient funds for gas',
                        'not enough eth for gas',
                        'insufficient balance',
                        'cannot estimate gas'
                    ],
                    'suggestions': [
                        'Add funds to cover gas fees',
                        'Wait for lower gas prices',
                        'Try a different network with lower fees'
                    ]
                }
            },
            
            # Generic errors
            'network': {
                'connection': {
                    'patterns': [
                        'connection error',
                        'network error',
                        'timeout',
                        'could not connect',
                        'connection refused',
                        'connection reset'
                    ],
                    'suggestions': [
                        'Check your internet connection',
                        'Try using a different proxy server',
                        'Wait a few minutes and try again',
                        'Check if the website is down for everyone'
                    ]
                },
                'proxy': {
                    'patterns': [
                        'proxy error',
                        'proxy connection',
                        'bad proxy',
                        'proxy authentication'
                    ],
                    'suggestions': [
                        'Verify your proxy credentials',
                        'Try a different proxy server',
                        'Check if the proxy is still active',
                        'Try without a proxy to see if that works'
                    ]
                },
                'dns': {
                    'patterns': [
                        'dns error',
                        'could not resolve',
                        'unknown host',
                        'name resolution'
                    ],
                    'suggestions': [
                        'Check if the domain is correct',
                        'Try using a different DNS server',
                        'Check if the website still exists'
                    ]
                }
            },
            'browser': {
                'element': {
                    'patterns': [
                        'element not found',
                        'no such element',
                        'element not visible',
                        'element not clickable',
                        'stale element'
                    ],
                    'suggestions': [
                        'The website layout may have changed',
                        'Try updating the selectors in the task',
                        'Wait longer for page to fully load',
                        'The element might be hidden or in a different state'
                    ]
                },
                'javascript': {
                    'patterns': [
                        'javascript error',
                        'script error',
                        'undefined',
                        'null',
                        'cannot read property'
                    ],
                    'suggestions': [
                        'Try refreshing the page',
                        'Clear browser cache and cookies',
                        'Make sure JavaScript is enabled',
                        'Website code might have changed'
                    ]
                },
                'navigation': {
                    'patterns': [
                        'navigation failed',
                        'page crash',
                        'navigation timeout',
                        'load timeout'
                    ],
                    'suggestions': [
                        'Check if the URL is correct',
                        'Try increasing page load timeout',
                        'Check if the website is down',
                        'Try a different browser engine'
                    ]
                }
            },
            'api': {
                'auth': {
                    'patterns': [
                        'unauthorized',
                        'authentication failed',
                        'invalid token',
                        '401',
                        'not authorized'
                    ],
                    'suggestions': [
                        'Re-login to refresh authentication tokens',
                        'Check if cookies are being properly stored',
                        'Session may have expired, try a fresh session',
                        'API might require additional authentication steps'
                    ]
                },
                'forbidden': {
                    'patterns': [
                        'forbidden',
                        'access denied',
                        '403',
                        'not allowed'
                    ],
                    'suggestions': [
                        'Your account might not have sufficient permissions',
                        'Check if you need to complete additional verification steps',
                        'Website may have anti-bot measures in place',
                        'Try using a different account with higher privileges'
                    ]
                },
                'not_found': {
                    'patterns': [
                        'not found',
                        '404',
                        'resource does not exist'
                    ],
                    'suggestions': [
                        'Check if the API endpoint URL is correct',
                        'The resource might have been moved or deleted',
                        'Verify that all parameters are correct'
                    ]
                },
                'server_error': {
                    'patterns': [
                        'server error',
                        'internal server error',
                        '500',
                        'service unavailable',
                        '503'
                    ],
                    'suggestions': [
                        'This is an issue with the website, not our tool',
                        'Try again later when the server might be fixed',
                        'Check if the website is down for everyone'
                    ]
                }
            }
        }
    
    def analyze_error(self, error, task_type=None, platform=None, context=None):
        """
        Analyze an error and provide diagnostics and suggestions
        
        Args:
            error: The error message or exception
            task_type: Optional task type for more specific suggestions
            platform: Optional platform for more specific suggestions
            context: Optional execution context for better analysis
            
        Returns:
            dict: Error analysis with suggestions
        """
        error_str = self._get_error_string(error)
        error_type = self._identify_error_type(error_str, task_type, platform)
        
        # Get general suggestions
        general_suggestions = self._get_general_suggestions(error_type, task_type, platform)
        
        # Get specific suggestions based on the exact error
        specific_suggestions = self._get_specific_suggestions(error_str, error_type, task_type, platform)
        
        # Get advanced technical diagnosis
        technical_diagnosis = self._get_technical_diagnosis(error, context)
        
        # Record error for learning
        self._record_error(error_str, error_type, task_type, platform, context)
        
        return {
            'error_message': error_str,
            'error_type': error_type,
            'general_suggestions': general_suggestions,
            'specific_suggestions': specific_suggestions,
            'technical_diagnosis': technical_diagnosis,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    def _get_error_string(self, error):
        """Convert error to string regardless of type"""
        if isinstance(error, Exception):
            return f"{type(error).__name__}: {str(error)}\n{traceback.format_exc()}"
        return str(error)
    
    def _identify_error_type(self, error_str, task_type=None, platform=None):
        """Identify the type of error"""
        error_str = error_str.lower()
        
        # First check platform-specific errors
        if platform:
            platform_errors = self.common_errors.get(platform, {})
            for error_category, error_info in platform_errors.items():
                for pattern in error_info['patterns']:
                    if pattern.lower() in error_str:
                        return f"{platform}_{error_category}"
        
        # Then check task-specific patterns
        if task_type:
            task_platform = task_type.split('_')[0] if '_' in task_type else None
            if task_platform and task_platform in self.common_errors:
                platform_errors = self.common_errors[task_platform]
                for error_category, error_info in platform_errors.items():
                    for pattern in error_info['patterns']:
                        if pattern.lower() in error_str:
                            return f"{task_platform}_{error_category}"
        
        # Check generic error categories
        for category, category_errors in self.common_errors.items():
            if category in ['twitter', 'discord', 'telegram', 'wallet']:
                continue  # Skip platform-specific checks here
                
            for error_type, error_info in category_errors.items():
                for pattern in error_info['patterns']:
                    if pattern.lower() in error_str:
                        return f"{category}_{error_type}"
        
        # Default to unknown error
        return "unknown"
    
    def _get_general_suggestions(self, error_type, task_type=None, platform=None):
        """Get general suggestions for the error type"""
        if '_' in error_type:
            category, specific = error_type.split('_', 1)
            if category in self.common_errors and specific in self.common_errors[category]:
                return self.common_errors[category][specific].get('suggestions', [])
        
        # Default suggestions
        return [
            "Try executing the task again",
            "Use a different account",
            "Wait for some time before retrying",
            "Check if the website has changed its layout or functionality"
        ]
    
    def _get_specific_suggestions(self, error_str, error_type, task_type=None, platform=None):
        """Get specific suggestions based on the exact error message"""
        suggestions = []
        
        # Check for specific patterns in the error message
        if "timeout" in error_str.lower():
            suggestions.append("Increase the timeout setting for this task")
            suggestions.append("Check your internet connection speed")
        
        if "element not found" in error_str.lower() or "no such element" in error_str.lower():
            suggestions.append("The website layout may have changed, try updating the selectors")
            suggestions.append("Wait longer for the page to fully load before interacting")
            
            # Extract the selector that failed
            selector_match = re.search(r"element not found: ([^\n]+)", error_str)
            if selector_match:
                suggestions.append(f"Update selector '{selector_match.group(1)}' which was not found")
        
        if "captcha" in error_str.lower() or "robot" in error_str.lower():
            suggestions.append("Complete captcha verification manually and try again")
            suggestions.append("Use a proxy with a good reputation")
            suggestions.append("Slow down your automation to appear more human-like")
        
        # Add task-specific suggestions
        if task_type:
            if "twitter_follow" in task_type:
                suggestions.append("Check if the Twitter account actually exists")
                suggestions.append("Your account might have reached the following limit")
            
            elif "discord_join" in task_type:
                suggestions.append("Check if the invite link is still valid")
                suggestions.append("Your account may have joined too many servers recently")
            
            elif "wallet_connect" in task_type:
                suggestions.append("Ensure your wallet is unlocked before connecting")
                suggestions.append("Check if you're on the correct network")
        
        return suggestions
    
    def _get_technical_diagnosis(self, error, context):
        """Get a technical diagnosis of the error"""
        diagnosis = []
        
        # Extract exception type and message
        if isinstance(error, Exception):
            error_type = type(error).__name__
            error_msg = str(error)
            diagnosis.append(f"Exception type: {error_type}")
            diagnosis.append(f"Error message: {error_msg}")
            
            # Add traceback for stack analysis
            diagnosis.append("Stack trace:")
            diagnosis.append(traceback.format_exc())
        else:
            diagnosis.append(f"Error: {str(error)}")
        
        # Add context information if available
        if context:
            diagnosis.append("Execution context:")
            for key, value in context.items():
                diagnosis.append(f"  {key}: {value}")
        
        return diagnosis
    
    def _record_error(self, error_str, error_type, task_type, platform, context):
        """Record error for learning and future improvement"""
        try:
            error_log = ErrorLog()
            error_log.error_message = error_str[:1000]  # Limit length
            error_log.error_type = error_type
            error_log.task_type = task_type
            error_log.platform = platform
            error_log.context = json.dumps(context) if context else None
            error_log.timestamp = datetime.utcnow()
            
            db.session.add(error_log)
            db.session.commit()
            
            # Update learning data based on this error
            self._update_learning_from_error(error_type, task_type, platform)
            
        except Exception as e:
            logger.exception(f"Failed to record error: {str(e)}")
    
    def _update_learning_from_error(self, error_type, task_type, platform):
        """Update learning data based on the error"""
        try:
            if not task_type or not platform:
                return
            
            # Get existing learning data
            learning_data = LearningData.query.filter_by(
                task_type=task_type,
                platform=platform
            ).first()
            
            if not learning_data:
                return
            
            # Update strategy based on error type
            try:
                strategy = json.loads(learning_data.strategy) if learning_data.strategy else {}
                
                # Adjust strategy based on error type
                if "rate_limit" in error_type:
                    # Increase delays
                    if 'wait_before_action' in strategy:
                        strategy['wait_before_action'] = min(10.0, strategy['wait_before_action'] * 1.5)
                    if 'wait_after_action' in strategy:
                        strategy['wait_after_action'] = min(10.0, strategy['wait_after_action'] * 1.5)
                    if 'delay_range' in strategy:
                        strategy['delay_range'] = [
                            min(5.0, strategy['delay_range'][0] * 1.5),
                            min(15.0, strategy['delay_range'][1] * 1.5)
                        ]
                
                elif "element" in error_type:
                    # Increase wait times and retry count
                    if 'wait_before_action' in strategy:
                        strategy['wait_before_action'] = min(8.0, strategy['wait_before_action'] * 1.2)
                    if 'retry_count' in strategy:
                        strategy['retry_count'] = min(5, strategy['retry_count'] + 1)
                
                elif "captcha" in error_type:
                    # Make behavior more human-like
                    strategy['human_like_behavior'] = True
                    strategy['random_delay'] = True
                    if 'delay_range' in strategy:
                        strategy['delay_range'] = [
                            min(3.0, strategy['delay_range'][0] * 1.3),
                            min(10.0, strategy['delay_range'][1] * 1.3)
                        ]
                
                # Update the strategy
                learning_data.strategy = json.dumps(strategy)
                db.session.commit()
                
            except Exception as e:
                logger.error(f"Error updating strategy from error: {str(e)}")
            
        except Exception as e:
            logger.exception(f"Error in update_learning_from_error: {str(e)}")

def format_user_friendly_error(analysis):
    """
    Format error analysis into a user-friendly message
    
    Args:
        analysis: Error analysis from ErrorHandler.analyze_error()
        
    Returns:
        str: User-friendly error message
    """
    message = []
    
    # Add a clear title
    message.append("🔍 Task Execution Problem")
    message.append("========================")
    message.append("")
    
    # Add error type in user-friendly terms
    error_type = analysis.get('error_type', 'unknown')
    friendly_error_type = error_type.replace('_', ' ').title()
    message.append(f"Issue Type: {friendly_error_type}")
    message.append("")
    
    # Add simplified error message
    error_msg = analysis.get('error_message', '')
    simple_msg = simplify_error_message(error_msg)
    message.append(f"What happened: {simple_msg}")
    message.append("")
    
    # Add suggestions
    message.append("Here's what you can try:")
    message.append("")
    
    # Combine general and specific suggestions without duplicates
    all_suggestions = []
    for suggestion in analysis.get('general_suggestions', []) + analysis.get('specific_suggestions', []):
        if suggestion not in all_suggestions:
            all_suggestions.append(suggestion)
    
    # Add top 5 suggestions with bullet points
    for i, suggestion in enumerate(all_suggestions[:5]):
        message.append(f"• {suggestion}")
    
    message.append("")
    message.append("The system will automatically adjust its strategy to avoid this issue in the future.")
    
    return "\n".join(message)

def simplify_error_message(error_msg):
    """Convert a technical error message to simple terms"""
    error_msg = str(error_msg).lower()
    
    # Remove technical details and stack traces
    if '\n' in error_msg:
        error_msg = error_msg.split('\n')[0]
    
    # Limit length
    if len(error_msg) > 150:
        error_msg = error_msg[:147] + '...'
    
    # Replace technical terms with simpler ones
    simplifications = {
        'element not found': 'couldn\'t find a button or element on the page',
        'no such element': 'an element on the page wasn\'t found',
        'timeout': 'the page took too long to respond',
        'stale element': 'the page changed before the action could be completed',
        'invalid session id': 'the browser session expired',
        'captcha': 'a captcha verification was detected',
        'rate limit': 'you\'ve reached the limit of requests allowed',
        'access denied': 'you don\'t have permission to access this resource',
        'connection refused': 'couldn\'t connect to the website',
        'forbidden': 'access to the website was denied',
        'proxy error': 'there was a problem with the proxy server',
        'authentication': 'there was a problem with login credentials',
        'network error': 'there was a connection problem',
        'internal server error': 'the website had an internal error'
    }
    
    for technical, simple in simplifications.items():
        if technical in error_msg:
            return simple
    
    # Default simplified message
    return "an error occurred while executing the task"

# Add ErrorLog model to models.py
def add_error_log_model():
    """
    Add ErrorLog model to models.py if not already present
    """
    try:
        from models import ErrorLog
        logger.info("ErrorLog model already exists")
    except ImportError:
        logger.info("Adding ErrorLog model to models.py")
        
        model_code = """
class ErrorLog(db.Model):
    __tablename__ = 'error_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    error_message = db.Column(db.Text)
    error_type = db.Column(db.String(64))
    task_type = db.Column(db.String(64))
    platform = db.Column(db.String(32))
    context = db.Column(db.Text)  # JSON string with execution context
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    resolved = db.Column(db.Boolean, default=False)
    resolution_notes = db.Column(db.Text)
"""
        
        try:
            with open('models.py', 'r') as f:
                content = f.read()
            
            if 'class ErrorLog' not in content:
                with open('models.py', 'a') as f:
                    f.write(model_code)
                
                # Create tables
                from app import app, db
                with app.app_context():
                    try:
                        db.create_all()
                        logger.info("Created ErrorLog table")
                    except Exception as e:
                        logger.error(f"Error creating table: {str(e)}")
        
        except Exception as e:
            logger.exception(f"Error adding ErrorLog model: {str(e)}")

# Initialize the module
try:
    add_error_log_model()
except Exception as e:
    logger.exception(f"Error initializing error_handler module: {str(e)}")