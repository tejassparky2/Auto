import logging
import json
import time
import threading
from datetime import datetime
import os
import re
import base64
import hashlib
from urllib.parse import urlparse
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup

from app import db
from models import Account, Airdrop, Task, TaskExecution, LearningData

logger = logging.getLogger(__name__)

class ActionRecorder:
    """
    Records user actions in a browser session and converts them to automation tasks.
    This allows the system to learn from manual executions and replicate them.
    """
    
    def __init__(self, account_id, airdrop_id):
        """Initialize recorder with account and airdrop IDs"""
        self.account_id = account_id
        self.airdrop_id = airdrop_id
        self.actions = []
        self.screenshot_dir = "static/screenshots"
        self.recording = False
        self.driver = None
        self.record_thread = None
        
        # Create screenshots directory if it doesn't exist
        os.makedirs(self.screenshot_dir, exist_ok=True)
    
    def start_recording(self):
        """Start recording user actions"""
        if self.recording:
            logger.warning("Recording already in progress")
            return False
        
        # Get account and airdrop
        account = Account.query.get(self.account_id)
        airdrop = Airdrop.query.get(self.airdrop_id)
        
        if not account or not airdrop:
            logger.error(f"Account {self.account_id} or Airdrop {self.airdrop_id} not found")
            return False
        
        try:
            # Set up Chrome options
            from automation import get_chrome_options
            chrome_options = get_chrome_options()
            
            # Add extension for recording
            # chrome_options.add_extension("path/to/recorder_extension.crx")
            
            # Initialize driver
            self.driver = webdriver.Chrome(options=chrome_options)
            
            # Start recording thread
            self.recording = True
            self.record_thread = threading.Thread(target=self._record_actions)
            self.record_thread.daemon = True
            self.record_thread.start()
            
            # Navigate to airdrop URL
            self.driver.get(airdrop.url)
            
            # Log start
            logger.info(f"Started recording actions for airdrop {self.airdrop_id} with account {self.account_id}")
            return True
            
        except Exception as e:
            logger.exception(f"Error starting recording: {str(e)}")
            self._cleanup()
            return False
    
    def stop_recording(self):
        """Stop recording and process the recorded actions"""
        if not self.recording:
            logger.warning("No recording in progress")
            return False
        
        try:
            # Stop recording
            self.recording = False
            
            # Wait for thread to finish
            if self.record_thread and self.record_thread.is_alive():
                self.record_thread.join(timeout=10)
            
            # Process recorded actions
            tasks = self._process_actions()
            
            # Clean up
            self._cleanup()
            
            return tasks
            
        except Exception as e:
            logger.exception(f"Error stopping recording: {str(e)}")
            self._cleanup()
            return False
    
    def _record_actions(self):
        """Record user actions in the browser"""
        try:
            # Initialize action tracking
            previous_url = self.driver.current_url
            previous_dom = self.driver.page_source
            
            while self.recording:
                try:
                    # Get current state
                    current_url = self.driver.current_url
                    current_dom = self.driver.page_source
                    
                    # Check for URL changes
                    if current_url != previous_url:
                        self._record_url_change(previous_url, current_url)
                        previous_url = current_url
                    
                    # Check for DOM changes
                    if self._significant_dom_change(previous_dom, current_dom):
                        self._record_dom_change(current_dom)
                        previous_dom = current_dom
                    
                    # Take screenshot periodically
                    if len(self.actions) % 5 == 0 and self.actions:
                        self._take_screenshot()
                    
                    # Sleep to reduce CPU usage
                    time.sleep(1)
                    
                except Exception as loop_error:
                    logger.error(f"Error in recording loop: {str(loop_error)}")
            
        except Exception as e:
            logger.exception(f"Error in _record_actions: {str(e)}")
            self.recording = False
    
    def _record_url_change(self, old_url, new_url):
        """Record URL change as an action"""
        logger.info(f"URL changed from {old_url} to {new_url}")
        
        self.actions.append({
            'type': 'url_change',
            'old_url': old_url,
            'new_url': new_url,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    def _record_dom_change(self, dom):
        """Record significant DOM change as an action"""
        # Parse DOM to detect clicked elements
        soup = BeautifulSoup(dom, 'html.parser')
        
        # Look for forms
        forms = soup.find_all('form')
        for form in forms:
            # Check for filled inputs
            inputs = form.find_all(['input', 'textarea', 'select'])
            filled_inputs = [input for input in inputs if input.get('value')]
            
            if filled_inputs:
                # Record form fill action
                self.actions.append({
                    'type': 'form_fill',
                    'form_id': form.get('id', ''),
                    'form_action': form.get('action', ''),
                    'inputs': [{'name': input.get('name', ''), 
                               'type': input.get('type', ''),
                               'value': input.get('value', '')}
                              for input in filled_inputs],
                    'timestamp': datetime.utcnow().isoformat()
                })
        
        # Look for button clicks
        buttons = soup.find_all(['button', 'a', 'input[type=submit]'])
        # (Simplified - in a real implementation, we'd need to track which button was clicked)
    
    def _significant_dom_change(self, old_dom, new_dom):
        """Detect if there has been a significant change in the DOM"""
        # Simple approach: check if length changed significantly
        return abs(len(old_dom) - len(new_dom)) > 100
    
    def _take_screenshot(self):
        """Take a screenshot of the current page"""
        try:
            timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
            filename = f"{self.airdrop_id}_{self.account_id}_{timestamp}.png"
            filepath = os.path.join(self.screenshot_dir, filename)
            
            self.driver.save_screenshot(filepath)
            
            self.actions.append({
                'type': 'screenshot',
                'path': filepath,
                'timestamp': datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error taking screenshot: {str(e)}")
    
    def _process_actions(self):
        """Process recorded actions into automation tasks"""
        if not self.actions:
            logger.warning("No actions recorded")
            return None
        
        try:
            logger.info(f"Processing {len(self.actions)} recorded actions")
            
            # Analyze actions to identify tasks
            tasks = []
            
            # Group actions by type
            url_changes = [a for a in self.actions if a['type'] == 'url_change']
            form_fills = [a for a in self.actions if a['type'] == 'form_fill']
            screenshots = [a for a in self.actions if a['type'] == 'screenshot']
            
            # Analyze URL patterns
            if url_changes:
                for url_change in url_changes:
                    new_url = url_change['new_url']
                    
                    # Detect Twitter actions
                    if 'twitter.com' in new_url or 'x.com' in new_url:
                        if '/status/' in new_url:
                            # Tweet interaction
                            if any('like' in a.get('form_id', '').lower() for a in form_fills):
                                tasks.append(self._create_task('twitter_like', {'tweet_link': new_url}))
                            if any('retweet' in a.get('form_id', '').lower() for a in form_fills):
                                tasks.append(self._create_task('twitter_retweet', {'tweet_link': new_url}))
                            if any('reply' in a.get('form_id', '').lower() for a in form_fills):
                                tasks.append(self._create_task('twitter_comment', {'tweet_link': new_url}))
                        else:
                            # Profile interaction
                            username = self._extract_twitter_username(new_url)
                            if username:
                                tasks.append(self._create_task('twitter_follow', {'username': username}))
                    
                    # Detect Discord actions
                    elif 'discord.com' in new_url or 'discord.gg' in new_url:
                        if '/invite/' in new_url or 'discord.gg/' in new_url:
                            invite_code = new_url.split('/')[-1].split('?')[0]
                            tasks.append(self._create_task('discord_join', {
                                'invite_code': invite_code,
                                'invite_link': new_url
                            }))
                    
                    # Detect Telegram actions
                    elif 't.me/' in new_url:
                        group_name = new_url.split('t.me/')[-1].split('?')[0]
                        tasks.append(self._create_task('telegram_join', {
                            'group_name': group_name,
                            'group_link': new_url
                        }))
            
            # Analyze form submissions
            if form_fills:
                website_forms = [f for f in form_fills if not any(domain in f.get('form_action', '')
                                                                for domain in ['twitter.com', 'x.com', 'discord.com', 't.me'])]
                
                if website_forms:
                    # Detect login/signup forms
                    login_forms = [f for f in website_forms 
                                 if any(field in str(f).lower() for field in ['login', 'sign in', 'username', 'password'])]
                    
                    signup_forms = [f for f in website_forms 
                                  if any(field in str(f).lower() for field in ['register', 'sign up', 'create account'])]
                    
                    if signup_forms:
                        tasks.append(self._create_task('website_signup', {'url': self.driver.current_url}))
                    elif login_forms:
                        tasks.append(self._create_task('website_login', {'url': self.driver.current_url}))
                    else:
                        # Generic form
                        tasks.append(self._create_task('website_form', {'url': self.driver.current_url}))
            
            # Save tasks to database
            stored_tasks = []
            airdrop = Airdrop.query.get(self.airdrop_id)
            
            if tasks and airdrop:
                for task_data in tasks:
                    # Check if similar task already exists
                    existing_task = Task.query.filter_by(
                        airdrop_id=self.airdrop_id,
                        task_type=task_data['task_type']
                    ).first()
                    
                    if not existing_task:
                        task = Task()
                        task.airdrop_id = self.airdrop_id
                        task.task_type = task_data['task_type']
                        task.description = task_data['description']
                        task.params = json.dumps(task_data['params'])
                        task.status = 'pending'
                        task.priority = 1
                        
                        db.session.add(task)
                        db.session.commit()
                        
                        stored_tasks.append(task)
            
            return stored_tasks
            
        except Exception as e:
            logger.exception(f"Error processing actions: {str(e)}")
            return None
    
    def _extract_twitter_username(self, url):
        """Extract username from Twitter URL"""
        try:
            if 'twitter.com/' in url:
                parts = url.split('twitter.com/')
            elif 'x.com/' in url:
                parts = url.split('x.com/')
            else:
                return None
            
            if len(parts) > 1:
                username = parts[1].split('/')[0].split('?')[0]
                if username and username not in ['home', 'explore', 'notifications', 'messages']:
                    return username
            
            return None
            
        except Exception as e:
            logger.error(f"Error extracting Twitter username: {str(e)}")
            return None
    
    def _create_task(self, task_type, params):
        """Create a task data structure"""
        descriptions = {
            'twitter_follow': f"Follow Twitter user @{params.get('username', '')}",
            'twitter_like': "Like the tweet",
            'twitter_retweet': "Retweet the tweet",
            'twitter_comment': "Comment on the tweet",
            'discord_join': f"Join Discord server with invite {params.get('invite_code', '')}",
            'telegram_join': f"Join Telegram group/channel {params.get('group_name', '')}",
            'website_signup': "Create account on website",
            'website_login': "Login to website",
            'website_form': "Complete form on website"
        }
        
        return {
            'task_type': task_type,
            'description': descriptions.get(task_type, f"Complete {task_type} task"),
            'params': params
        }
    
    def _cleanup(self):
        """Clean up resources"""
        self.recording = False
        
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            
        self.driver = None

def start_recording_session(account_id, airdrop_id):
    """
    Start a recording session to learn from manual execution
    
    Args:
        account_id: ID of the account to use
        airdrop_id: ID of the airdrop to learn
        
    Returns:
        ActionRecorder instance or None if failed
    """
    try:
        # Create recorder
        recorder = ActionRecorder(account_id, airdrop_id)
        
        # Start recording
        success = recorder.start_recording()
        
        if not success:
            logger.error("Failed to start recording session")
            return None
        
        return recorder
        
    except Exception as e:
        logger.exception(f"Error starting recording session: {str(e)}")
        return None

def stop_recording_session(recorder):
    """
    Stop a recording session and process the recorded actions
    
    Args:
        recorder: ActionRecorder instance
        
    Returns:
        list: Created tasks or None if failed
    """
    if not recorder:
        logger.error("Invalid recorder")
        return None
    
    try:
        # Stop recording
        tasks = recorder.stop_recording()
        
        if not tasks:
            logger.warning("No tasks created from recording")
            return None
        
        logger.info(f"Created {len(tasks)} tasks from recording")
        return tasks
        
    except Exception as e:
        logger.exception(f"Error stopping recording session: {str(e)}")
        return None