import logging
import re
import json
import random
import time
import os
import hashlib
from datetime import datetime
from urllib.parse import urlparse, parse_qs
import requests
from bs4 import BeautifulSoup

from app import db
from models import AIModel, Task

logger = logging.getLogger(__name__)

class AITaskDetector:
    """Advanced AI-based task detector for airdrops
    
    This system uses pattern recognition, NLP techniques, and rule-based approaches
    to identify tasks in airdrop websites without requiring expensive API calls.
    """
    
    def __init__(self):
        """Initialize the detector with models"""
        self.models = {}
        self.load_models()
    
    def load_models(self):
        """Load available AI models from the database"""
        try:
            ai_models = AIModel.query.filter_by(is_active=True).all()
            
            if not ai_models:
                # Create default pattern matching model if none exists
                default_model = AIModel()
                default_model.name = "Default Pattern Matcher"
                default_model.model_type = "pattern_matching"
                default_model.version = "1.0.0"
                default_model.description = "Default pattern matching model for task detection"
                default_model.params = json.dumps(self._get_default_patterns())
                default_model.is_active = True
                
                db.session.add(default_model)
                db.session.commit()
                
                ai_models = [default_model]
            
            # Load models into memory
            for model in ai_models:
                self.models[model.id] = {
                    'name': model.name,
                    'type': model.model_type,
                    'version': model.version,
                    'params': json.loads(model.params) if model.params else {}
                }
            
            logger.info(f"Loaded {len(self.models)} AI models for task detection")
            
        except Exception as e:
            logger.exception(f"Error loading AI models: {str(e)}")
            # Use default patterns if DB load fails
            self.models[0] = {
                'name': "Fallback Pattern Matcher",
                'type': "pattern_matching",
                'version': "1.0.0",
                'params': self._get_default_patterns()
            }
    
    def _get_default_patterns(self):
        """Get default patterns for task detection"""
        return {
            'twitter_patterns': {
                'follow': [
                    r'follow\s+@(\w+)',
                    r'follow\s+on\s+twitter',
                    r'follow\s+.{1,20}\s+twitter',
                    r'twitter\.com/(\w+)(?:\s+|$)',
                    r'x\.com/(\w+)(?:\s+|$)',
                    r'twitter:?\s*@(\w+)'
                ],
                'retweet': [
                    r'retweet',
                    r're-tweet',
                    r'rt\s+@',
                    r'rt\s+the\s+tweet',
                    r'share\s+.{1,20}\s+tweet'
                ],
                'like': [
                    r'like\s+the\s+tweet',
                    r'like\s+on\s+twitter',
                    r'like\s+.{1,20}\s+post'
                ],
                'comment': [
                    r'comment\s+on',
                    r'reply\s+to',
                    r'tag\s+friends',
                    r'leave\s+a\s+comment'
                ]
            },
            'discord_patterns': {
                'join': [
                    r'join\s+.{1,20}\s+discord',
                    r'join\s+discord\s+server',
                    r'discord\.gg/\w+',
                    r'discord\.com/invite/\w+'
                ],
                'message': [
                    r'send\s+a\s+message',
                    r'message\s+in\s+discord',
                    r'chat\s+in\s+.{1,20}\s+channel',
                    r'say\s+.{1,20}\s+in\s+discord'
                ],
                'verify': [
                    r'verify\s+in\s+discord',
                    r'verification',
                    r'get\s+verified',
                    r'verify\s+your\s+account'
                ]
            },
            'telegram_patterns': {
                'join': [
                    r'join\s+.{1,20}\s+telegram',
                    r'telegram\s+group',
                    r'telegram\s+channel',
                    r't\.me/\w+',
                    r'telegram\.org'
                ],
                'message': [
                    r'send\s+.{1,20}\s+telegram',
                    r'message\s+in\s+telegram',
                    r'telegram\s+bot'
                ]
            },
            'website_patterns': {
                'signup': [
                    r'sign\s*up',
                    r'register',
                    r'create\s+.{1,20}\s+account',
                    r'fill\s+in\s+the\s+form',
                    r'registration\s+form'
                ],
                'email': [
                    r'enter\s+.{1,20}\s+email',
                    r'submit\s+.{1,20}\s+email',
                    r'newsletter',
                    r'subscribe'
                ],
                'wallet': [
                    r'connect\s+.{1,20}\s+wallet',
                    r'connect\s+wallet',
                    r'ethereum\s+address',
                    r'wallet\s+address',
                    r'link\s+.{1,20}\s+wallet'
                ],
                'kyc': [
                    r'kyc',
                    r'know\s+your\s+customer',
                    r'verify\s+identity',
                    r'identity\s+verification'
                ],
                'quiz': [
                    r'quiz',
                    r'answer\s+questions',
                    r'questionnaire',
                    r'survey'
                ]
            }
        }
    
    def detect_tasks(self, url, content=None, html=None):
        """
        Detect tasks in an airdrop by analyzing URL, content and HTML
        
        Args:
            url: URL of the airdrop
            content: Optional text content of the page
            html: Optional HTML content of the page
            
        Returns:
            list: Detected tasks
        """
        tasks = []
        domain = urlparse(url).netloc
        
        try:
            # If content or HTML isn't provided, fetch it
            if not content and not html:
                html = self._fetch_url(url)
                
            if html and not content:
                content = self._extract_text(html)
            
            # Extract links for additional analysis
            links = self._extract_links(html, url) if html else []
            
            # Process with different models and aggregate results
            for model_id, model in self.models.items():
                if model['type'] == 'pattern_matching':
                    model_tasks = self._detect_with_patterns(model, url, domain, content, links, html)
                    tasks.extend(model_tasks)
                # Add other model types here (neural, hybrid, etc.)
            
            # Remove duplicates
            unique_tasks = self._deduplicate_tasks(tasks)
            
            # Prioritize and refine tasks
            final_tasks = self._prioritize_tasks(unique_tasks)
            
            return final_tasks
            
        except Exception as e:
            logger.exception(f"Error detecting tasks for URL {url}: {str(e)}")
            return []
    
    def _fetch_url(self, url):
        """Fetch HTML content from a URL"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            logger.error(f"Error fetching URL {url}: {str(e)}")
            return None
    
    def _extract_text(self, html):
        """Extract text content from HTML"""
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.extract()
            
            # Get text
            text = soup.get_text()
            
            # Break into lines and remove leading/trailing space
            lines = (line.strip() for line in text.splitlines())
            # Break multi-headlines into a line each
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            # Drop blank lines
            text = '\n'.join(chunk for chunk in chunks if chunk)
            
            return text
        except Exception as e:
            logger.error(f"Error extracting text from HTML: {str(e)}")
            return ""
    
    def _extract_links(self, html, base_url):
        """Extract links from HTML with their context"""
        links = []
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            for a in soup.find_all('a', href=True):
                href = a['href']
                # Convert relative URLs to absolute
                if not href.startswith(('http://', 'https://')):
                    href = urljoin(base_url, href)
                
                link_info = {
                    'url': href,
                    'text': a.get_text().strip(),
                    'classes': a.get('class', []),
                    'id': a.get('id', ''),
                    'title': a.get('title', '')
                }
                links.append(link_info)
            
            return links
        except Exception as e:
            logger.error(f"Error extracting links from HTML: {str(e)}")
            return []
    
    def _detect_with_patterns(self, model, url, domain, content, links, html):
        """Detect tasks using pattern matching"""
        tasks = []
        patterns = model['params']
        
        # Check if content is available
        if not content:
            return tasks
        
        # Normalize content
        content_lower = content.lower()
        
        # Check Twitter patterns
        for task_type, pattern_list in patterns.get('twitter_patterns', {}).items():
            for pattern in pattern_list:
                matches = re.finditer(pattern, content_lower)
                for match in matches:
                    context = self._get_context(content_lower, match.start(), 100)
                    task = self._create_twitter_task(task_type, match, context, links, url)
                    if task:
                        tasks.append(task)
        
        # Check Discord patterns
        for task_type, pattern_list in patterns.get('discord_patterns', {}).items():
            for pattern in pattern_list:
                matches = re.finditer(pattern, content_lower)
                for match in matches:
                    context = self._get_context(content_lower, match.start(), 100)
                    task = self._create_discord_task(task_type, match, context, links, url)
                    if task:
                        tasks.append(task)
        
        # Check Telegram patterns
        for task_type, pattern_list in patterns.get('telegram_patterns', {}).items():
            for pattern in pattern_list:
                matches = re.finditer(pattern, content_lower)
                for match in matches:
                    context = self._get_context(content_lower, match.start(), 100)
                    task = self._create_telegram_task(task_type, match, context, links, url)
                    if task:
                        tasks.append(task)
        
        # Check Website patterns
        for task_type, pattern_list in patterns.get('website_patterns', {}).items():
            for pattern in pattern_list:
                matches = re.finditer(pattern, content_lower)
                for match in matches:
                    context = self._get_context(content_lower, match.start(), 100)
                    task = self._create_website_task(task_type, match, context, links, url, domain)
                    if task:
                        tasks.append(task)
        
        # Analyze forms separately
        if html:
            form_tasks = self._analyze_forms(html, url, domain)
            tasks.extend(form_tasks)
        
        return tasks
    
    def _get_context(self, content, position, context_size):
        """Get context around a match position"""
        start = max(0, position - context_size // 2)
        end = min(len(content), position + context_size // 2)
        return content[start:end]
    
    def _create_twitter_task(self, task_type, match, context, links, url):
        """Create a Twitter task from a match"""
        if task_type == 'follow':
            # Try to extract username from the match
            username = None
            if match.groups():
                username = match.group(1)
            
            # If no username in match, try to find in links
            if not username:
                for link in links:
                    link_url = link['url'].lower()
                    if 'twitter.com/' in link_url or 'x.com/' in link_url:
                        parts = link_url.split('/')
                        for i, part in enumerate(parts):
                            if part in ['twitter.com', 'x.com'] and i+1 < len(parts):
                                if parts[i+1] not in ['search', 'hashtag', 'explore', 'home']:
                                    username = parts[i+1].split('?')[0]
                                    break
            
            if username:
                return {
                    'task_type': 'twitter_follow',
                    'description': f"Follow Twitter user @{username}",
                    'params': {
                        'username': username
                    },
                    'confidence': 0.9,
                    'context': context
                }
        
        elif task_type == 'retweet':
            # Try to find a tweet URL
            tweet_url = None
            for link in links:
                link_url = link['url'].lower()
                if ('twitter.com/' in link_url or 'x.com/' in link_url) and '/status/' in link_url:
                    tweet_url = link['url']
                    break
            
            if tweet_url:
                return {
                    'task_type': 'twitter_retweet',
                    'description': "Retweet the tweet",
                    'params': {
                        'tweet_link': tweet_url
                    },
                    'confidence': 0.85,
                    'context': context
                }
            else:
                return {
                    'task_type': 'twitter_retweet',
                    'description': "Retweet their tweet",
                    'params': {
                        'airdrop_url': url,
                        'context': context
                    },
                    'confidence': 0.6,
                    'context': context
                }
        
        elif task_type == 'like':
            # Try to find a tweet URL
            tweet_url = None
            for link in links:
                link_url = link['url'].lower()
                if ('twitter.com/' in link_url or 'x.com/' in link_url) and '/status/' in link_url:
                    tweet_url = link['url']
                    break
            
            if tweet_url:
                return {
                    'task_type': 'twitter_like',
                    'description': "Like the tweet",
                    'params': {
                        'tweet_link': tweet_url
                    },
                    'confidence': 0.85,
                    'context': context
                }
            else:
                return {
                    'task_type': 'twitter_like',
                    'description': "Like their tweet",
                    'params': {
                        'airdrop_url': url,
                        'context': context
                    },
                    'confidence': 0.6,
                    'context': context
                }
        
        elif task_type == 'comment':
            # Try to find a tweet URL
            tweet_url = None
            for link in links:
                link_url = link['url'].lower()
                if ('twitter.com/' in link_url or 'x.com/' in link_url) and '/status/' in link_url:
                    tweet_url = link['url']
                    break
            
            if tweet_url:
                return {
                    'task_type': 'twitter_comment',
                    'description': "Comment on the tweet",
                    'params': {
                        'tweet_link': tweet_url
                    },
                    'confidence': 0.8,
                    'context': context
                }
        
        return None
    
    def _create_discord_task(self, task_type, match, context, links, url):
        """Create a Discord task from a match"""
        if task_type == 'join':
            # Try to find a Discord invite
            invite_url = None
            invite_code = None
            
            # Check in the match first
            match_text = match.group(0)
            if 'discord.gg/' in match_text or 'discord.com/invite/' in match_text:
                parts = match_text.split('/')
                for part in parts:
                    if part and part not in ['discord.gg', 'discord.com', 'invite']:
                        invite_code = part.strip()
                        break
            
            # Then check in links
            if not invite_code:
                for link in links:
                    link_url = link['url'].lower()
                    if 'discord.gg/' in link_url or 'discord.com/invite/' in link_url:
                        invite_url = link['url']
                        parts = link_url.split('/')
                        for part in parts:
                            if part and part not in ['discord.gg', 'discord.com', 'invite']:
                                invite_code = part.split('?')[0]
                                break
                        break
            
            if invite_code:
                if not invite_url:
                    invite_url = f"https://discord.gg/{invite_code}"
                    
                return {
                    'task_type': 'discord_join',
                    'description': f"Join Discord server with invite {invite_code}",
                    'params': {
                        'invite_code': invite_code,
                        'invite_link': invite_url
                    },
                    'confidence': 0.9,
                    'context': context
                }
        
        elif task_type == 'message':
            # This requires more context to know which channel to message
            channel_name = None
            
            # Extract potential channel names from context
            channel_match = re.search(r'#(\w+[-\w]*)', context)
            if channel_match:
                channel_name = channel_match.group(1)
            
            return {
                'task_type': 'discord_message',
                'description': f"Send a message in Discord" + (f" channel #{channel_name}" if channel_name else ""),
                'params': {
                    'channel': channel_name,
                    'message_type': 'text',
                    'airdrop_url': url
                },
                'confidence': 0.7,
                'context': context
            }
        
        elif task_type == 'verify':
            return {
                'task_type': 'discord_verify',
                'description': "Verify your account in Discord",
                'params': {
                    'airdrop_url': url
                },
                'confidence': 0.8,
                'context': context
            }
        
        return None
    
    def _create_telegram_task(self, task_type, match, context, links, url):
        """Create a Telegram task from a match"""
        if task_type == 'join':
            # Try to find a Telegram group/channel
            group_url = None
            group_name = None
            
            # Check in the match
            match_text = match.group(0)
            if 't.me/' in match_text:
                parts = match_text.split('/')
                for part in parts:
                    if part and part != 't.me':
                        group_name = part.strip()
                        break
            
            # Then check in links
            if not group_name:
                for link in links:
                    link_url = link['url'].lower()
                    if 't.me/' in link_url:
                        group_url = link['url']
                        parts = link_url.split('/')
                        for part in parts:
                            if part and part != 't.me':
                                group_name = part.split('?')[0]
                                break
                        break
            
            if group_name:
                if not group_url:
                    group_url = f"https://t.me/{group_name}"
                    
                return {
                    'task_type': 'telegram_join',
                    'description': f"Join Telegram group/channel {group_name}",
                    'params': {
                        'group_name': group_name,
                        'group_link': group_url
                    },
                    'confidence': 0.9,
                    'context': context
                }
        
        return None
    
    def _create_website_task(self, task_type, match, context, links, url, domain):
        """Create a website task from a match"""
        if task_type == 'signup':
            return {
                'task_type': 'website_signup',
                'description': f"Create account on {domain}",
                'params': {
                    'url': url
                },
                'confidence': 0.8,
                'context': context
            }
        
        elif task_type == 'email':
            return {
                'task_type': 'website_email',
                'description': f"Subscribe with email on {domain}",
                'params': {
                    'url': url
                },
                'confidence': 0.8,
                'context': context
            }
        
        elif task_type == 'wallet':
            wallet_type = None
            
            # Try to determine wallet type
            wallet_types = ['metamask', 'trustwallet', 'phantom', 'sollet', 'walletconnect']
            for wtype in wallet_types:
                if wtype in context.lower():
                    wallet_type = wtype
                    break
            
            return {
                'task_type': 'website_wallet',
                'description': f"Connect wallet on {domain}" + (f" ({wallet_type})" if wallet_type else ""),
                'params': {
                    'url': url,
                    'wallet_type': wallet_type
                },
                'confidence': 0.85,
                'context': context
            }
        
        elif task_type == 'kyc':
            return {
                'task_type': 'website_kyc',
                'description': f"Complete KYC verification on {domain}",
                'params': {
                    'url': url
                },
                'confidence': 0.9,
                'context': context
            }
        
        elif task_type == 'quiz':
            return {
                'task_type': 'website_quiz',
                'description': f"Complete quiz on {domain}",
                'params': {
                    'url': url
                },
                'confidence': 0.85,
                'context': context
            }
        
        return None
    
    def _analyze_forms(self, html, url, domain):
        """Analyze forms in HTML to detect tasks"""
        tasks = []
        try:
            soup = BeautifulSoup(html, 'html.parser')
            forms = soup.find_all('form')
            
            for form in forms:
                # Check form purpose
                form_id = form.get('id', '')
                form_class = form.get('class', [])
                form_action = form.get('action', '')
                
                inputs = form.find_all(['input', 'textarea', 'select'])
                input_types = [inp.get('type', '') for inp in inputs]
                input_names = [inp.get('name', '') for inp in inputs]
                input_ids = [inp.get('id', '') for inp in inputs]
                
                # Look for email signup forms
                if ('email' in input_types or any('email' in name.lower() for name in input_names)) and \
                   (not any(password_input in input_types for password_input in ['password', 'pwd'])):
                    tasks.append({
                        'task_type': 'website_email',
                        'description': f"Subscribe with email on {domain}",
                        'params': {
                            'url': url,
                            'form_id': form_id
                        },
                        'confidence': 0.85
                    })
                
                # Look for registration forms
                elif 'password' in input_types or any('password' in name.lower() for name in input_names):
                    tasks.append({
                        'task_type': 'website_signup',
                        'description': f"Create account on {domain}",
                        'params': {
                            'url': url,
                            'form_id': form_id
                        },
                        'confidence': 0.9
                    })
                
                # Look for wallet connection forms
                elif any(wallet_term in str(form).lower() for wallet_term in ['wallet', 'connect', 'eth', 'sol', 'address']):
                    tasks.append({
                        'task_type': 'website_wallet',
                        'description': f"Connect wallet on {domain}",
                        'params': {
                            'url': url,
                            'form_id': form_id
                        },
                        'confidence': 0.85
                    })
            
            return tasks
            
        except Exception as e:
            logger.error(f"Error analyzing forms: {str(e)}")
            return []
    
    def _deduplicate_tasks(self, tasks):
        """Remove duplicate tasks"""
        unique_tasks = []
        task_hashes = set()
        
        for task in tasks:
            # Create a hash of task type and main param
            task_hash = None
            if task['task_type'] == 'twitter_follow' and 'username' in task['params']:
                task_hash = f"twitter_follow_{task['params']['username'].lower()}"
            elif task['task_type'] == 'twitter_retweet' and 'tweet_link' in task['params']:
                task_hash = f"twitter_retweet_{task['params']['tweet_link']}"
            elif task['task_type'] == 'twitter_like' and 'tweet_link' in task['params']:
                task_hash = f"twitter_like_{task['params']['tweet_link']}"
            elif task['task_type'] == 'discord_join' and 'invite_code' in task['params']:
                task_hash = f"discord_join_{task['params']['invite_code']}"
            elif task['task_type'] == 'telegram_join' and 'group_name' in task['params']:
                task_hash = f"telegram_join_{task['params']['group_name'].lower()}"
            else:
                # For other tasks, create a hash of the whole task
                task_json = json.dumps({
                    'type': task['task_type'],
                    'params': task['params']
                }, sort_keys=True)
                task_hash = hashlib.md5(task_json.encode()).hexdigest()
            
            if task_hash and task_hash not in task_hashes:
                task_hashes.add(task_hash)
                unique_tasks.append(task)
        
        return unique_tasks
    
    def _prioritize_tasks(self, tasks):
        """Prioritize and finalize tasks"""
        if not tasks:
            return []
        
        # Sort by confidence
        sorted_tasks = sorted(tasks, key=lambda x: x.get('confidence', 0), reverse=True)
        
        # Apply priority rules
        prioritized_tasks = []
        for task in sorted_tasks:
            # Skip low confidence tasks if we already have a better one of the same type
            if any(pt['task_type'] == task['task_type'] and pt.get('confidence', 0) > task.get('confidence', 0) + 0.2 for pt in prioritized_tasks):
                continue
            
            # Format the task for database storage
            final_task = {
                'task_type': task['task_type'],
                'description': task['description'],
                'params': task['params'],
                'priority': self._calculate_priority(task)
            }
            
            prioritized_tasks.append(final_task)
        
        return prioritized_tasks
    
    def _calculate_priority(self, task):
        """Calculate task priority (1-5, lower is higher priority)"""
        confidence = task.get('confidence', 0)
        
        # Base priority on confidence
        if confidence > 0.9:
            priority = 1
        elif confidence > 0.8:
            priority = 2
        elif confidence > 0.7:
            priority = 3
        elif confidence > 0.6:
            priority = 4
        else:
            priority = 5
        
        # Adjust based on task type importance
        task_type_priorities = {
            'discord_join': -1,  # Higher priority
            'telegram_join': -1,
            'twitter_follow': -1,
            'twitter_retweet': -1,
            'twitter_like': 0,
            'twitter_comment': 0,
            'discord_message': 0,
            'website_signup': -1,
            'website_wallet': -1,
            'website_email': 0,
            'website_kyc': -1,
            'website_quiz': 0
        }
        
        priority += task_type_priorities.get(task['task_type'], 0)
        
        # Ensure valid range
        return max(1, min(5, priority))

def detect_airdrop_tasks(airdrop_id, refresh=False):
    """
    Analyze an airdrop and detect tasks
    
    Args:
        airdrop_id: ID of the airdrop to analyze
        refresh: Whether to refresh existing tasks
        
    Returns:
        list: Detected tasks
    """
    from models import Airdrop, Task
    
    try:
        # Get airdrop
        airdrop = Airdrop.query.get(airdrop_id)
        
        if not airdrop:
            logger.error(f"Airdrop {airdrop_id} not found")
            return None
        
        # Check if airdrop already has tasks
        existing_tasks = Task.query.filter_by(airdrop_id=airdrop_id).all()
        if existing_tasks and not refresh:
            logger.info(f"Airdrop {airdrop_id} already has {len(existing_tasks)} tasks. Set refresh=True to re-analyze.")
            return existing_tasks
        
        # Initialize detector
        detector = AITaskDetector()
        
        # Detect tasks
        tasks = detector.detect_tasks(airdrop.url)
        
        if not tasks:
            logger.warning(f"No tasks detected for airdrop {airdrop_id}")
            return []
        
        # If refreshing, delete existing tasks
        if refresh and existing_tasks:
            for task in existing_tasks:
                db.session.delete(task)
            db.session.commit()
        
        # Save new tasks
        saved_tasks = []
        for task_data in tasks:
            task = Task()
            task.airdrop_id = airdrop_id
            task.task_type = task_data['task_type']
            task.description = task_data['description']
            task.params = json.dumps(task_data['params'])
            task.status = 'pending'
            task.priority = task_data.get('priority', 3)
            
            db.session.add(task)
            saved_tasks.append(task)
        
        db.session.commit()
        
        logger.info(f"Detected and saved {len(saved_tasks)} tasks for airdrop {airdrop_id}")
        return saved_tasks
    
    except Exception as e:
        logger.exception(f"Error detecting tasks for airdrop {airdrop_id}: {str(e)}")
        db.session.rollback()
        return None


def update_ai_model(model_id=None, new_patterns=None):
    """
    Update AI model patterns based on successful detections
    
    Args:
        model_id: Optional ID of the model to update (default: all active models)
        new_patterns: Optional new patterns to add
        
    Returns:
        bool: Success flag
    """
    try:
        # Get models to update
        if model_id:
            models = AIModel.query.filter_by(id=model_id, is_active=True).all()
        else:
            models = AIModel.query.filter_by(is_active=True, model_type='pattern_matching').all()
        
        if not models:
            logger.warning("No active models found to update")
            return False
        
        # Update each model
        for model in models:
            try:
                patterns = json.loads(model.params) if model.params else {}
                
                # Add new patterns if provided
                if new_patterns:
                    for category, category_patterns in new_patterns.items():
                        if category not in patterns:
                            patterns[category] = {}
                        
                        for task_type, pattern_list in category_patterns.items():
                            if task_type not in patterns[category]:
                                patterns[category][task_type] = []
                            
                            for pattern in pattern_list:
                                if pattern not in patterns[category][task_type]:
                                    patterns[category][task_type].append(pattern)
                
                # Update model
                model.params = json.dumps(patterns)
                model.updated_at = datetime.utcnow()
                
                # Update performance metrics if available
                # This would typically come from feedback on the model's performance
            
            except Exception as model_error:
                logger.error(f"Error updating model {model.id}: {str(model_error)}")
        
        db.session.commit()
        logger.info(f"Updated {len(models)} AI models")
        return True
        
    except Exception as e:
        logger.exception(f"Error updating AI models: {str(e)}")
        db.session.rollback()
        return False