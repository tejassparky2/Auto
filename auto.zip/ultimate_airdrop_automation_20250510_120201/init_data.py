import os
import logging
from datetime import datetime
from werkzeug.security import generate_password_hash

from app import db, app
from models import User, Account, Airdrop, Task, NotificationSettings

logger = logging.getLogger(__name__)

def init_default_data():
    """Initialize default data for the application"""
    try:
        with app.app_context():
            # Check if default user exists
            default_user = User.query.filter_by(username="Tejas").first()
            
            if not default_user:
                logger.info("Creating default user 'Tejas'")
                
                # Create default user
                default_user = User()
                default_user.username = "Tejas"
                default_user.email = "tejas@example.com"
                default_user.password_hash = generate_password_hash("Tejas")
                default_user.created_at = datetime.utcnow()
                
                db.session.add(default_user)
                db.session.commit()
                
                # Create default notification settings
                notification_settings = NotificationSettings()
                notification_settings.user_id = default_user.id
                notification_settings.email_notifications = True
                notification_settings.email = "tejas@example.com"
                notification_settings.notification_level = "important"
                
                db.session.add(notification_settings)
                
                # Create default accounts for different platforms
                platforms = [
                    {"platform": "twitter", "username": "tejas_twitter", "password": "Tejas123"},
                    {"platform": "discord", "username": "tejas_discord", "password": "Tejas123"},
                    {"platform": "telegram", "username": "tejas_telegram", "password": "Tejas123"}
                ]
                
                for platform_data in platforms:
                    account = Account()
                    account.user_id = default_user.id
                    account.platform = platform_data["platform"]
                    account.username = platform_data["username"]
                    account.password = platform_data["password"]
                    account.created_at = datetime.utcnow()
                    
                    db.session.add(account)
                
                # Create a sample airdrop
                sample_airdrop = Airdrop()
                sample_airdrop.user_id = default_user.id
                sample_airdrop.name = "Sample Airdrop"
                sample_airdrop.url = "https://example.com/airdrop"
                sample_airdrop.status = "pending"
                sample_airdrop.created_at = datetime.utcnow()
                
                db.session.add(sample_airdrop)
                db.session.commit()
                
                # Create sample tasks for the airdrop
                sample_tasks = [
                    {
                        "task_type": "twitter_follow",
                        "description": "Follow Twitter user @SampleProject",
                        "params": {"username": "SampleProject"}
                    },
                    {
                        "task_type": "twitter_retweet",
                        "description": "Retweet the announcement tweet",
                        "params": {"tweet_link": "https://twitter.com/SampleProject/status/123456789"}
                    },
                    {
                        "task_type": "discord_join",
                        "description": "Join Discord server",
                        "params": {"invite_link": "https://discord.gg/sample"}
                    }
                ]
                
                for task_data in sample_tasks:
                    task = Task()
                    task.airdrop_id = sample_airdrop.id
                    task.task_type = task_data["task_type"]
                    task.description = task_data["description"]
                    task.params = str(task_data["params"])
                    task.status = "pending"
                    task.priority = 1
                    
                    db.session.add(task)
                
                db.session.commit()
                logger.info("Default data initialized successfully")
            else:
                logger.info("Default user 'Tejas' already exists")
                
    except Exception as e:
        logger.exception(f"Error initializing default data: {str(e)}")

if __name__ == "__main__":
    init_default_data()