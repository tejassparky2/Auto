from datetime import datetime
from flask_login import UserMixin
from app import db

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    accounts = db.relationship('Account', backref='user', lazy='dynamic')
    airdrops = db.relationship('Airdrop', backref='user', lazy='dynamic')
    notification_settings = db.relationship('NotificationSettings', backref='user', uselist=False)
    proxy_servers = db.relationship('ProxyServer', backref='user', lazy='dynamic')

class Account(db.Model):
    __tablename__ = 'accounts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    platform = db.Column(db.String(64), nullable=False)  # twitter, discord, telegram, etc.
    username = db.Column(db.String(120), nullable=False)
    password = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120))
    access_token = db.Column(db.String(256))
    refresh_token = db.Column(db.String(256))
    token_expires_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    status = db.Column(db.String(32), default='active')  # active, locked, banned
    notes = db.Column(db.Text)
    
    # Relationships
    task_executions = db.relationship('TaskExecution', backref='account', lazy='dynamic')
    
    def is_token_valid(self):
        """Check if access token is still valid"""
        if not self.token_expires_at:
            return False
        return self.token_expires_at > datetime.utcnow()

class Airdrop(db.Model):
    __tablename__ = 'airdrops'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    url = db.Column(db.String(256), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(32), default='pending')  # pending, in_progress, completed, failed
    value_estimate = db.Column(db.Float)  # Estimated value of the airdrop
    time_estimate = db.Column(db.Integer)  # Estimated time to complete in minutes
    source = db.Column(db.String(64))  # Where this airdrop was discovered
    deadline = db.Column(db.DateTime)  # When the airdrop ends
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    tags = db.Column(db.String(256))  # Comma-separated tags
    success_chance = db.Column(db.Float)  # Estimated success probability (0-1)
    
    # Relationships
    tasks = db.relationship('Task', backref='airdrop', lazy='dynamic')

class Task(db.Model):
    __tablename__ = 'tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    airdrop_id = db.Column(db.Integer, db.ForeignKey('airdrops.id'), nullable=False)
    task_type = db.Column(db.String(64), nullable=False)  # twitter_follow, discord_join, etc.
    description = db.Column(db.String(256))
    params = db.Column(db.Text)  # JSON string with task parameters
    status = db.Column(db.String(32), default='pending')  # pending, in_progress, completed, failed, error
    priority = db.Column(db.Integer, default=1)  # 1 (highest) to 5 (lowest)
    result = db.Column(db.Text)  # JSON string with execution result
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    scheduled_for = db.Column(db.DateTime)  # When this task is scheduled to execute
    completed_at = db.Column(db.DateTime)  # When the task was completed
    
    # Relationships
    executions = db.relationship('TaskExecution', backref='task', lazy='dynamic')

class TaskExecution(db.Model):
    __tablename__ = 'task_executions'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    account_id = db.Column(db.Integer, db.ForeignKey('accounts.id'), nullable=False)
    status = db.Column(db.String(32), nullable=False)  # success, failure, error
    details = db.Column(db.Text)  # Detailed execution log or error message
    execution_time = db.Column(db.Float)  # Execution time in seconds
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    retry_count = db.Column(db.Integer, default=0)
    
    # Additional metrics for learning
    strategy_used = db.Column(db.Text)  # JSON string with strategy parameters
    error_type = db.Column(db.String(64))  # Classification of error if failed

class TaskHistory(db.Model):
    __tablename__ = 'task_history'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable=False)
    status = db.Column(db.String(32), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    details = db.Column(db.Text)
    performed_by = db.Column(db.String(64))  # user, system, scheduler

class LearningData(db.Model):
    __tablename__ = 'learning_data'
    
    id = db.Column(db.Integer, primary_key=True)
    task_type = db.Column(db.String(64), nullable=False)
    platform = db.Column(db.String(64), nullable=False)
    strategy = db.Column(db.Text)  # JSON string with strategy parameters
    success_rate = db.Column(db.Float)  # Success rate (0-1)
    avg_execution_time = db.Column(db.Float)  # Average execution time
    common_errors = db.Column(db.Text)  # JSON string with common error patterns
    total_attempts = db.Column(db.Integer, default=0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class NotificationSettings(db.Model):
    __tablename__ = 'notification_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Email notifications
    email_notifications = db.Column(db.Boolean, default=False)
    email = db.Column(db.String(120))
    
    # Telegram notifications
    telegram_notifications = db.Column(db.Boolean, default=False)
    telegram_chat_id = db.Column(db.String(64))
    
    # Slack notifications
    slack_notifications = db.Column(db.Boolean, default=False)
    slack_webhook_url = db.Column(db.String(256))
    
    # SMS notifications
    sms_notifications = db.Column(db.Boolean, default=False)
    phone_number = db.Column(db.String(32))
    
    # Notification preferences
    notification_level = db.Column(db.String(32), default='important')  # all, important, critical
    quiet_hours_start = db.Column(db.Time)
    quiet_hours_end = db.Column(db.Time)
    
    # Schedule preferences
    schedule_notifications = db.Column(db.Boolean, default=True)
    
    # Success/Failure preferences
    notify_on_success = db.Column(db.Boolean, default=True)
    notify_on_failure = db.Column(db.Boolean, default=True)
    notify_on_discovery = db.Column(db.Boolean, default=True)

class ProxyServer(db.Model):
    __tablename__ = 'proxy_servers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    ip_address = db.Column(db.String(64), nullable=False)
    port = db.Column(db.Integer, nullable=False)
    proxy_type = db.Column(db.String(32), nullable=False)  # http, https, socks4, socks5
    username = db.Column(db.String(120))
    password = db.Column(db.String(120))
    country = db.Column(db.String(64))
    status = db.Column(db.String(32), default='active')  # active, inactive, error
    speed = db.Column(db.Float)  # Speed in ms
    last_checked = db.Column(db.DateTime)
    
    def get_proxy_url(self):
        """Get proxy URL in format for requests library"""
        if self.username and self.password:
            auth = f"{self.username}:{self.password}@"
        else:
            auth = ""
        
        return f"{self.proxy_type}://{auth}{self.ip_address}:{self.port}"

class ScheduledTask(db.Model):
    __tablename__ = 'scheduled_tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    task_type = db.Column(db.String(64), nullable=False)  # discovery, execution, maintenance
    params = db.Column(db.Text)  # JSON string with task parameters
    schedule_type = db.Column(db.String(32), nullable=False)  # one_time, daily, weekly, monthly, custom
    cron_expression = db.Column(db.String(120))  # For custom schedules
    next_run = db.Column(db.DateTime, nullable=False)
    last_run = db.Column(db.DateTime)
    status = db.Column(db.String(32), default='active')  # active, paused, completed, error
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with parent user
    user = db.relationship('User', backref='scheduled_tasks')

class AirdropSource(db.Model):
    __tablename__ = 'airdrop_sources'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    url = db.Column(db.String(256), nullable=False)
    source_type = db.Column(db.String(32), nullable=False)  # website, twitter, discord, telegram, custom
    scraping_method = db.Column(db.String(32), default='html')  # html, api, rss
    selectors = db.Column(db.Text)  # JSON string with CSS selectors
    api_key = db.Column(db.String(256))
    is_active = db.Column(db.Boolean, default=True)
    check_frequency = db.Column(db.Integer, default=24)  # Check frequency in hours
    last_checked = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with parent user
    user = db.relationship('User', backref='airdrop_sources')

class AirdropSchedule(db.Model):
    __tablename__ = 'airdrop_schedules'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    airdrop_id = db.Column(db.Integer, db.ForeignKey('airdrops.id'), nullable=False)
    schedule_type = db.Column(db.String(32), nullable=False)  # one_time, recurring
    next_execution = db.Column(db.DateTime, nullable=False)
    frequency = db.Column(db.String(32))  # daily, weekly, custom
    cron_expression = db.Column(db.String(120))  # For custom schedules
    status = db.Column(db.String(32), default='active')  # active, paused, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='airdrop_schedules')
    airdrop = db.relationship('Airdrop', backref='schedules')

class AIModel(db.Model):
    __tablename__ = 'ai_models'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    model_type = db.Column(db.String(32), nullable=False)  # pattern_matching, neural, hybrid
    version = db.Column(db.String(32), nullable=False)
    description = db.Column(db.Text)
    params = db.Column(db.Text)  # JSON string with model parameters
    performance_metrics = db.Column(db.Text)  # JSON with metrics
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
class TaskTemplate(db.Model):
    __tablename__ = 'task_templates'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    task_type = db.Column(db.String(64), nullable=False)
    params = db.Column(db.Text)  # JSON string with template parameters
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship with parent user
    user = db.relationship('User', backref='task_templates')

class TaskRecording(db.Model):
    __tablename__ = 'task_recordings'
    
    id = db.Column(db.Integer, primary_key=True)
    airdrop_id = db.Column(db.Integer, db.ForeignKey('airdrops.id'), nullable=False)
    account_id = db.Column(db.Integer, db.ForeignKey('accounts.id'), nullable=False)
    actions = db.Column(db.Text)  # JSON string with recorded actions
    cookies = db.Column(db.Text)  # JSON string with cookies
    local_storage = db.Column(db.Text)  # JSON string with localStorage data
    network_requests = db.Column(db.Text)  # JSON string with network requests
    dom_snapshots = db.Column(db.Text)  # JSON string with DOM snapshots
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    airdrop = db.relationship('Airdrop', backref='recordings')
    account = db.relationship('Account', backref='recordings')