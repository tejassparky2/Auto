import logging
import requests
from bs4 import BeautifulSoup
import re
import trafilatura
from urllib.parse import urljoin, urlparse

# Configure logging
logger = logging.getLogger(__name__)

def fetch_page_content(url):
    """
    Fetch HTML content from a URL
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        logger.error(f"Error fetching {url}: {str(e)}")
        return None

def extract_text(html_content):
    """
    Extract main text content from HTML using trafilatura
    """
    try:
        text = trafilatura.extract(html_content)
        if text:
            return text
        
        # Fallback to BeautifulSoup if trafilatura fails
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.extract()
        
        # Get text
        text = soup.get_text()
        
        # Break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())
        # Break multi-headlines into a line each
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        # Remove blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)
        
        return text
    except Exception as e:
        logger.error(f"Error extracting text: {str(e)}")
        return ""

def extract_links(html_content, base_url):
    """
    Extract all links from HTML content
    """
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        links = []
        
        for link in soup.find_all('a', href=True):
            href = link.get('href')
            full_url = urljoin(base_url, href)
            links.append(full_url)
        
        return links
    except Exception as e:
        logger.error(f"Error extracting links: {str(e)}")
        return []

def detect_airdrop_requirements(text_content, links):
    """
    Detect airdrop requirements from text and links
    """
    requirements = []
    
    # Twitter requirements
    if re.search(r'follow.*twitter|twitter.*follow', text_content, re.IGNORECASE):
        twitter_handles = re.findall(r'@([a-zA-Z0-9_]+)', text_content)
        twitter_links = [link for link in links if 'twitter.com/' in link]
        
        if twitter_handles:
            for handle in twitter_handles:
                requirements.append({
                    'type': 'twitter_follow',
                    'target': handle
                })
        elif twitter_links:
            for link in twitter_links:
                username = link.split('twitter.com/')[-1].split('?')[0].split('/')[0]
                if username and username not in ['home', 'explore', 'notifications', 'messages']:
                    requirements.append({
                        'type': 'twitter_follow',
                        'target': username
                    })
    
    if re.search(r'retweet|rt @', text_content, re.IGNORECASE):
        tweet_links = [link for link in links if 'twitter.com/' in link and '/status/' in link]
        
        if tweet_links:
            for link in tweet_links:
                requirements.append({
                    'type': 'twitter_retweet',
                    'target': link
                })
    
    # Discord requirements
    if re.search(r'join.*discord|discord.*join', text_content, re.IGNORECASE):
        discord_links = [link for link in links if 'discord.gg/' in link or 'discord.com/invite/' in link]
        
        if discord_links:
            for link in discord_links:
                requirements.append({
                    'type': 'discord_join',
                    'target': link
                })
    
    # Telegram requirements
    if re.search(r'join.*telegram|telegram.*join', text_content, re.IGNORECASE):
        telegram_links = [link for link in links if 't.me/' in link]
        
        if telegram_links:
            for link in telegram_links:
                requirements.append({
                    'type': 'telegram_join',
                    'target': link
                })
    
    # Website requirements
    if re.search(r'sign up|register|create.*account', text_content, re.IGNORECASE):
        # Filter out known platform links
        website_links = [link for link in links if not any(platform in link for platform in 
                         ['twitter.com', 'discord.gg', 'discord.com', 't.me'])]
        
        if website_links:
            main_domain = urlparse(website_links[0]).netloc
            requirements.append({
                'type': 'website_signup',
                'target': website_links[0]
            })
    
    return requirements

def find_form_elements(html_content):
    """
    Find form elements in HTML content
    """
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        forms = []
        
        for form in soup.find_all('form'):
            form_data = {
                'action': form.get('action', ''),
                'method': form.get('method', 'get'),
                'inputs': []
            }
            
            for input_field in form.find_all(['input', 'textarea', 'select']):
                input_type = input_field.name
                input_name = input_field.get('name', '')
                input_id = input_field.get('id', '')
                input_value = input_field.get('value', '')
                input_placeholder = input_field.get('placeholder', '')
                
                if input_type == 'input':
                    input_type = input_field.get('type', 'text')
                
                form_data['inputs'].append({
                    'type': input_type,
                    'name': input_name,
                    'id': input_id,
                    'value': input_value,
                    'placeholder': input_placeholder
                })
            
            forms.append(form_data)
        
        return forms
    except Exception as e:
        logger.error(f"Error finding form elements: {str(e)}")
        return []
